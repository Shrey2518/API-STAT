# API-STAT

AI-assisted API security workbench with seven workspace sections.

## Core workspace

1. **Dashboard** - unified scores, findings, assessments, trends and account history.
2. **API Calculator** - parameterized threat model with AI interpretation and remediation.
3. **API Config Check** - in-browser Linux/Windows-style configuration terminal with practical URL commands.
4. **Live API / Source Code Test** - two-column live API testing and fast AI-assisted source-code review. Live API testing supports an optional **deep scan** that runs an OWASP API Security Top 10 style probe battery (BOLA/IDOR, broken authentication, rate-limit burst, mass assignment, and a safe injection smoke test) against the live endpoint, on top of the baseline transport/header checks.
5. **Security Chatbot** - real-time streamed AI security copilot with RAG-grounded reasoning.
6. **API Security Policy** - policy attachment library with in-app PDF viewer.
7. **History & Logs** - account-wide assessment and action history.

## Agentic AI layer (Section 5 - Security Chatbot)

The chatbot explains API **objects, properties, functions** and security concepts, and reasons over evidence you give it. Every message runs through a real, visible pipeline:

```
intake -> vectorize -> route -> execute -> retrieve (RAG) -> reason -> respond
```

1. **Vectorize** - the message (plus a digest of any attachment) becomes a TF-IDF keyword vector.
2. **Route** - each capability owns a *keyword vector*; cosine similarity plus deterministic signals (a JWT pattern, a CVE id, an attached report) pick which capabilities run. The routing scores are shown live in the Reasoning Pipeline panel.
3. **Execute** - selected capabilities produce structured evidence.
4. **Retrieve** - the 74-entry API-security knowledge base, the bundled policy PDF and your uploaded policy PDFs are searched by vector similarity.
5. **Reason** - the configured LLM streams a grounded answer token by token. With **no API key** a local engine composes the answer from the same evidence, so the chatbot is useful offline.

### Capabilities (each can be switched on/off in the UI)

| Capability | What it does |
|---|---|
| API Concept Explainer | Objects, properties, endpoints, methods, status codes, auth, CORS, GraphQL... |
| OWASP API Top 10 Mapper | Maps an issue or findings to OWASP API 2023 categories by vector similarity |
| Report Assessor | Parses an attached report, extracts findings, checks severity/CVSS consistency (recomputes CVSS v3.x from vectors), OWASP coverage, and completeness against API-STAT policy §4 |
| OpenAPI Inspector | Object catalogue, sensitive/privileged properties, unauthenticated operations, pagination, SSRF-prone parameters, suggested tests |
| JWT Analyzer | Decodes a pasted JWT locally (never verifies or trusts it) and checks alg/exp/aud/iss/claims |
| HTTP Header Analyzer | Reviews pasted response headers (HSTS, CORS, cookies, caching, disclosure) |
| CVE Intelligence | NVD then OSV lookup (network) |
| Live HTTP Probe | Light GET + OPTIONS check of a URL you type (network, SSRF-guarded, no attack payloads) |
| Assessment Evidence | Uses your current Section 4 scan as evidence |
| Policy RAG | Passages from the policy PDFs, ASVS and NIST SSDF |
| Remediation Advisor / Test Plan Builder | Fixes with code, and test steps (per-operation when an OpenAPI spec is attached) |

### Attaching a report with **+**

Click **+** (or drag and drop) to attach up to 3 files of 10 MB: `.pdf .docx .json .sarif .yaml .yml .html .htm .md .txt .log .csv .xml`. Attachments stay available for follow-up questions ("how do I fix the high findings?") until you remove them or press Clear. Scanned/image-only PDFs are not OCR'd.

### Safety and privacy

- Files are processed in memory and never written to disk; only metadata is logged.
- Secrets, tokens and JWTs are redacted before any text is sent to an external LLM.
- Uploaded content and tool output are fenced as untrusted data in the LLM prompt (prompt-injection defence); capabilities are chosen by deterministic code, never by the LLM.
- Per-user rate limit (`AGENT_RATE_LIMIT_PER_MIN`, per gunicorn worker).
- Findings extracted from unstructured PDFs/DOCX are heuristic: verify against the source. Spec-based findings are *review candidates*, not proof of vulnerability.

### Extending

Add knowledge in `app/knowledge.py` (one `_e(...)` entry). Add a capability in `app/capabilities.py` (keywords + optional signal + a runner returning `{summary, severity, md, llm, card, actions, kb}`). Run the tests with `python -m unittest discover -s tests -v`.

## Image evidence

An optional PNG/JPG/JPEG/WEBP screenshot can be attached **only during source-code scans**. When an OpenAI multimodal model is configured, API-STAT can analyze visible security-relevant evidence from the image. Without a multimodal key, the image remains stored as scan evidence and the rest of the scan continues normally.

## Run locally

```powershell
python -m venv venv
.\\venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
python main.py
```

The application opens Google Chrome at `/dashboard` when available.

## MongoDB Atlas backend

API-STAT uses **MongoDB Atlas** for persistence. The database name defaults to `apistat`; collections are created automatically when the app connects, and indexes are created for user lookups, scan history, findings, action logs, policies, calculator assessments, configuration checks and live API assessments.

1. Create a free MongoDB Atlas cluster and a database user.
2. In Atlas Network Access, allow the IP address from which you will run API-STAT. Avoid `0.0.0.0/0` for a real deployment.
3. In Atlas, select **Connect → Drivers → Python** and copy the connection string.
4. Copy `.env.example` to `.env`, then set `MONGODB_URI` to the Atlas connection string and keep `MONGODB_DB=apistat`.
5. Replace the username/password placeholders. URL-encode special characters in the database password if necessary. Never put the connection string in frontend JavaScript or commit `.env` to GitHub.
6. Start the app with `python main.py`.

Example `.env` entries (use your actual Atlas URI; do not copy this placeholder literally):

```dotenv
MONGODB_URI=mongodb+srv://<db_user>:<db_password>@<your-cluster-host>/?retryWrites=true&w=majority&appName=API-STAT
MONGODB_DB=apistat
SECRET_KEY=replace-with-a-long-random-secret
```

Collections used: `users`, `scans`, `findings`, `action_logs`, `policy_documents`, `calculator_assessments`, `config_assessments`, and `live_api_assessments`. Assessment data is linked to the owning user. Passwords are stored as hashes; API evidence and target URLs are redacted before saving where the existing route supports redaction. Policy PDFs and uploaded source files remain in local file storage; MongoDB stores their metadata/references rather than entire files.

### Optional: migrate data from the bundled legacy SQLite database

The old `instance/apistat.db` file is retained solely as a migration source. After setting `MONGODB_URI`, run:

```powershell
python migrate_sqlite_to_mongodb.py --source instance/apistat.db
```

Run this once against the intended Atlas database. The script is idempotent for existing numeric IDs and does not delete the SQLite file. Local file paths for old policy/source uploads only work if those files are still present on this computer.

## Environment

Copy `.env.example` to `.env` and configure MongoDB Atlas and a Flask secret. For AI analysis, configure one of:

- `OPENAI_API_KEY`
- `GEMINI_API_KEY`
- `OLLAMA_BASE_URL`

Optional OpenAI visual analysis model:

- `OPENAI_VISION_MODEL`

## Assessment reports

- **Live API and configuration reports** use the actual URL, HTTP response, observed controls, timing, response evidence and AI remediation returned for the selected assessment.
- **Source-code reports** use the actual scan findings, rule/CVE identifiers, file and line locations, source evidence, category scores, scan pipeline and AI-generated priority actions.
- The two HTML report layouts are intentionally different because live HTTP tests and source-code scans produce different evidence. Reports open in a browser tab and are generated from the latest result for that account (source reports are tied to the individual scan).
- Configure `OPENAI_API_KEY`, `GEMINI_API_KEY` or `OLLAMA_BASE_URL` to enable an external/local LLM. Without a configured provider, API-STAT labels the deterministic local heuristic fallback instead of claiming a remote AI model was used. Validate automated findings before acting on them.

## Policy

The bundled 19-page policy attachment is displayed as `api-stat version1` and opened in the in-app PDF viewer. The original viewer/download URL is retained; additional PDF policies can be added and deleted from Section 6.

## Notes

- GitHub OAuth is intentionally not part of login. Public GitHub repository URLs can be used as an alternative source connector in Section 4.
- No separate CLI application is required; Section 3 provides the terminal-like interface in the browser.

## Windows runtime troubleshooting

Use Python 3.12.x for the most reliable compatibility with the bundled security-analysis tools. If a traceback ends inside `subprocess.py` while Bandit/Semgrep is running, recreate the virtual environment with Python 3.12:

```powershell
Deactivate
Remove-Item -Recurse -Force .\venv
py -3.12 -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

The scanner now executes Bandit only against discovered Python source files and excludes common virtual-environment/build directories from Semgrep. External security tools are also time-limited so a tool failure cannot hang the web request.
