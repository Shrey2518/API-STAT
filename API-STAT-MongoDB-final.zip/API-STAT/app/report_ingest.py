"""Safe parsing and analysis of security reports attached in the chatbot ("+" button).

Supported inputs: PDF, DOCX, JSON (SARIF / OpenAPI / generic findings), YAML,
HTML, Markdown, TXT/LOG, CSV and XML (as text). Nothing is executed and nothing
is fetched from the network; files are processed in memory and never written to
disk. Only metadata is logged, never document content.
"""
from __future__ import annotations

import csv
import io
import json
import math
import os
import re
import zipfile
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .knowledge import owasp_index, owasp_label, OWASP_IDS, get_entry

MAX_UPLOAD_BYTES = int(float(os.getenv("AGENT_MAX_UPLOAD_MB", "10")) * 1024 * 1024)
MAX_YAML_BYTES = 2 * 1024 * 1024
MAX_TEXT_CHARS = 400_000
MAX_PDF_PAGES = 200
MAX_UNCOMPRESSED_DOCX = 120 * 1024 * 1024
ALLOWED_EXT = (".pdf", ".docx", ".json", ".sarif", ".yaml", ".yml", ".html", ".htm",
               ".md", ".txt", ".log", ".csv", ".xml")

SEV_ORDER = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]
_SEV_NORM = {"critical": "CRITICAL", "high": "HIGH", "medium": "MEDIUM", "moderate": "MEDIUM",
             "low": "LOW", "info": "INFO", "informational": "INFO", "none": "INFO",
             "error": "HIGH", "warning": "MEDIUM", "note": "LOW"}


class ParseError(Exception):
    """Raised for files we cannot or will not parse (message is safe to show the user)."""


@dataclass
class ParsedDoc:
    name: str
    ext: str
    size: int
    kind: str = "text"            # text | sarif | openapi | json-report | csv-report
    text: str = ""
    structured: Any = None        # parsed JSON/YAML object when available
    pages: Optional[int] = None
    truncated: bool = False
    warnings: List[str] = field(default_factory=list)
    carried: bool = False          # True when re-sent from an earlier turn (follow-up question)
    _analysis: Any = None          # cached analyze_report() result

    def meta(self) -> dict:
        return {"name": self.name, "size": self.size, "kind": self.kind,
                "pages": self.pages, "chars": len(self.text), "truncated": self.truncated, "carried": self.carried}


# ============================================================ text extraction
class _HTMLText(HTMLParser):
    BLOCK = {"p", "div", "br", "li", "tr", "section", "article", "table", "ul", "ol", "pre"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: List[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript"):
            self._skip += 1
        elif tag in ("h1", "h2", "h3", "h4"):
            self.parts.append("\n" + "#" * int(tag[1]) + " ")
        elif tag in ("td", "th"):
            self.parts.append(" | ")
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript") and self._skip:
            self._skip -= 1
        elif tag in ("h1", "h2", "h3", "h4") or tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self._skip:
            self.parts.append(data)


def _decode(data: bytes) -> str:
    for enc in ("utf-8-sig", "utf-16"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("latin-1", errors="ignore")


def _pdf_text(data: bytes, doc: ParsedDoc) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as exc:  # pragma: no cover - depends on environment
        raise ParseError("PDF support needs the 'pypdf' package (pip install pypdf).") from exc
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            try:
                if not reader.decrypt(""):
                    raise ParseError("The PDF is password-protected. Remove the password and attach it again.")
            except ParseError:
                raise
            except Exception as exc:
                raise ParseError("The PDF is encrypted and could not be opened.") from exc
        total = len(reader.pages)
        doc.pages = total
        parts = []
        for i, page in enumerate(reader.pages):
            if i >= MAX_PDF_PAGES:
                doc.truncated = True
                doc.warnings.append(f"Only the first {MAX_PDF_PAGES} of {total} pages were read.")
                break
            parts.append(page.extract_text() or "")
        text = "\n".join(parts)
    except ParseError:
        raise
    except Exception as exc:
        raise ParseError(f"The PDF could not be read ({type(exc).__name__}). It may be corrupt.") from exc
    if len(text.strip()) < 20:
        doc.warnings.append("No extractable text found - this looks like a scanned/image-only PDF (OCR is not supported).")
    return text


def _docx_text(data: bytes, doc: ParsedDoc) -> str:
    try:
        import docx  # python-docx
        from docx.table import Table
        from docx.text.paragraph import Paragraph
    except ImportError as exc:  # pragma: no cover
        raise ParseError("DOCX support needs the 'python-docx' package.") from exc
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if sum(i.file_size for i in z.infolist()) > MAX_UNCOMPRESSED_DOCX:
                raise ParseError("The DOCX expands to an unreasonable size and was rejected.")
        d = docx.Document(io.BytesIO(data))
    except ParseError:
        raise
    except Exception as exc:
        raise ParseError(f"The DOCX could not be read ({type(exc).__name__}).") from exc
    lines: List[str] = []
    for child in d.element.body.iterchildren():
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            p = Paragraph(child, d)
            txt = p.text.strip()
            if not txt:
                continue
            style = (p.style.name if p.style is not None else "") or ""
            m = re.match(r"heading\s*(\d)", style, re.I)
            lines.append(("#" * min(4, int(m.group(1))) + " " + txt) if m else txt)
        elif tag == "tbl":
            t = Table(child, d)
            for row in t.rows:
                cells: List[str] = []
                for c in row.cells:
                    ct = " ".join(c.text.split())
                    if ct and (not cells or cells[-1] != ct):
                        cells.append(ct)
                if cells:
                    lines.append(" | ".join(cells))
    return "\n".join(lines)


def _looks_like_openapi(obj: Any) -> bool:
    return isinstance(obj, dict) and ("openapi" in obj or "swagger" in obj) and isinstance(obj.get("paths"), dict)


def _looks_like_sarif(obj: Any) -> bool:
    return isinstance(obj, dict) and isinstance(obj.get("runs"), list) and (
        "sarif" in str(obj.get("$schema", "")).lower() or str(obj.get("version", "")).startswith("2.1")
        or any(isinstance(r, dict) and "results" in r for r in obj["runs"]))


def parse_upload(filename: str, data: bytes) -> ParsedDoc:
    """Parse an uploaded file into text (+ structured data when the format has it)."""
    name = os.path.basename(filename or "report") or "report"
    ext = os.path.splitext(name)[1].lower()
    doc = ParsedDoc(name=name, ext=ext, size=len(data))
    if ext not in ALLOWED_EXT:
        raise ParseError(f"'{ext or 'unknown'}' files are not supported. Attach: {', '.join(ALLOWED_EXT)}.")
    if not data:
        raise ParseError("The file is empty.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise ParseError(f"The file is larger than {MAX_UPLOAD_BYTES // (1024 * 1024)} MB.")

    if ext == ".pdf":
        if not data.lstrip().startswith(b"%PDF"):
            raise ParseError("This file has a .pdf extension but is not a PDF.")
        doc.text = _pdf_text(data, doc)
    elif ext == ".docx":
        if not data.startswith(b"PK"):
            raise ParseError("This file has a .docx extension but is not a DOCX.")
        doc.text = _docx_text(data, doc)
    elif ext in (".html", ".htm"):
        p = _HTMLText()
        p.feed(_decode(data))
        doc.text = re.sub(r"\n{3,}", "\n\n", "".join(p.parts))
    elif ext in (".json", ".sarif"):
        raw = _decode(data)
        try:
            obj = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ParseError(f"Invalid JSON: {exc.msg} (line {exc.lineno}).") from exc
        doc.structured = obj
        doc.kind = "sarif" if _looks_like_sarif(obj) else "openapi" if _looks_like_openapi(obj) else "json-report"
        doc.text = raw
    elif ext in (".yaml", ".yml"):
        if len(data) > MAX_YAML_BYTES:
            raise ParseError("YAML files larger than 2 MB are not accepted. Convert to JSON or trim the file.")
        try:
            import yaml
            obj = yaml.safe_load(_decode(data))
        except Exception as exc:
            raise ParseError(f"Invalid YAML: {str(exc)[:120]}") from exc
        doc.structured = obj
        doc.kind = "openapi" if _looks_like_openapi(obj) else "json-report"
        doc.text = _decode(data)
    elif ext == ".csv":
        doc.text = _decode(data)
        doc.kind = "csv-report"
    else:  # .md .txt .log .xml
        raw = _decode(data)
        doc.text = re.sub(r"<[^>]{1,200}>", " ", raw) if ext == ".xml" else raw

    if len(doc.text) > MAX_TEXT_CHARS:
        doc.text = doc.text[:MAX_TEXT_CHARS]
        doc.truncated = True
        doc.warnings.append(f"Text was truncated to {MAX_TEXT_CHARS:,} characters.")
    return doc


# ============================================================ CVSS helpers
_CVSS3 = {
    "AV": {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.2},
    "AC": {"L": 0.77, "H": 0.44},
    "UI": {"N": 0.85, "R": 0.62},
    "CIA": {"H": 0.56, "L": 0.22, "N": 0.0},
}
_RE_CVSS_VECTOR = re.compile(r"CVSS:3\.[01]/(?:[A-Z]{1,2}:[A-Z]/?)+")


def _roundup(x: float) -> float:
    i = int(round(x * 100000))
    return i / 100000.0 if i % 10000 == 0 else (math.floor(i / 10000) + 1) / 10.0


def cvss3_base_score(vector: str) -> Optional[float]:
    """Compute the CVSS v3.x base score from a vector string, or None if it is not a valid v3 vector."""
    try:
        parts = dict(p.split(":", 1) for p in vector.strip().split("/")[1:])
        scope_changed = parts["S"] == "C"
        av, ac, ui = _CVSS3["AV"][parts["AV"]], _CVSS3["AC"][parts["AC"]], _CVSS3["UI"][parts["UI"]]
        pr = {"N": 0.85, "L": 0.68 if scope_changed else 0.62, "H": 0.5 if scope_changed else 0.27}[parts["PR"]]
        c, i, a = (_CVSS3["CIA"][parts[k]] for k in ("C", "I", "A"))
    except (KeyError, ValueError):
        return None
    iss = 1 - (1 - c) * (1 - i) * (1 - a)
    impact = 7.52 * (iss - 0.029) - 3.25 * (iss - 0.02) ** 15 if scope_changed else 6.42 * iss
    if impact <= 0:
        return 0.0
    expl = 8.22 * av * ac * pr * ui
    raw = 1.08 * (impact + expl) if scope_changed else impact + expl
    return _roundup(min(raw, 10))


def severity_from_cvss(score: float) -> str:
    if score >= 9.0:
        return "CRITICAL"
    if score >= 7.0:
        return "HIGH"
    if score >= 4.0:
        return "MEDIUM"
    if score > 0:
        return "LOW"
    return "INFO"


# ============================================================ regexes
_SEV = r"(critical|high|medium|moderate|low|informational|info|none)"
RE_SEV_LABEL = re.compile(r"(?:severity|risk(?:\s*(?:level|rating))?|rating|priority|criticality)\s*[:\-=|]?\s*[\(\[]?\s*" + _SEV + r"\b", re.I)
RE_SEV_BRACKET = re.compile(r"[\[\(]\s*" + _SEV + r"\s*[\]\)]", re.I)
RE_SEV_LEAD = re.compile(r"^\s*" + _SEV + r"\s*[:\-–—|]\s+\S", re.I)
RE_CVSS_SCORE = re.compile(r"cvss(?:\s*v?3(?:\.\d)?)?(?:\s*(?:base)?\s*score)?\s*[:=\-|]?\s*(\d{1,2}(?:\.\d)?)(?![\d/.])", re.I)
RE_CVE = re.compile(r"\bCVE-\d{4}-\d{4,7}\b", re.I)
RE_CWE = re.compile(r"\bCWE-\d{1,5}\b", re.I)
RE_OWASP = re.compile(r"\bAPI(10|[1-9])(?::2023|:2019)?\b|\bA(0[1-9]|10):20(?:21|17)\b")
RE_ENDPOINT = re.compile(r"\b(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(/[A-Za-z0-9_\-./{}:~%?=&]{1,150})")
RE_URL = re.compile(r"https?://[^\s<>\"')\]]{4,200}")
RE_EVIDENCE = re.compile(r"evidence|proof[- ]of[- ]concept|\bpoc\b|steps? to reproduce|reproduc|\bcurl\s|request\s*:|response\s*:|screenshot|payload", re.I)
RE_REPRO = re.compile(r"steps? to reproduce|reproduc|\bpoc\b|proof[- ]of[- ]concept|\bcurl\s", re.I)
RE_REMEDIATION = re.compile(r"remediation|recommendation|mitigation|solution|how to fix|\bfix\b|resolve|recommended (?:action|fix)", re.I)
RE_IMPACT = re.compile(r"\bimpact\b|consequence|business risk|attacker (?:can|could|may)", re.I)
RE_AFFECTED = re.compile(r"affected|endpoint|component|asset|location|\burl\b|host|target", re.I)

RE_MD_HEADING = re.compile(r"^\s{0,3}#{1,4}\s+(.{4,160})$")
RE_ID_HEADING = re.compile(
    r"^\s*(?:(?:finding|issue|vulnerability|vuln|bug|observation)\s*)?[#№]?\s*"
    r"([A-Z]{1,6}[-_ ]?\d{1,4}|\d{1,3}(?:\.\d{1,2}){0,2})\s*[.:)\-–—]\s*(.{5,140})$", re.I)
RE_FINDING_HEADING = re.compile(r"^\s*(?:finding|issue|vulnerability|vuln|observation)\s*[#№]?\s*(\d{1,3})\s*[.:)\-–—]?\s*(.{0,140})$", re.I)
RE_SECTION_BREAK = re.compile(
    r"^\W*(?:\d+[.)]?\s*)?(executive summary|management summary|summary|scope|methodology|approach|conclusion|conclusions|"
    r"appendix|appendices|references|about|disclaimer|table of contents|introduction|overview|background|"
    r"revision history|document control|contents|findings summary|summary of findings|testing timeline)\b", re.I)


def _norm_sev(word: Optional[str]) -> Optional[str]:
    return _SEV_NORM.get((word or "").strip().lower()) if word else None


def _find_severity(block: str, title: str = "") -> Optional[str]:
    m = RE_SEV_LABEL.search(block)
    if m:
        return _norm_sev(m.group(1))
    for probe in (title, block[:300]):
        m = RE_SEV_BRACKET.search(probe) or RE_SEV_LEAD.search(probe)
        if m:
            return _norm_sev(m.group(1))
    return None


def _uniq(seq: Iterable[str], limit: int = 50) -> List[str]:
    out: List[str] = []
    for s in seq:
        if s not in out:
            out.append(s)
        if len(out) >= limit:
            break
    return out


def _norm_owasp(match: "re.Match") -> str:
    s = match.group(0).upper()
    if s.startswith("API"):
        num = match.group(1)
        return f"API{num}:2023"
    return s


def _tidy_title(title: str) -> str:
    title = re.sub(r"^[\s#*\-–—]+", "", title)
    title = re.sub(r"[\[\(]\s*" + _SEV + r"\s*[\]\)]", "", title, flags=re.I)
    title = re.sub(r"^\W*(?:finding|issue|vulnerability|vuln)\s*[#№]?\s*\d*\s*[.:)\-–—]?\s*", "", title, flags=re.I)
    title = re.sub(r"\.{3,}\s*\d+\s*$", "", title)   # table-of-contents dots
    return " ".join(title.split())[:160]


# ============================================================ finding construction
def _new_finding(fid: str, title: str, block: str, source: str, **extra) -> dict:
    sev = extra.pop("severity", None) or _find_severity(block, title)
    vector_m = _RE_CVSS_VECTOR.search(block)
    vector = extra.pop("cvss_vector", None) or (vector_m.group(0) if vector_m else None)
    cvss = extra.pop("cvss", None)
    if cvss is None:
        m = RE_CVSS_SCORE.search(block)
        if m:
            try:
                val = float(m.group(1))
                cvss = val if 0 <= val <= 10 else None
            except ValueError:
                cvss = None
    computed = cvss3_base_score(vector) if vector else None
    if cvss is None and computed is not None:
        cvss = computed
    endpoints = extra.pop("endpoints", None)
    if endpoints is None:
        endpoints = _uniq([f"{m.group(1)} {m.group(2).rstrip('.,;:)')}" for m in RE_ENDPOINT.finditer(block)] +
                          [u for u in RE_URL.findall(block)], 6)
    f = {
        "id": fid,
        "title": title or "Untitled finding",
        "severity": sev,
        "cvss": cvss,
        "cvss_vector": vector,
        "cvss_computed": computed,
        "cve": _uniq(m.upper() for m in RE_CVE.findall(block)),
        "cwe": _uniq(m.upper() for m in RE_CWE.findall(block)),
        "owasp": _uniq(_norm_owasp(m) for m in RE_OWASP.finditer(block)),
        "endpoints": endpoints,
        "has_evidence": bool(RE_EVIDENCE.search(block)),
        "has_repro": bool(RE_REPRO.search(block)),
        "has_remediation": bool(RE_REMEDIATION.search(block)),
        "has_impact": bool(RE_IMPACT.search(block)),
        "description": " ".join(block.split())[:420],
        "excerpt": block.strip()[:700],
        "source": source,
    }
    f.update(extra)
    return f


def _indicator_count(block: str, title: str) -> Tuple[int, bool]:
    sev = _find_severity(block, title) is not None
    n = sum([
        sev,
        bool(RE_CVSS_SCORE.search(block) or _RE_CVSS_VECTOR.search(block) or RE_CVE.search(block) or RE_CWE.search(block)),
        bool(RE_REMEDIATION.search(block)),
        bool(RE_EVIDENCE.search(block)),
        bool(RE_IMPACT.search(block)),
        bool(RE_ENDPOINT.search(block) or RE_AFFECTED.search(block)),
        bool(re.search(r"\bdescription\b", block, re.I)),
    ])
    return n, sev


def extract_findings_from_text(text: str) -> List[dict]:
    """Heuristically split unstructured report text into findings."""
    lines = text.splitlines()
    anchors: List[Tuple[int, str, str]] = []  # (line index, title, kind)
    for i, raw in enumerate(lines):
        line = raw.strip()
        if not line or len(line) > 200:
            continue
        m = RE_MD_HEADING.match(line)
        if m:
            anchors.append((i, m.group(1), "md"))
            continue
        m = RE_FINDING_HEADING.match(line)
        if m:
            anchors.append((i, m.group(2) or line, "finding"))
            continue
        m = RE_ID_HEADING.match(line)
        if m and not re.match(r"^\d+[.)]\s+(?:enable|use|ensure|implement|validate|add|disable|apply|restrict|review)\b", line, re.I):
            anchors.append((i, m.group(2), "id"))
            continue
        if RE_SEV_LEAD.match(line) or (RE_SEV_BRACKET.search(line) and len(line) < 140):
            anchors.append((i, line, "sev"))

    findings: List[dict] = []
    prev: Optional[dict] = None
    for n, (start, title, _kind) in enumerate(anchors):
        end = anchors[n + 1][0] if n + 1 < len(anchors) else len(lines)
        block = "\n".join(lines[start:end]).strip()
        clean_title = _tidy_title(title)
        if RE_SECTION_BREAK.match(title.strip()):
            prev = None
            continue
        count, has_sev = _indicator_count(block, title)
        if (has_sev and count >= 2) or count >= 3:
            prev = _new_finding(f"F-{len(findings) + 1:02d}", clean_title, block, "text")
            findings.append(prev)
        elif prev is not None:
            # continuation of the previous finding (e.g. a numbered remediation list)
            merged = prev["excerpt"] + "\n" + block
            rebuilt = _new_finding(prev["id"], prev["title"], merged, "text",
                                   severity=prev["severity"])
            prev.update(rebuilt)
    if findings:
        return findings

    # fallback: "Severity: X" lines with the previous short line as the title
    for i, raw in enumerate(lines):
        m = RE_SEV_LABEL.search(raw)
        if not m:
            continue
        j = i - 1
        while j >= 0 and not lines[j].strip():
            j -= 1
        title = _tidy_title(lines[j]) if j >= 0 and len(lines[j].strip()) < 150 else f"Finding near line {i + 1}"
        block = "\n".join(lines[max(0, j):i + 12])
        findings.append(_new_finding(f"F-{len(findings) + 1:02d}", title, block, "text", severity=_norm_sev(m.group(1))))
    return findings


# ---- structured formats -------------------------------------------------
def _key(k: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(k).lower())


_MAP = {
    "title": ("title", "name", "summary", "issue", "alert", "vulnerability", "rule", "ruleid", "check", "headline", "finding"),
    "severity": ("severity", "risk", "riskdesc", "risklevel", "level", "priority", "rating", "criticality"),
    "description": ("description", "desc", "details", "detail", "message", "text", "synopsis"),
    "remediation": ("remediation", "solution", "recommendation", "recommendations", "fix", "mitigation", "fixrecommendation"),
    "evidence": ("evidence", "poc", "proof", "proofofconcept", "stepstoreproduce", "reproduction", "steps", "attack", "request"),
    "endpoint": ("endpoint", "url", "uri", "path", "location", "affected", "asset", "host", "target", "file"),
    "cvss": ("cvss", "cvssscore", "cvssv3", "cvssv31", "basescore", "score"),
    "vector": ("cvssvector", "vector", "cvssv3vector", "cvssvectorstring"),
}


def _pick(d: dict, field_name: str) -> Any:
    wanted = _MAP[field_name]
    norm = {_key(k): v for k, v in d.items()}
    for w in wanted:
        v = norm.get(w)
        if v not in (None, "", [], {}):
            return v
    return None


def _looks_like_finding(d: dict) -> bool:
    keys = {_key(k) for k in d}
    hits = sum(1 for f in ("title", "severity", "description", "remediation", "cvss") if any(w in keys for w in _MAP[f]))
    return hits >= 2 or ("severity" in keys and hits >= 1)


def _as_text(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False)[:1500]
    return str(v)


def _finding_from_mapping(d: dict, idx: int, source: str) -> dict:
    title = _as_text(_pick(d, "title")) or f"Finding {idx}"
    blob = json.dumps(d, ensure_ascii=False, default=str)[:4000]
    sev_raw = _pick(d, "severity")
    cvss_raw = _pick(d, "cvss")
    cvss = None
    try:
        if cvss_raw is not None:
            cvss = float(str(cvss_raw).split()[0])
            cvss = cvss if 0 <= cvss <= 10 else None
    except ValueError:
        cvss = None
    sev = None
    if isinstance(sev_raw, (int, float)) and cvss is None and 0 <= float(sev_raw) <= 10 and not isinstance(sev_raw, bool):
        cvss = float(sev_raw)
        sev = severity_from_cvss(cvss)
    elif sev_raw is not None:
        m = re.search(_SEV, str(sev_raw), re.I)
        sev = _norm_sev(m.group(1)) if m else None
    evidence = _pick(d, "evidence")
    remediation = _pick(d, "remediation")
    endpoint = _pick(d, "endpoint")
    text_parts = "\n".join(filter(None, [title, _as_text(_pick(d, "description")), _as_text(remediation), _as_text(evidence)]))
    f = _new_finding(
        f"F-{idx:02d}", title[:160], blob if not text_parts else text_parts + "\n" + blob, source,
        severity=sev, cvss=cvss, cvss_vector=(_as_text(_pick(d, "vector")) or None),
        endpoints=_uniq([_as_text(endpoint)] if endpoint else [], 6) or None,
    )
    f["has_remediation"] = bool(remediation) or f["has_remediation"]
    f["has_evidence"] = bool(evidence) or f["has_evidence"]
    f["description"] = " ".join(_as_text(_pick(d, "description") or title).split())[:420]
    return f


def _walk_lists(obj: Any, depth: int = 0) -> Iterable[list]:
    if depth > 5:
        return
    if isinstance(obj, list):
        if obj and all(isinstance(x, dict) for x in obj[:5]) and any(_looks_like_finding(x) for x in obj[:5]):
            yield obj
        else:
            for x in obj[:50]:
                yield from _walk_lists(x, depth + 1)
    elif isinstance(obj, dict):
        for v in obj.values():
            if isinstance(v, (list, dict)):
                yield from _walk_lists(v, depth + 1)


def _sarif_findings(obj: dict) -> List[dict]:
    out: List[dict] = []
    for run in obj.get("runs", []):
        if not isinstance(run, dict):
            continue
        rules = {}
        for r in (run.get("tool", {}).get("driver", {}) or {}).get("rules", []) or []:
            if isinstance(r, dict) and r.get("id"):
                rules[r["id"]] = r
        for res in run.get("results", []) or []:
            if not isinstance(res, dict):
                continue
            rid = str(res.get("ruleId") or "")
            rule = rules.get(rid, {})
            msg = (res.get("message") or {}).get("text") or (rule.get("shortDescription") or {}).get("text") or rid
            level = res.get("level") or (rule.get("defaultConfiguration") or {}).get("level") or "warning"
            props = {**(rule.get("properties") or {}), **(res.get("properties") or {})}
            secsev = props.get("security-severity")
            cvss = None
            sev = _norm_sev(level)
            try:
                if secsev is not None:
                    cvss = float(secsev)
                    sev = severity_from_cvss(cvss)
            except (TypeError, ValueError):
                pass
            locs = []
            for loc in res.get("locations", []) or []:
                pl = (loc or {}).get("physicalLocation", {}) or {}
                uri = (pl.get("artifactLocation") or {}).get("uri")
                line = (pl.get("region") or {}).get("startLine")
                if uri:
                    locs.append(f"{uri}:{line}" if line else uri)
            help_text = (rule.get("help") or {}).get("text") or (rule.get("fullDescription") or {}).get("text") or ""
            blob = f"{rid} {msg} {help_text} " + json.dumps(props, default=str)[:600]
            title = f"{rid}: {msg}" if rid and rid not in msg else msg
            f = _new_finding(f"F-{len(out) + 1:02d}", " ".join(str(title).split())[:160], blob, "sarif",
                             severity=sev, cvss=cvss, endpoints=locs[:5])
            f["has_remediation"] = bool(help_text) or f["has_remediation"]
            f["has_evidence"] = bool(locs)
            f["description"] = " ".join(str(msg).split())[:420]
            out.append(f)
    return out


def _csv_findings(text: str) -> List[dict]:
    try:
        rows = list(csv.DictReader(io.StringIO(text)))
    except csv.Error:
        return []
    rows = [r for r in rows if isinstance(r, dict)][:2000]
    if rows and _looks_like_finding(rows[0]):
        return [_finding_from_mapping(r, i + 1, "csv") for i, r in enumerate(rows)]
    return []


def extract_findings(doc: ParsedDoc) -> List[dict]:
    if doc.kind == "sarif" and isinstance(doc.structured, dict):
        return _sarif_findings(doc.structured)
    if doc.kind == "json-report" and doc.structured is not None:
        for lst in _walk_lists(doc.structured):
            return [_finding_from_mapping(d, i + 1, "json") for i, d in enumerate(lst[:2000]) if isinstance(d, dict)]
        return []
    if doc.kind == "csv-report":
        rows = _csv_findings(doc.text)
        if rows:
            return rows
    return extract_findings_from_text(doc.text)


# ============================================================ secrets in documents
_SECRET_PATTERNS: List[Tuple[str, "re.Pattern"]] = [
    ("AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b")),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_\-]{30,}\b")),
    ("Slack token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b")),
    ("Stripe-style key", re.compile(r"\b[sr]k_(?:live|test)_[A-Za-z0-9]{10,}\b")),
    ("Private key block", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----")),
    ("JWT", re.compile(r"\beyJ[A-Za-z0-9_\-]{8,}\.eyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]*")),
    ("Bearer token", re.compile(r"(?i)\bbearer\s+[A-Za-z0-9\-._~+/]{24,}=*")),
    ("Credential assignment", re.compile(r"(?i)\b(?:api[_-]?key|secret|passwd|password|token)\s*[:=]\s*[\"']?(?![*xX•\.\-]{4,}|\s|<|\{|\$)[A-Za-z0-9/+_\-]{14,}")),
]


def find_secrets(text: str) -> List[str]:
    found: List[str] = []
    for label, rx in _SECRET_PATTERNS:
        if rx.search(text) and label not in found:
            found.append(label)
    return found


def redact_secrets(text: str) -> str:
    """Mask credentials before text is sent to an external LLM provider."""
    for label, rx in _SECRET_PATTERNS:
        tag = "[REDACTED_" + re.sub(r"\W+", "_", label.upper()).strip("_") + "]"
        if label == "Credential assignment":
            text = rx.sub(lambda m: re.split(r"[:=]", m.group(0), 1)[0] + "= " + tag, text)
        else:
            text = rx.sub(tag, text)
    return text


# ============================================================ report-level analysis
_DATE_RE = re.compile(
    r"\b(?:20\d{2}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]20\d{2}|"
    r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+\d{1,2},?\s+20\d{2}|"
    r"\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+20\d{2})\b", re.I)

_DOC_CHECKS = [
    ("summary", "Executive summary", re.compile(r"executive summary|management summary|summary of (?:findings|results)|\boverview\b", re.I),
     "Add a short summary of overall risk and the most important findings."),
    ("scope", "Scope and target definition", re.compile(r"\bscope\b|in[- ]scope|assessed (?:assets|systems|apis?)|systems? (?:tested|assessed)", re.I),
     "State exactly which hosts, APIs and versions were tested (and what was out of scope)."),
    ("method", "Methodology / standards used", re.compile(r"methodolog|testing approach|test(?:ing)? (?:approach|method)|owasp|ptes|nist sp 800-115|asvs", re.I),
     "Describe the methodology or standard (for example OWASP API Security Top 10)."),
    ("date", "Assessment date / test period", None,
     "Record the assessment date or test period (required by the API-STAT policy)."),
    ("rating", "Severity rating scheme", re.compile(r"severity (?:rating|scale|levels?|classification)|risk rating|rating (?:scale|method)|\bcvss\b", re.I),
     "Define how severity is rated (for example CVSS v3.1 bands)."),
    ("confidence", "Confidence / likelihood stated", re.compile(r"confidence|likelihood", re.I),
     "State the confidence or likelihood for findings (required by the API-STAT policy)."),
    ("retest", "Retest / verification status", re.compile(r"\bre-?test|verification (?:status|result)|remediation status|status\s*[:|]\s*(?:open|fixed|resolved|closed|verified)", re.I),
     "Add retest or verification status for critical/high findings (API-STAT policy §4)."),
    ("owner", "Ownership / assignment", re.compile(r"\bowner\b|assigned to|responsible (?:team|party)|due date|target date", re.I),
     "Assign an owner (and ideally a due date) to critical/high findings (API-STAT policy §4)."),
]


def _sev_rank(s: Optional[str]) -> int:
    return SEV_ORDER.index(s) if s in SEV_ORDER else len(SEV_ORDER)


def analyze_report(doc: ParsedDoc) -> dict:
    """Assess a parsed report: findings, consistency, OWASP coverage, completeness vs. policy (cached per document)."""
    if doc._analysis is None:
        doc._analysis = _analyze_report(doc)
    return doc._analysis


def _analyze_report(doc: ParsedDoc) -> dict:
    text = doc.text or ""
    findings = extract_findings(doc)
    total = len(findings)

    by_sev = {s: 0 for s in SEV_ORDER}
    unrated = 0
    for f in findings:
        if f["severity"] in by_sev:
            by_sev[f["severity"]] += 1
        else:
            unrated += 1

    def pct(pred) -> Optional[int]:
        return round(100 * sum(1 for f in findings if pred(f)) / total) if total else None

    coverage_pct = {
        "severity": pct(lambda f: f["severity"] is not None),
        "evidence": pct(lambda f: f["has_evidence"]),
        "remediation": pct(lambda f: f["has_remediation"]),
        "affected_asset": pct(lambda f: bool(f["endpoints"])),
        "references": pct(lambda f: bool(f["cve"] or f["cwe"] or f["owasp"])),
    }

    # --- document-level checks
    checks = []
    doc_hits = 0
    for cid, label, rx, advice in _DOC_CHECKS:
        ok = bool(_DATE_RE.search(text)) if cid == "date" else bool(rx.search(text))
        doc_hits += ok
        checks.append({"id": cid, "label": label, "status": "PASS" if ok else "WARN",
                       "detail": "Found in the report." if ok else advice})

    # --- consistency checks
    issues: List[dict] = []
    for f in findings:
        if f["cvss"] is not None and f["severity"]:
            band = severity_from_cvss(f["cvss"])
            if band != f["severity"]:
                issues.append({"finding": f["id"], "title": f["title"], "type": "severity-vs-cvss",
                               "detail": f"Rated {f['severity']} but CVSS {f['cvss']} falls in the {band} band."})
        if f["cvss_vector"] and f["cvss_computed"] is not None and f["cvss"] is not None \
                and abs(f["cvss"] - f["cvss_computed"]) > 0.2 and f["cvss"] != f["cvss_computed"]:
            issues.append({"finding": f["id"], "title": f["title"], "type": "score-vs-vector",
                           "detail": f"Reported CVSS {f['cvss']} does not match the vector (computes to {f['cvss_computed']})."})
    seen: Dict[str, str] = {}
    for f in findings:
        k = re.sub(r"[^a-z0-9]", "", f["title"].lower())
        if k and k in seen:
            issues.append({"finding": f["id"], "title": f["title"], "type": "duplicate",
                           "detail": f"Same title as {seen[k]} - possible duplicate."})
        elif k:
            seen[k] = f["id"]
    for f in findings:
        if f["severity"] in ("CRITICAL", "HIGH") and not f["has_repro"] and not f["has_evidence"]:
            issues.append({"finding": f["id"], "title": f["title"], "type": "missing-evidence",
                           "detail": "High-impact finding without evidence or reproduction steps (API-STAT policy §4)."})
        if f["severity"] in ("CRITICAL", "HIGH") and not f["has_remediation"]:
            issues.append({"finding": f["id"], "title": f["title"], "type": "missing-remediation",
                           "detail": "High-impact finding without remediation guidance."})

    # --- OWASP mapping via the vector index
    idx = owasp_index()
    mapping: List[dict] = []
    covered: Dict[str, int] = {}
    for f in findings:
        explicit = [o for o in f["owasp"] if o.startswith("API")]
        if explicit:
            for o in explicit:
                covered[o] = covered.get(o, 0) + 1
            mapping.append({"finding": f["id"], "title": f["title"], "category": explicit[0],
                            "score": 1.0, "matched": ["explicit reference"], "explicit": True})
            continue
        q = f"{f['title']} {f['description']} {' '.join(f['cwe'])}"
        hits = idx.query(q, k=1, min_score=0.05)
        if hits:
            h = hits[0]
            label = owasp_label(h.id)
            covered[label] = covered.get(label, 0) + 1
            mapping.append({"finding": f["id"], "title": f["title"], "category": label, "score": h.score,
                            "matched": h.matched[:4], "explicit": False})
        else:
            mapping.append({"finding": f["id"], "title": f["title"], "category": None, "score": 0.0,
                            "matched": [], "explicit": False})
    all_labels = [owasp_label(i) for i in OWASP_IDS]
    not_mentioned = [l for l in all_labels if l not in covered]
    # also honour explicit mentions anywhere in the document text
    mentioned_in_text = {_norm_owasp(m) for m in RE_OWASP.finditer(text) if m.group(0).upper().startswith("API")}
    not_mentioned = [l for l in not_mentioned if l not in mentioned_in_text]

    # --- quality score (documentation completeness, NOT a security score)
    docratio = doc_hits / len(_DOC_CHECKS)
    if total:
        parts = [(coverage_pct["severity"], 15), (coverage_pct["evidence"], 15), (coverage_pct["remediation"], 15),
                 (coverage_pct["affected_asset"], 10), (coverage_pct["references"], 5)]
        findratio = sum((p or 0) * w for p, w in parts) / (sum(w for _, w in parts) * 100)
        score = round(40 * docratio + 60 * findratio)
        partial = False
    else:
        score = round(100 * docratio)
        partial = True

    secrets = find_secrets(text)
    priorities = sorted(findings, key=lambda f: (_sev_rank(f["severity"]), -(f["cvss"] or 0)))[:8]
    all_cves = _uniq((c for f in findings for c in f["cve"]), 25) or _uniq((m.upper() for m in RE_CVE.findall(text)), 25)
    warnings = list(doc.warnings)
    if not total:
        warnings.append("No discrete findings could be identified automatically; only document-level checks were applied.")
    elif doc.kind in ("text",):
        warnings.append("Findings were extracted heuristically from unstructured text - verify them against the source report.")

    return {
        "name": doc.name, "kind": doc.kind, "pages": doc.pages, "chars": len(text), "truncated": doc.truncated,
        "findings": findings, "total": total, "by_severity": by_sev, "unrated": unrated,
        "coverage_pct": coverage_pct, "checks": checks, "issues": issues,
        "owasp_mapping": mapping,
        "owasp_covered": dict(sorted(covered.items())), "owasp_not_mentioned": not_mentioned,
        "quality": {"score": score, "partial": partial},
        "secrets": secrets, "priorities": priorities, "cves": all_cves,
        "cwes": _uniq((c for f in findings for c in f["cwe"]), 25),
        "warnings": warnings,
    }
