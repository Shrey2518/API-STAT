"""Agent capabilities.

Every capability owns a *keyword vector* (its ``keywords``) and optional
deterministic *signals* (a JWT in the message, a CVE id, an attached report ...).
The router vectorises the user's message (plus a digest of any attached report)
into the same TF-IDF space, scores each capability by cosine similarity, adds
its signal, and runs the best matches. Every runner returns the same shape:

    {summary, severity, md, llm, card, actions, kb, skipped?}

``md`` is a Markdown fragment (used when no LLM is configured), ``llm`` is
compact context for the LLM prompt, ``card`` is a structured UI card.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from . import knowledge as kbmod
from .openapi_tools import analyze_openapi, suggest_tests
from .report_ingest import (ParsedDoc, analyze_report, SEV_ORDER, RE_CVE as RI_CVE)
from .security_tools import (CVE_RE, JWT_RE, analyze_headers, analyze_jwt, looks_like_headers,
                             lookup_cve, parse_headers)
from .vectors import TfidfIndex, tokenize

SEV_RANK = {s: i for i, s in enumerate(SEV_ORDER)}
URL_RE = re.compile(r"https?://[^\s<>\"')\]]{4,300}")
ACTION_VERBS = re.compile(r"\b(test|probe|scan|check|inspect|analy[sz]e|assess|headers?|reachab\w*|ping|live|audit|review)\b", re.I)
QUESTION_RE = re.compile(r"\?|^\s*(what|how|why|explain|difference|define|when|which|can|does|do|is|are|should|tell me|describe)\b", re.I)


@dataclass
class Ctx:
    message: str
    history: List[dict] = field(default_factory=list)      # [{role, content}]
    docs: List[ParsedDoc] = field(default_factory=list)
    scan: dict = field(default_factory=dict)               # evidence from Section 4
    policy_sources: List[Tuple[str, str]] = field(default_factory=list)   # [(display name, pdf path)]
    disabled: set = field(default_factory=set)
    live_probe_enabled: bool = True
    results: Dict[str, dict] = field(default_factory=dict)
    query: str = ""                                        # retrieval query (after follow-up rewrite)

    @property
    def text_all(self) -> str:
        """Message plus NEW attachments (documents carried over from earlier turns don't re-trigger tools)."""
        return self.message + "\n" + "\n".join(d.text[:30000] for d in self.docs if not d.carried)


# ------------------------------------------------------------------ helpers
def max_sev(sevs) -> str:
    best = "INFO"
    for s in sevs:
        if s in SEV_RANK and SEV_RANK[s] < SEV_RANK[best]:
            best = s
    return best


def _bullets(items, prefix="- ") -> str:
    return "\n".join(f"{prefix}{i}" for i in items)


_ELLIPTICAL = re.compile(r"\b(it|this|that|they|them|these|those|same|above|previous|again|one)\b|^\s*(and|also|but|so|then|why|how|what about|how about)\b", re.I)


def followup_query(message: str, history: List[dict], has_docs: bool = False) -> str:
    """Resolve short elliptical follow-ups ("how do I fix it?") by borrowing the previous question.
    Self-contained messages, and messages about an attached document, are left alone."""
    terms, _ = tokenize(message, with_bigrams=False)
    if has_docs or len(terms) >= 5 or not _ELLIPTICAL.search(message) or URL_RE.search(message) or JWT_RE.search(message) or CVE_RE.search(message):
        return message
    for turn in reversed(history or []):
        if turn.get("role") == "user" and turn.get("content") and turn["content"].strip() != message.strip():
            return f"{turn['content'][:400]} {message}"
    return message


def kb_search(query: str, k: int = 4):
    """KB retrieval with (a) a title-match boost so specific entries beat generic ones and
    (b) a gentle prior against 'report' entries unless the question is about reports."""
    hits = kbmod.search_kb(query, k=k + 4, min_score=0.06)
    q_terms = {t for t in tokenize(query, with_bigrams=False)[0] if t not in ("api",)}
    about_reports = bool(re.search(r"report|finding|severity|rating|evidence|retest|triage|false positive", query, re.I))
    for h in hits:
        title_terms = set(tokenize(h.payload["title"], with_bigrams=False)[0])
        if q_terms:
            h.score = round(h.score * (1 + 0.8 * len(q_terms & title_terms) / len(q_terms)), 4)
        if h.payload.get("cat") == "report" and not about_reports:
            h.score = round(h.score * 0.7, 4)
    hits.sort(key=lambda h: h.score, reverse=True)
    return hits[:k]


def render_entry(e: dict, full: bool = True) -> str:
    md = [f"### {e['title']}", e["summary"]]
    if full:
        if e["watch"]:
            md += ["", "**What to watch for**", _bullets(e["watch"])]
        if e["test"]:
            md += ["", "**How to test**", _bullets(e["test"])]
        if e["fix"]:
            md += ["", "**How to fix**", _bullets(e["fix"])]
        if e["example"]:
            md += ["", "```python", e["example"], "```"]
        if e["refs"]:
            md += ["", "*References: " + ", ".join(e["refs"]) + "*"]
    return "\n".join(md)


def report_kb_ids(ctx: Ctx, limit: int = 3) -> List[str]:
    """OWASP KB entries for the categories that appear most often in attached reports (used by follow-ups)."""
    counts: Dict[str, int] = {}
    for d in ctx.docs:
        if d.kind == "openapi":
            continue
        for m in analyze_report(d)["owasp_mapping"]:
            if m["category"]:
                counts[m["category"]] = counts.get(m["category"], 0) + 1
    ids = []
    for label, _n in sorted(counts.items(), key=lambda kv: -kv[1]):
        for e in kbmod.KB:
            if e["cat"] == "owasp" and kbmod.owasp_label(e["id"]) == label:
                ids.append(e["id"])
    return ids[:limit]


def _skipped(summary: str, action: str = "") -> dict:
    return {"skipped": True, "summary": summary, "severity": "INFO", "md": "", "llm": "", "card": None,
            "actions": [action] if action else [], "kb": []}


# ------------------------------------------------------------------ policy retrieval (bundled PDF + user PDFs)
BUNDLED_POLICY = Path(__file__).resolve().parent.parent / "docs" / "API-STAT Security Policy.pdf"
_policy_cache: Dict[tuple, TfidfIndex] = {}
_policy_lock = threading.Lock()


def _pdf_chunks(name: str, path: str, max_pages: int = 80) -> List[dict]:
    try:
        from pypdf import PdfReader
        reader = PdfReader(path)
        pages = [(reader.pages[i].extract_text() or "") for i in range(min(len(reader.pages), max_pages))]
    except Exception:
        return []
    chunks: List[dict] = []
    for pno, text in enumerate(pages, 1):
        buf: List[str] = []
        size = 0

        def flush():
            nonlocal buf, size
            body = " ".join(" ".join(buf).split())
            if len(body) > 40:
                chunks.append({"source": name, "page": pno, "text": body[:900]})
            buf, size = [], 0

        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            if re.match(r"^\d\.\s+[A-Z][A-Z &/-]{3,}", line) and buf:
                flush()
            buf.append(line)
            size += len(line)
            if size >= 420:
                flush()
        flush()
    return chunks


def policy_index(sources: List[Tuple[str, str]]) -> TfidfIndex:
    srcs = [("API-STAT Security Policy", str(BUNDLED_POLICY))] + [s for s in sources if s[1] != str(BUNDLED_POLICY)]
    key = []
    for name, path in srcs:
        try:
            key.append((path, os.path.getmtime(path)))
        except OSError:
            continue
    key = tuple(key)
    with _policy_lock:
        if key in _policy_cache:
            return _policy_cache[key]
        idx = TfidfIndex({"text": 1.0})
        n = 0
        for name, path in srcs:
            if not os.path.isfile(path):
                continue
            for i, ch in enumerate(_pdf_chunks(name, path)):
                idx.add(f"{name}#{i}", {"text": ch["text"]}, ch)
                n += 1
        # Standards from the knowledge base give the policy layer OWASP/ASVS/SSDF content even without PDFs.
        for e in kbmod.KB:
            if e["cat"] == "standard":
                idx.add(f"kb:{e['id']}", {"text": e["title"] + " " + e["summary"]},
                        {"source": "Knowledge base", "page": None, "text": e["summary"][:900], "title": e["title"]})
        idx.build()
        if len(_policy_cache) > 8:
            _policy_cache.clear()
        _policy_cache[key] = idx
        return idx


def policy_search(ctx: Ctx, k: int = 3):
    return policy_index(ctx.policy_sources).query(ctx.query or ctx.message, k=k, min_score=0.05)


# ------------------------------------------------------------------ runners
def run_concept(ctx: Ctx) -> dict:
    hits = kb_search(ctx.query, 4)
    hits = [h for h in hits if h.score >= 0.07]
    if not hits:
        return {"summary": "No close match in the knowledge base.", "severity": "INFO", "md": "", "llm": "", "card": None, "actions": [], "kb": [], "skipped": True}
    top = hits[0].payload
    others = [h.payload for h in hits[1:] if h.score >= 0.6 * hits[0].score]
    md = render_entry(top)
    if others:
        md += "\n\n**Related topics:** " + "; ".join(o["title"] for o in others)
    return {
        "summary": f"Best match: {top['title']} ({hits[0].score:.2f})",
        "severity": "INFO", "md": md,
        "llm": "\n\n".join(f"[{h.payload['title']}]\n{h.payload['summary']}\nWatch: {' | '.join(h.payload['watch'][:3])}\nTest: {' | '.join(h.payload['test'][:3])}\nFix: {' | '.join(h.payload['fix'][:3])}" for h in hits[:3]),
        "card": {"type": "kb", "entries": [{"id": h.payload["id"], "title": h.payload["title"], "score": h.score, "matched": h.matched[:5]} for h in hits[:4]]},
        "actions": [], "kb": [h.payload["id"] for h in hits], "top_score": hits[0].score,
    }


def run_owasp(ctx: Ctx) -> dict:
    explicit = re.findall(r"\bAPI(10|[1-9])\b", ctx.message, re.I)
    hits = kbmod.owasp_index().query(ctx.query, k=3, min_score=0.05)
    entries = []
    seen = set()
    for n in explicit:
        for e in kbmod.KB:
            if e["cat"] == "owasp" and e["id"].startswith(f"api{n}-") and e["id"] not in seen:
                seen.add(e["id"])
                entries.append((e, 1.0, ["explicit reference"]))
    for h in hits:
        if h.payload["id"] not in seen:
            seen.add(h.payload["id"])
            entries.append((h.payload, h.score, h.matched))
    if ctx.scan.get("findings"):
        for f in ctx.scan["findings"][:8]:
            for h in kbmod.owasp_index().query(f"{f.get('title','')} {f.get('category','')} {f.get('ai_explanation','')}", k=1, min_score=0.06):
                if h.payload["id"] not in seen:
                    seen.add(h.payload["id"])
                    entries.append((h.payload, h.score, h.matched))
    if not entries:
        return _skipped("No OWASP API Top 10 category matched.")
    entries = entries[:4]
    md = "**OWASP API Security Top 10 (2023) mapping**\n" + "\n".join(
        f"- **{kbmod.owasp_label(e['id'])}** - {e['title'].split(' ', 1)[1]} _(match {s:.2f}: {', '.join(m[:3])})_" for e, s, m in entries)
    return {
        "summary": "Mapped to " + ", ".join(kbmod.owasp_label(e["id"]) for e, _, _ in entries),
        "severity": "INFO", "md": md, "llm": md,
        "card": {"type": "owasp", "items": [{"label": kbmod.owasp_label(e["id"]), "title": e["title"], "score": round(s, 3), "matched": m[:4],
                                              "fix": e["fix"][:2]} for e, s, m in entries]},
        "actions": [], "kb": [e["id"] for e, _, _ in entries],
    }


def run_report(ctx: Ctx) -> dict:
    docs = [d for d in ctx.docs if d.kind != "openapi"]
    if not docs:
        return _skipped("No report attached. Click the + button to attach a PDF, DOCX, JSON, SARIF, HTML or text report.",
                        "Attach the report with the + button so it can be assessed.")
    reports = [analyze_report(d) for d in docs[:3]]
    md_parts, llm_parts, actions, kb_ids, sevs = [], [], [], [], []
    for r in reports:
        sev_line = ", ".join(f"{n} {s.lower()}" for s, n in r["by_severity"].items() if n) or "no rated findings"
        top = max_sev(f["severity"] for f in r["findings"]) if r["findings"] else "INFO"
        sevs.append(top)
        md = [f"### Report assessment - {r['name']}",
              f"**{r['total']} finding(s)** ({sev_line}"
              + (f", {r['unrated']} unrated" if r["unrated"] else "") + f") · documentation completeness **{r['quality']['score']}/100**"
              + (" _(document-level only)_" if r["quality"]["partial"] else "")]
        if r["priorities"]:
            md += ["", "**Highest-priority findings**"]
            for f in r["priorities"][:5]:
                md.append(f"- **{f['severity'] or 'UNRATED'}** {f['title']}" + (f" - CVSS {f['cvss']}" if f["cvss"] is not None else "")
                          + (f" · `{f['endpoints'][0]}`" if f["endpoints"] else ""))
        if r["issues"]:
            md += ["", "**Consistency & quality issues**"]
            for i in r["issues"][:8]:
                md.append(f"- {i['finding']} _{i['title'][:60]}_: {i['detail']}")
        gaps = [c for c in r["checks"] if c["status"] != "PASS"]
        if gaps:
            md += ["", "**Missing report elements (API-STAT policy §4 and good practice)**"]
            md += [f"- {c['label']}: {c['detail']}" for c in gaps]
            actions += [c["detail"] for c in gaps[:3]]
        if r["owasp_covered"]:
            md += ["", "**OWASP API Top 10 coverage:** " + ", ".join(f"{k} ×{v}" for k, v in r["owasp_covered"].items())]
        if r["owasp_not_mentioned"] and r["total"]:
            md.append("_Not mentioned (confirm they were in scope, absence is not proof of safety):_ " + ", ".join(r["owasp_not_mentioned"]))
        if r["secrets"]:
            md += ["", f"**Warning:** the report appears to contain live credentials ({', '.join(r['secrets'])}). Redact before sharing."]
            actions.append("Redact credentials found in the report and rotate them if they were real.")
        for w in r["warnings"]:
            md.append(f"\n_Note: {w}_")
        md_parts.append("\n".join(md))
        llm_parts.append(json.dumps({
            "report": r["name"], "kind": r["kind"], "total_findings": r["total"], "by_severity": r["by_severity"],
            "quality_score": r["quality"], "coverage_pct": r["coverage_pct"], "issues": r["issues"][:10],
            "missing_elements": [c["label"] for c in gaps], "owasp_covered": r["owasp_covered"], "owasp_not_mentioned": r["owasp_not_mentioned"],
            "secrets_in_report": r["secrets"], "warnings": r["warnings"],
            "top_findings": [{k: f[k] for k in ("id", "title", "severity", "cvss", "endpoints", "has_evidence", "has_remediation", "description")} for f in r["priorities"][:6]],
        }, default=str)[:6000])
        for m in r["owasp_mapping"]:
            if m["category"]:
                for e in kbmod.KB:
                    if e["cat"] == "owasp" and kbmod.owasp_label(e["id"]) == m["category"] and e["id"] not in kb_ids:
                        kb_ids.append(e["id"])
        actions += [f"Resolve: {i['detail']}" for i in r["issues"][:2]]
    slim = []
    for r in reports:
        rr = {k: v for k, v in r.items() if k not in ("findings", "priorities")}
        rr["findings"] = [{k: v for k, v in f.items() if k not in ("excerpt",)} for f in r["findings"][:40]]
        slim.append(rr)
    return {
        "summary": "; ".join(f"{r['name']}: {r['total']} finding(s), quality {r['quality']['score']}/100" for r in reports),
        "severity": max_sev(sevs), "md": "\n\n".join(md_parts), "llm": "\n".join(llm_parts),
        "card": {"type": "report", "reports": slim}, "actions": actions[:6], "kb": kb_ids[:4],
    }


def _spec_from_message(msg: str) -> Any:
    if not re.search(r"openapi|swagger", msg, re.I):
        return None
    candidates = re.findall(r"```(?:json|yaml|yml)?\s*\n(.*?)```", msg, re.S) or [msg]
    for c in candidates:
        c = c.strip()
        try:
            obj = json.loads(c)
        except Exception:
            try:
                import yaml
                obj = yaml.safe_load(c) if len(c) < 400_000 else None
            except Exception:
                obj = None
        if isinstance(obj, dict) and isinstance(obj.get("paths"), dict):
            return obj
    return None


def _spec_from_ctx(ctx: Ctx) -> Tuple[Any, str]:
    for d in ctx.docs:
        if d.kind == "openapi":
            return d.structured, d.name
    spec = _spec_from_message(ctx.message)
    return (spec, "pasted spec") if spec else (None, "")


def run_openapi(ctx: Ctx) -> dict:
    spec, name = _spec_from_ctx(ctx)
    if spec is None:
        return _skipped("No OpenAPI/Swagger spec supplied. Attach one with + (JSON or YAML) or paste it.", "Attach an OpenAPI spec with + to review objects, properties and operations.")
    r = analyze_openapi(spec, ctx.message)
    if not r.get("ok"):
        return _skipped(r.get("error", "Could not analyse the spec."))
    top = max_sev(f["severity"] for f in r["findings"]) if r["findings"] else "INFO"
    counts = {s: sum(1 for f in r["findings"] if f["severity"] == s) for s in SEV_ORDER}
    md = [f"### OpenAPI review - {r['title']} ({name})",
          f"**{r['operation_count']} operations** over {r['path_count']} paths · **{r['schema_count']} object schemas** · "
          f"{r['secured_operations']}/{r['operation_count']} operations declare authentication · spec {r['spec_version']}"]
    if r["security_schemes"]:
        md.append("**Security schemes:** " + ", ".join(f"{s['name']} ({s['type']}{'/' + s['detail'] if s['detail'] else ''})" for s in r["security_schemes"]))
    fs = r["focus_schema"]
    if fs:
        md += ["", f"**Object `{fs['name']}` - {fs['property_count']} properties**"]
        md += [f"- `{p['name']}` : {p['type']}" + (f" ({p['format']})" if p["format"] else "") + (" · read-only" if p["readOnly"] else "") + (" · write-only" if p["writeOnly"] else "")
               + (" · **sensitive**" if p["name"] in fs["sensitive"] else "") + (" · **privileged**" if p["name"] in fs["privileged"] else "") for p in fs["properties"][:20]]
    if r["findings"]:
        md += ["", "**Review candidates** (from the contract only - confirm against the running API)"]
        md += [f"- **{f['severity']}** {f['owasp']} - {f['title']} _({f['where'][:50]})_" for f in r["findings"][:12]]
    tests = suggest_tests(r)
    if tests:
        md += ["", "**Suggested tests**"] + [f"- `{t['operation']}`: {t['steps'][0]}" for t in tests[:5]]
    kb_ids = list(dict.fromkeys(next((e["id"] for e in kbmod.KB if e["cat"] == "owasp" and kbmod.owasp_label(e["id"]) == f["owasp"]), None) for f in r["findings"]))
    kb_ids = [k for k in kb_ids if k][:4]
    card = {"type": "openapi", "title": r["title"], "operations": r["operation_count"], "paths": r["path_count"], "schemas": r["schema_count"],
            "secured": r["secured_operations"], "counts": counts, "findings": r["findings"][:25],
            "catalogue": [{k: c[k] for k in ("name", "property_count", "sensitive", "privileged")} for c in r["schemas"][:12]],
            "focus": fs, "tests": tests}
    return {"summary": f"{r['title']}: {r['operation_count']} operations, {len(r['findings'])} review candidate(s)", "severity": top,
            "md": "\n".join(md), "llm": json.dumps({k: r[k] for k in ("title", "operation_count", "schema_count", "secured_operations", "security_schemes")}
                                                   | {"findings": r["findings"][:20], "focus_schema": fs}, default=str)[:6000],
            "card": card, "actions": [f"{f['title']} ({f['where'][:40]})" for f in r["findings"][:3] if f["severity"] in ("HIGH", "CRITICAL")], "kb": kb_ids,
            "_spec_result": r}


def run_jwt(ctx: Ctx) -> dict:
    tokens = list(dict.fromkeys(JWT_RE.findall(ctx.text_all)))[:3]
    if not tokens:
        return _skipped("No JWT found in the message.")
    analyses = [analyze_jwt(t) for t in tokens]
    analyses = [a for a in analyses if a.get("ok")]
    if not analyses:
        return _skipped("The token could not be decoded.")
    md, sevs, actions = [], [], []
    for n, a in enumerate(analyses, 1):
        sevs += [i["severity"] for i in a["issues"]]
        md += [f"### JWT #{n} (decoded locally, signature not verified)",
               f"**Algorithm:** `{a['algorithm']}` · **Status:** {a['status']}",
               "**Header:** `" + json.dumps(a["header"]) + "`", "**Payload:** `" + json.dumps(a["payload"])[:500] + "`", "", "**Findings**"]
        md += [f"- **{i['severity']}** {i['title']} - {i['detail']}" for i in a["issues"]] or ["- No obvious weaknesses in the token itself."]
        actions += [i["fix"] for i in a["issues"] if i["fix"] and i["severity"] in ("CRITICAL", "HIGH")][:2]
    return {"summary": f"{len(analyses)} JWT(s) decoded; worst issue {max_sev(sevs)}", "severity": max_sev(sevs), "md": "\n".join(md),
            "llm": json.dumps([{k: a[k] for k in ("header", "payload", "status", "issues")} for a in analyses], default=str)[:5000],
            "card": {"type": "jwt", "tokens": analyses}, "actions": actions[:3], "kb": ["auth-jwt"]}


def run_headers(ctx: Ctx) -> dict:
    src = ctx.message if looks_like_headers(ctx.message) else next((d.text for d in ctx.docs if looks_like_headers(d.text[:6000])), "")
    if not src:
        return _skipped("No HTTP headers found. Paste raw response headers.")
    headers, status = parse_headers(src)
    a = analyze_headers(headers, status)
    if a["direction"] == "request":
        return {"summary": "Request headers detected.", "severity": "INFO", "md": "\n".join(a["notes"]), "llm": "\n".join(a["notes"]), "card": None, "actions": [], "kb": []}
    bad = [c for c in a["checks"] if c["status"] in ("FAIL", "WARN")]
    md = ["### HTTP response header review" + (f" ({status})" if status else ""),
          f"{a['counts'].get('FAIL', 0)} fail · {a['counts'].get('WARN', 0)} warn · {a['counts'].get('INFO', 0)} info · {a['counts'].get('PASS', 0)} pass", ""]
    md += [f"- **{c['status']}** {c['name']}: {c['detail']}" + (f" -> _{c['fix']}_" if c["fix"] else "") for c in a["checks"] if c["status"] != "PASS"]
    return {"summary": f"{len(bad)} header issue(s)", "severity": "HIGH" if a["counts"].get("FAIL") else "MEDIUM" if a["counts"].get("WARN") else "INFO",
            "md": "\n".join(md), "llm": json.dumps(a["checks"], default=str)[:4000], "card": {"type": "headers", "checks": a["checks"], "counts": a["counts"]},
            "actions": [c["fix"] for c in bad if c["fix"]][:3], "kb": ["cfg-security-headers", "cfg-cors"] if bad else []}


def run_cve(ctx: Ctx) -> dict:
    ids = list(dict.fromkeys(m.upper() for m in CVE_RE.findall(ctx.text_all)))
    for f in ctx.scan.get("findings", []) or []:
        if f.get("cve_id"):
            ids.append(str(f["cve_id"]).upper())
    ids = list(dict.fromkeys(ids))[:5]
    if not ids:
        return _skipped("No CVE identifier found.")
    with ThreadPoolExecutor(max_workers=min(4, len(ids))) as pool:
        rows = list(pool.map(lookup_cve, ids))
    md = ["### CVE intelligence"]
    sevs = []
    for r in rows:
        if r.get("error"):
            md.append(f"- **{r['id']}** - {r['error']}. See {r['url']}")
            continue
        sevs.append(r.get("severity") or "INFO")
        md.append(f"- **{r['id']}** ({r['source']}) - " + (f"CVSS {r['cvss']} **{r['severity']}**" if r.get("cvss") else "no score") + (" · **in CISA KEV (known exploited)**" if r.get("kev") else "")
                  + (f" · {', '.join(r['cwe'])}" if r.get("cwe") else "") + f"\n  {r['summary'][:300]}")
    md.append("\n_CVSS measures severity, not risk to you: check reachability of the affected component and exploitation data (KEV/EPSS)._")
    return {"summary": f"{len(rows)} CVE lookup(s)", "severity": max_sev(sevs), "md": "\n".join(md), "llm": json.dumps(rows, default=str)[:4000],
            "card": {"type": "cve", "items": rows}, "actions": ["Patch KEV-listed or reachable vulnerable components first."] if any(r.get("kev") for r in rows) else [],
            "kb": ["std-cve-cwe-epss-kev", "std-cvss"]}


def run_probe(ctx: Ctx) -> dict:
    if not ctx.live_probe_enabled:
        return _skipped("Live probing from chat is disabled (AGENT_ENABLE_LIVE_PROBE=false).")
    m = URL_RE.search(ctx.message)
    if not m:
        return _skipped("No URL found.")
    url = m.group(0).rstrip(".,;")
    try:
        from .scan_engine import basic_api_config_check
        r = basic_api_config_check(url, 10)
    except Exception as exc:
        msg = str(exc)[:200]
        return {"summary": f"Probe not completed: {msg}", "severity": "INFO", "md": f"### Live probe\nCould not probe `{url}`: {msg}", "llm": f"Probe of {url} failed: {msg}",
                "card": {"type": "probe", "url": url, "error": msg}, "actions": [], "kb": []}
    hdrs = {k: [v] for k, v in (r.get("headers") or {}).items()}
    deep = analyze_headers(hdrs, None, https=r["effective_url"].lower().startswith("https://"))
    bad = [c for c in deep["checks"] if c["status"] in ("FAIL", "WARN")]
    md = [f"### Live probe - `{url}`", f"HTTP {r['status_code']} in {r['response_time_ms']} ms · baseline score **{r['security_score']}/10** (GET + OPTIONS only, no attack payloads)", ""]
    md += [f"- **{c['status']}** {c['name']}: {c['detail']}" + (f" -> _{c['fix']}_" if c["fix"] else "") for c in deep["checks"] if c["status"] != "PASS"] or ["- No header issues observed."]
    md.append("\n_Only probe systems you are authorised to test. For OWASP API probes use Section 4 (deep scan)._")
    return {"summary": f"HTTP {r['status_code']}, {len(bad)} issue(s)", "severity": "HIGH" if deep["counts"].get("FAIL") else "MEDIUM" if bad else "INFO",
            "md": "\n".join(md), "llm": json.dumps({"url": url, "status": r["status_code"], "checks": deep["checks"]}, default=str)[:4000],
            "card": {"type": "probe", "url": url, "status_code": r["status_code"], "ms": r["response_time_ms"], "score": r["security_score"], "checks": deep["checks"]},
            "actions": [c["fix"] for c in bad if c["fix"]][:3], "kb": ["cfg-security-headers"] if bad else []}


def run_policy(ctx: Ctx) -> dict:
    hits = policy_search(ctx, 3)
    if not hits:
        return _skipped("No policy passage matched.")
    md = ["### Policy guidance"] + [f"- **{h.payload.get('title') or h.payload['source']}**"
                                    + (f" (p.{h.payload['page']})" if h.payload.get("page") else "") + f": {h.payload['text'][:320]}" for h in hits]
    return {"summary": f"{len(hits)} policy passage(s) from " + ", ".join(sorted({h.payload['source'] for h in hits})), "severity": "INFO", "md": "\n".join(md),
            "llm": "\n".join(f"[{h.payload['source']}] {h.payload['text'][:500]}" for h in hits),
            "card": {"type": "policy", "items": [{"source": h.payload["source"], "page": h.payload.get("page"), "text": h.payload["text"][:320], "score": h.score, "matched": h.matched[:4]} for h in hits]},
            "actions": [], "kb": []}


def run_evidence(ctx: Ctx) -> dict:
    s = ctx.scan or {}
    if not s:
        return _skipped("No assessment evidence is loaded. Run a scan in Section 4 first.", "Run a live or source assessment in Section 4 to give the agent evidence.")
    fs = s.get("findings") or []
    md = [f"### Current assessment evidence - {s.get('target') or s.get('source_name') or 'API'}"]
    if s.get("security_score") is not None:
        md.append(f"Security score: **{s['security_score']}**/10 · {len(fs)} finding(s) in context")
    md += [f"- {f.get('title') or f.get('rule_id')} ({f.get('category', 'unclassified')}, score {f.get('finding_score', '?')})" for f in fs[:6]]
    return {"summary": f"{len(fs)} finding(s) from the current assessment", "severity": "INFO", "md": "\n".join(md),
            "llm": json.dumps({k: s.get(k) for k in ("target", "security_score", "mode")} | {"findings": [{k: f.get(k) for k in ("title", "category", "finding_score", "endpoint", "cve_id", "ai_explanation")} for f in fs[:8]]}, default=str)[:5000],
            "card": {"type": "evidence", "target": s.get("target"), "score": s.get("security_score"), "findings": [{"title": f.get("title") or f.get("rule_id"), "category": f.get("category"), "score": f.get("finding_score")} for f in fs[:8]]},
            "actions": [], "kb": []}


def run_remediation(ctx: Ctx) -> dict:
    ids: List[str] = report_kb_ids(ctx) if _about_doc(ctx) else []
    for r in ctx.results.values():
        ids += r.get("kb", [])
    if not ids:
        ids += report_kb_ids(ctx)
    ids += [h.payload["id"] for h in kb_search(ctx.query, 3) if h.score >= 0.08]
    ids = [i for i in dict.fromkeys(ids) if kbmod.get_entry(i) and kbmod.get_entry(i)["fix"]][:3]
    if not ids:
        return _skipped("No remediation guidance matched.")
    entries = [kbmod.get_entry(i) for i in ids]
    md = ["### Remediation guidance"]
    for e in entries:
        md += [f"**{e['title']}**", _bullets(e["fix"])]
        if e["example"] and e is entries[0]:
            md += ["", "```python", e["example"], "```"]
        md.append("")
    return {"summary": "Fix guidance for " + ", ".join(e["title"].split(" ")[0] for e in entries), "severity": "INFO", "md": "\n".join(md).strip(),
            "llm": "\n".join(f"[{e['title']}] " + " | ".join(e["fix"]) for e in entries),
            "card": {"type": "fix", "items": [{"title": e["title"], "steps": e["fix"][:4]} for e in entries]}, "actions": [], "kb": ids}


def run_test_plan(ctx: Ctx) -> dict:
    spec_res = (ctx.results.get("openapi_inspector") or {}).get("_spec_result")
    if spec_res:
        tests = suggest_tests(spec_res, 12)
        if tests:
            md = ["### Test plan from the API contract"] + [f"- **`{t['operation']}`**\n" + _bullets(t["steps"], "  - ") for t in tests]
            return {"summary": f"{len(tests)} operation(s) with targeted tests", "severity": "INFO", "md": "\n".join(md), "llm": md and "\n".join(md)[:3000],
                    "card": {"type": "plan", "operations": tests}, "actions": [], "kb": ["test-authz-matrix"]}
    ids = report_kb_ids(ctx) if _about_doc(ctx) else []
    for r in ctx.results.values():
        ids += r.get("kb", [])
    if not ids:
        ids += report_kb_ids(ctx)
    ids += [h.payload["id"] for h in kb_search(ctx.query, 3) if h.score >= 0.08]
    entries = [kbmod.get_entry(i) for i in dict.fromkeys(ids) if kbmod.get_entry(i) and kbmod.get_entry(i)["test"]][:3]
    if not entries:
        return _skipped("No test guidance matched.")
    md = ["### Suggested test plan"]
    for n, e in enumerate(entries, 1):
        md += [f"**{n}. {e['title']}**"] + [f"   {i}. {t}" for i, t in enumerate(e["test"], 1)]
    md.append("\n_Test only systems you are authorised to assess. Record request/response evidence for every result._")
    return {"summary": "Test steps for " + ", ".join(e["title"].split(" ")[0] for e in entries), "severity": "INFO", "md": "\n".join(md),
            "llm": "\n".join(f"[{e['title']}] " + " | ".join(e["test"]) for e in entries),
            "card": {"type": "plan", "topics": [{"title": e["title"], "steps": e["test"]} for e in entries]}, "actions": [], "kb": [e["id"] for e in entries]}


# ------------------------------------------------------------------ registry
@dataclass
class Capability:
    id: str
    name: str
    description: str
    keywords: str                     # the capability's keyword vector (space separated)
    chips: List[str]                  # short keywords shown in the UI
    run: Callable[[Ctx], dict]
    signal: Callable[[Ctx], Tuple[float, str]] = lambda ctx: (0.0, "")
    order: int = 1                    # 1 = independent, 2 = policy, 3 = builds on earlier results
    kind: str = "local"               # local | network
    needs: Optional[Callable[[Ctx], bool]] = None   # capability is only eligible when its input exists


_ASSESS_WORDS = re.compile(r"assess|evaluat|review|validat|audit|quality|complete|missing|gap|lack|weak|consisten|mismatch|inconsisten|duplicate|summar|analy[sz]|coverage|score|priorit|worst|top finding|overview", re.I)


_REFERS_TO_DOC = re.compile(r"\b(?:this|these|those|attached|above|my|the|our)\b(?:\s+\w+){0,3}\s+(?:report|findings?|issues?|vulnerabilit\w+|document|file|pentest|sarif|spec|specification|contract|openapi|swagger)\b", re.I)
_CONCEPT_ASK = re.compile(r"\b(?:what is|what are|what does|explain|define|difference|meaning of|how does)\b", re.I)


def _about_doc(ctx: Ctx) -> bool:
    """True when the user is asking about the attached document rather than a general concept."""
    return bool(ctx.docs) and bool(_REFERS_TO_DOC.search(ctx.message)) and not _CONCEPT_ASK.search(ctx.message)


def _needs_report(ctx: Ctx) -> bool:
    docs = [d for d in ctx.docs if d.kind != "openapi"]
    if not docs:
        return bool(re.search(r"report|pentest|sarif|findings? (?:file|document)", ctx.message, re.I))   # lets us say "attach it with +"
    if any(not d.carried for d in docs):
        return True
    return bool(_ASSESS_WORDS.search(ctx.message))          # follow-up: only when explicitly asked to (re)assess


def _sig_report(ctx):
    if any(d.kind != "openapi" and not d.carried for d in ctx.docs):
        return 1.0, "report attached"
    return 0.0, ""


def _sig_openapi(ctx):
    if any(d.kind == "openapi" and not d.carried for d in ctx.docs):
        return 1.0, "OpenAPI spec attached"
    if _spec_from_message(ctx.message) is not None:
        return 0.9, "spec pasted in message"
    return 0.0, ""


def _sig_jwt(ctx):
    return (1.0, "JWT pattern detected") if JWT_RE.search(ctx.text_all) else (0.0, "")


def _sig_headers(ctx):
    return (0.9, "raw HTTP headers detected") if looks_like_headers(ctx.message) else (0.0, "")


def _sig_cve(ctx):
    if CVE_RE.search(ctx.message):
        return 0.9, "CVE id in message"
    return (0.0, "")


def _sig_probe(ctx):
    if URL_RE.search(ctx.message) and ACTION_VERBS.search(ctx.message):
        return 0.85, "URL + action verb"
    return 0.0, ""


def _sig_evidence(ctx):
    if (ctx.scan.get("findings") or ctx.scan.get("target")) and re.search(r"\b(my|this|current|latest|last|the)\b.*\b(scan|assessment|result|finding|score|evidence)s?\b|\bscan\b|\bassessment\b", ctx.message, re.I):
        return 0.7, "assessment evidence loaded"
    return 0.0, ""


def _sig_re(pattern: str, bonus: float, why: str):
    rx = re.compile(pattern, re.I)
    return lambda ctx: (bonus, why) if rx.search(ctx.message) else (0.0, "")


def _sig_concept(ctx):
    return (0.3, "question form") if QUESTION_RE.search(ctx.message) else (0.0, "")


CAPABILITIES: List[Capability] = [
    Capability("concept_explainer", "API Concept Explainer",
               "Explains API objects, properties, functions, endpoints, HTTP and security concepts from the knowledge base.",
               "what explain difference define object property field function endpoint method parameter schema resource identifier header status code api concept meaning example bola bfla bopla mass assignment cors jwt oauth idor",
               ["OBJECT", "PROPERTY", "FUNCTION", "ENDPOINT", "EXPLAIN"], run_concept, _sig_concept,
               needs=lambda ctx: not _about_doc(ctx)),
    Capability("owasp_mapper", "OWASP API Top 10 Mapper",
               "Maps a described issue or assessment findings to OWASP API Security Top 10 (2023) categories using vector similarity.",
               "owasp top 10 api1 api2 api3 api4 api5 api6 api7 api8 api9 api10 category classify map vulnerability risk weakness which category cwe",
               ["OWASP", "API1-10", "CWE", "CLASSIFY"], run_owasp,
               _sig_re(r"owasp|\bapi(10|[1-9])\b|top ?10|which category|classif", 0.6, "OWASP wording"),
               needs=lambda ctx: not _about_doc(ctx)),
    Capability("report_assessor", "Report Assessor",
               "Parses an attached report (PDF, DOCX, JSON, SARIF, HTML, text), extracts findings, checks CVSS/severity consistency, OWASP coverage and API-STAT policy completeness.",
               "report pentest penetration assessment audit findings attached uploaded evaluate validate review quality severity cvss evidence remediation retest document pdf docx sarif",
               ["REPORT", "FINDINGS", "CVSS", "SARIF", "POLICY"], run_report, _sig_report, needs=_needs_report),
    Capability("openapi_inspector", "OpenAPI Inspector",
               "Reviews an OpenAPI/Swagger contract: objects, sensitive/privileged properties, unauthenticated operations, pagination, SSRF-prone parameters.",
               "openapi swagger spec contract schema schemas components paths operations endpoints properties readonly writeonly security scheme servers definition yaml",
               ["OPENAPI", "SCHEMA", "OPERATIONS", "SECURITY SCHEME"], run_openapi, _sig_openapi),
    Capability("jwt_analyzer", "JWT Analyzer",
               "Decodes a JSON Web Token locally (never verifies or trusts it) and checks algorithm, expiry, audience/issuer and risky claims.",
               "jwt token bearer decode claims header payload alg signature expiry exp iss aud kid jku hs256 rs256 none",
               ["JWT", "ALG", "CLAIMS", "EXP"], run_jwt, _sig_jwt,
               needs=lambda ctx: bool(JWT_RE.search(ctx.text_all))),
    Capability("http_headers_analyzer", "HTTP Header Analyzer",
               "Reviews pasted response headers: HSTS, nosniff, CORS, cookies, cache control, version disclosure and rate-limit signalling.",
               "header headers response hsts csp cors cookie set-cookie samesite httponly secure cache-control nosniff server x-powered-by content-type",
               ["HSTS", "CORS", "COOKIES", "CSP"], run_headers, _sig_headers,
               needs=lambda ctx: looks_like_headers(ctx.message) or any(looks_like_headers(d.text[:6000]) for d in ctx.docs)),
    Capability("cve_intel", "CVE Intelligence",
               "Looks up CVE identifiers (NVD, then OSV) for CVSS, weaknesses and known-exploited status.",
               "cve vulnerability cvss exploit advisory nvd osv kev epss patch dependency library version affected",
               ["CVE", "CVSS", "KEV", "OSV"], run_cve, _sig_cve, kind="network",
               needs=lambda ctx: bool(CVE_RE.search(ctx.text_all)) or any(f.get("cve_id") for f in (ctx.scan.get("findings") or []))),
    Capability("live_probe", "Live HTTP Probe",
               "Non-invasive GET + OPTIONS check of a URL you provide (transport and header controls). No attack payloads.",
               "live probe url endpoint check test scan reachable https tls headers online website api host",
               ["URL", "GET", "OPTIONS", "HEADERS"], run_probe, _sig_probe, kind="network",
               needs=lambda ctx: bool(URL_RE.search(ctx.message))),
    Capability("scan_evidence", "Assessment Evidence",
               "Uses the results of your current Section 4 assessment (score, findings) as grounded evidence.",
               "my scan assessment result results findings score evidence current latest report above this api target",
               ["SCAN", "FINDINGS", "SCORE"], run_evidence, _sig_evidence,
               needs=lambda ctx: bool(ctx.scan)),
    Capability("policy_rag", "Policy RAG",
               "Retrieves passages from the API-STAT Security Policy PDF, your uploaded policy PDFs and OWASP ASVS / NIST SSDF summaries.",
               "policy compliance standard requirement baseline control asvs ssdf nist guideline must should minimum verification governance",
               ["POLICY", "ASVS", "NIST SSDF"], run_policy,
               _sig_re(r"\bpolic(?:y|ies)\b|complian|\basvs\b|\bssdf\b|\bnist\b|baseline|requirement", 0.5, "policy wording"), order=2),
    Capability("remediation_advisor", "Remediation Advisor",
               "Turns matched weaknesses into concrete fixes and secure code examples.",
               "fix remediate remediation mitigate mitigation patch prevent secure code harden recommendation snippet example how to solve",
               ["FIX", "PREVENT", "CODE"], run_remediation,
               _sig_re(r"\bfix|remediat|mitigat|prevent|harden|secure (?:code|version)|recommend|patch|how (?:do|can|should) (?:i|we) (?:secure|protect)", 0.5, "fix wording"), order=3),
    Capability("test_plan_builder", "Test Plan Builder",
               "Builds test steps: per-operation from an OpenAPI spec, or per weakness from the knowledge base.",
               "test plan testing how to test checklist steps reproduce verify attack scenario methodology pentest cases authorization matrix",
               ["TEST PLAN", "CHECKLIST", "REPRODUCE"], run_test_plan,
               _sig_re(r"test (?:plan|cases?|steps)|how (?:do|can|could|should|would|to) (?:i |we |you )?(?:to )?(?:test|verify|reproduce|check|pentest)|checklist|attack scenario|methodology", 0.55, "testing wording"), order=3),
]
BY_ID = {c.id: c for c in CAPABILITIES}

_router: Optional[TfidfIndex] = None
_router_lock = threading.Lock()


def router_index() -> TfidfIndex:
    global _router
    if _router is None:
        with _router_lock:
            if _router is None:
                idx = TfidfIndex({"keywords": 3.0, "name": 1.5, "description": 1.0})
                for c in CAPABILITIES:
                    idx.add(c.id, {"keywords": c.keywords, "name": c.name, "description": c.description}, {"id": c.id})
                _router = idx.build()
    return _router


def public_registry() -> List[dict]:
    return [{"id": c.id, "name": c.name, "description": c.description, "chips": c.chips, "kind": c.kind} for c in CAPABILITIES]


def route(ctx: Ctx, max_selected: int = 5, threshold: float = 0.30) -> Tuple[List[dict], List[Tuple[str, float]]]:
    """Score every capability. Returns (routing rows sorted by score, query top terms)."""
    from .vectors import top_terms
    digest = " ".join(d.text[:6000] for d in ctx.docs)
    idx = router_index()
    msg_hits = {h.id: h for h in idx.query(ctx.query, k=len(CAPABILITIES), min_score=0.0)}
    doc_hits = {h.id: h for h in idx.query(digest, k=len(CAPABILITIES), min_score=0.0)} if digest.strip() else {}
    rows = []
    for c in CAPABILITIES:
        h = msg_hits.get(c.id)
        # The user's question dominates; an attached document contributes at reduced weight.
        vec = min(1.0, (h.score if h else 0.0) * 2.5 + 0.35 * (doc_hits[c.id].score if c.id in doc_hits else 0.0) * 2.5)
        sig, why = c.signal(ctx)
        eligible = c.needs(ctx) if c.needs else True
        score = min(1.0, vec + sig) if eligible else 0.0
        if not eligible:
            why = "input not present"
        rows.append({"id": c.id, "name": c.name, "score": round(score, 3), "vector": round(vec, 3), "signal": round(sig, 3),
                     "matched": (h.matched[:5] if h else []), "reason": why, "disabled": c.id in ctx.disabled, "selected": False})
    rows.sort(key=lambda r: r["score"], reverse=True)
    picked = 0
    # When a specialised capability has clearly claimed the input (strong deterministic signal),
    # secondary capabilities must score higher to join, which keeps answers focused.
    focused = any(r["signal"] >= 0.85 and r["score"] >= 0.85 and not r["disabled"] for r in rows)
    for r in rows:
        if r["disabled"]:
            continue
        need = 0.5 if (focused and r["signal"] < 0.85) else threshold
        if r["score"] >= need and picked < max_selected:
            r["selected"] = True
            picked += 1
    if not any(r["selected"] for r in rows):
        fallback = next((r for r in rows if r["id"] == "concept_explainer" and not r["disabled"]), None)
        if fallback:
            fallback["selected"] = True
            fallback["reason"] = fallback["reason"] or "default capability"
    return rows, top_terms(f"{ctx.query} {ctx.query} {digest[:4000]}", idx, 10)
