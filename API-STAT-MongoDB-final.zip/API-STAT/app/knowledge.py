"""Curated API-security knowledge base.

Each entry describes one concept a security analyst may ask about: what it *is*,
what to *watch for*, how to *test* it, how to *fix* it. Entries are indexed by
``app.vectors`` so the chatbot can retrieve the closest passages (RAG) and can
answer without any external LLM.

Categories
    owasp     OWASP API Security Top 10 (2023)
    object    API objects, identifiers and properties
    function  endpoints, methods, parameters and other API "functions"
    auth      authentication / authorization building blocks
    config    transport, headers, CORS, limits, logging, secrets
    inject    injection and data-handling weaknesses
    standard  standards, scoring and process (CVSS, CVE/CWE, ASVS, SSDF ...)
    report    how to read and judge a security report
"""
from __future__ import annotations

import threading
from typing import Dict, List, Optional

from .vectors import TfidfIndex


def _e(id, cat, title, kw, summary, watch=(), test=(), fix=(), example="", refs=(), related=()):
    return {
        "id": id,
        "cat": cat,
        "title": title,
        "keywords": kw,
        "summary": summary,
        "watch": list(watch),
        "test": list(test),
        "fix": list(fix),
        "example": example.strip("\n"),
        "refs": list(refs),
        "related": list(related),
    }


KB: List[dict] = [
    # ------------------------------------------------------------------ OWASP API Top 10 (2023)
    _e(
        "api1-bola", "owasp", "API1:2023 Broken Object Level Authorization (BOLA / IDOR)",
        "user a user b another user other user's data read someone else's order change the id swap id different account bola idor insecure direct object reference object level authorization object id identifier ownership tenant path parameter access other user data api1",
        "Endpoints that accept an object identifier (for example /orders/1234) must check that the authenticated caller may access that specific object. BOLA is when the server authenticates the caller but never checks ownership, so changing the ID returns someone else's data. It is the most common and most damaging API flaw because every ID-taking endpoint is a potential entry point.",
        watch=[
            "IDs in the path, query string, headers or JSON body (userId, orderId, accountId, tenantId).",
            "Sequential IDs make it easy to exploit, but GUIDs are not a fix - they only make guessing harder.",
            "Check read, update and delete separately, plus nested resources (/users/{id}/invoices/{invoiceId}) and bulk endpoints.",
        ],
        test=[
            "Log in as user A and capture a request for A's object; replay it with user B's token.",
            "Swap IDs in path, query and body; try IDs from another tenant or role.",
            "Compare status codes and bodies (200 vs 403/404); confirm the data really belongs to the other user.",
        ],
        fix=[
            "Enforce an ownership/permission check on every object access in one shared authorization layer (for example WHERE id = :id AND owner_id = :caller).",
            "Derive the caller from the validated token, never from a client-supplied userId.",
            "Use unpredictable IDs as defence in depth and add automated cross-user access tests.",
        ],
        example="""
# Vulnerable: trusts the ID from the URL
@app.get("/api/orders/<int:order_id>")
def get_order(order_id):
    return jsonify(Order.query.get_or_404(order_id).to_dict())

# Fixed: scope the query to the authenticated caller
@app.get("/api/orders/<int:order_id>")
@login_required
def get_order(order_id):
    order = Order.query.filter_by(id=order_id, owner_id=current_user.id).first_or_404()
    return jsonify(order.to_dict())""",
        refs=["OWASP API1:2023", "CWE-639", "CWE-285"],
        related=["obj-identifiers", "api5-bfla", "test-authz-matrix"],
    ),
    _e(
        "api2-broken-auth", "owasp", "API2:2023 Broken Authentication",
        "broken authentication login token jwt session credential stuffing brute force password reset api key weak authentication api2 authenticate identity",
        "Weaknesses in how an API proves who the caller is: missing or weak authentication on endpoints, poor token validation, credential stuffing/brute force, insecure password reset, or long-lived static secrets. Attackers take over accounts or impersonate users.",
        watch=[
            "Endpoints that should require authentication but do not (or accept 'any' token).",
            "JWTs accepted with alg=none, no expiry, wrong issuer/audience, or a weak HMAC secret.",
            "No rate limit or lockout on login, OTP, password-reset or token endpoints; credentials or API keys in URLs.",
        ],
        test=[
            "Call protected endpoints with no token, an expired token, a tampered token and a token for another audience.",
            "Attempt repeated logins/OTP guesses and observe throttling; check error messages for user enumeration.",
            "Review reset and change-password flows for predictable tokens and missing re-authentication.",
        ],
        fix=[
            "Use a proven identity provider or framework; validate signature, algorithm allow-list, exp, nbf, iss and aud on every request.",
            "Rate-limit and monitor authentication endpoints; support MFA for sensitive actions.",
            "Keep credentials out of URLs and logs; rotate keys; hash passwords with Argon2id or bcrypt.",
        ],
        refs=["OWASP API2:2023", "CWE-287", "CWE-306", "CWE-798"],
        related=["auth-jwt", "auth-credential-stuffing", "auth-api-keys", "auth-authn-vs-authz"],
    ),
    _e(
        "api3-bopla", "owasp", "API3:2023 Broken Object Property Level Authorization (BOPLA)",
        "bopla broken object property level authorization mass assignment excessive data exposure property field expose sensitive properties read write api3 object property",
        "Even when a caller may access an object, they may not be allowed to see or change every property of it. BOPLA combines the older 'excessive data exposure' (returning more properties than the client needs) and 'mass assignment' (letting the client set properties it should not, such as role or isAdmin).",
        watch=[
            "Responses that return whole database rows (password hashes, internal flags, other users' emails).",
            "Create/update endpoints that bind the whole JSON body onto a model.",
            "Properties that differ by role (e.g. cost price, internal notes) but are serialised for everyone.",
        ],
        test=[
            "Compare response properties for different roles and against what the UI actually needs.",
            "Add unexpected properties to POST/PUT/PATCH bodies (role, isAdmin, balance, ownerId, verified) and see if they persist.",
            "Look for readOnly/writeOnly mismatches between the OpenAPI spec and real behaviour.",
        ],
        fix=[
            "Return explicit response DTOs/serialisers with an allow-list of properties; never serialise raw models.",
            "Accept only an allow-list of writable properties per role; reject unknown properties.",
            "Mark id, createdAt, role and other server-controlled properties readOnly and enforce it server-side.",
        ],
        example="""
# Vulnerable mass assignment
user = User(**request.get_json())

# Fixed: allow-list writable properties
ALLOWED = {"display_name", "email", "avatar_url"}
data = {k: v for k, v in request.get_json().items() if k in ALLOWED}
user = User(**data)""",
        refs=["OWASP API3:2023", "CWE-915", "CWE-213"],
        related=["data-mass-assignment", "data-excessive-exposure", "obj-property-flags"],
    ),
    _e(
        "api4-resource-consumption", "owasp", "API4:2023 Unrestricted Resource Consumption",
        "unrestricted resource consumption rate limit throttling quota denial of service dos payload size pagination batch cpu memory cost sms email api4 abuse",
        "APIs need CPU, memory, bandwidth and sometimes paid third-party services. Without limits, one client can exhaust them (denial of service) or run up costs (SMS, email, cloud bills).",
        watch=[
            "No rate limit, or a limit that is per-IP only and easy to rotate.",
            "Unbounded page size, huge request bodies, deeply nested JSON/GraphQL, unlimited batch sizes, expensive search/regex.",
            "Endpoints that trigger paid actions (SMS, email, exports, file conversion) without quotas.",
        ],
        test=[
            "Send a controlled burst and look for 429 and Retry-After; test large limit/page_size values.",
            "Send oversized bodies and deeply nested payloads; try batch requests with thousands of items.",
            "Check whether limits apply per user/token/API key and per expensive operation.",
        ],
        fix=[
            "Apply rate limits and quotas per identity and per operation at the gateway and in the app.",
            "Enforce maximum payload size, page size, array length (maxItems), query depth/complexity and timeouts.",
            "Set spending limits and alerts on third-party services.",
        ],
        refs=["OWASP API4:2023", "CWE-770", "CWE-400"],
        related=["cfg-rate-limiting", "fn-pagination", "fn-batch-bulk", "fn-graphql"],
    ),
    _e(
        "api5-bfla", "owasp", "API5:2023 Broken Function Level Authorization (BFLA)",
        "normal user regular user low privilege user access admin endpoint admin function accessible bfla broken function level authorization admin function role privilege escalation permission method tampering administrative endpoint api5 function authorization",
        "A regular user can call a function (endpoint + method) that should be restricted to a privileged role, such as an admin endpoint, a management action, or DELETE on a resource they can only read. Unlike BOLA (which object), BFLA is about *which action*.",
        watch=[
            "Admin or internal paths (/admin, /internal, /manage, /export) protected only by obscurity or client-side hiding.",
            "HTTP method tampering: GET is allowed but PUT/DELETE on the same URL is not checked.",
            "Authorization implemented per-controller by hand, so new endpoints are easy to miss.",
        ],
        test=[
            "Build an authorization matrix of role x endpoint x method and test every cell with each role's token.",
            "Call admin endpoints with a low-privilege token; switch methods (GET->POST/PUT/DELETE) on the same path.",
            "Look for privileged endpoints listed in the OpenAPI spec, JS bundles or error messages.",
        ],
        fix=[
            "Deny by default and enforce role/permission checks centrally (middleware, decorators, policy engine).",
            "Separate administrative APIs (network, host or gateway) from public ones.",
            "Test every new endpoint against the authorization matrix in CI.",
        ],
        refs=["OWASP API5:2023", "CWE-285", "CWE-269"],
        related=["fn-admin-functions", "test-authz-matrix", "api1-bola", "auth-scopes-roles"],
    ),
    _e(
        "api6-business-flows", "owasp", "API6:2023 Unrestricted Access to Sensitive Business Flows",
        "sensitive business flow abuse automation scalping ticket purchase referral coupon comment spam bot api6 business logic",
        "Some legitimate flows (buying a limited product, creating accounts, referrals, posting comments, redeeming coupons) become harmful when automated at scale. The API works as designed, but the business is harmed.",
        watch=["Flows with a scarce resource, money or reputation effect; no friction against bots; flows callable directly without the UI."],
        test=["Automate the flow at scale from one identity and from many; check for device/behaviour checks, CAPTCHA and per-flow limits."],
        fix=[
            "Identify which flows are business-critical and add per-flow limits, step-up checks (CAPTCHA/MFA) and anomaly detection.",
            "Bind sensitive steps to a session, device or prior step so they cannot be replayed out of order.",
        ],
        refs=["OWASP API6:2023", "CWE-799"],
        related=["biz-race-conditions", "biz-enumeration", "cfg-rate-limiting"],
    ),
    _e(
        "api7-ssrf", "owasp", "API7:2023 Server Side Request Forgery (SSRF)",
        "ssrf server side request forgery url parameter callback webhook fetch remote resource metadata internal network cloud metadata 169.254.169.254 redirect api7 request forgery",
        "The API fetches a remote resource using a URL the client controls (image import, webhook, PDF render, link preview). The attacker points it at internal services or cloud metadata endpoints and reads or abuses them through the server.",
        watch=[
            "Parameters named url, uri, link, callback, webhook, redirect, image, feed or target.",
            "Fetchers that follow redirects, or that validate the hostname once and connect later (DNS rebinding).",
            "Responses that return the fetched content or detailed errors back to the caller.",
        ],
        test=[
            "Submit URLs pointing to 127.0.0.1, private ranges, 169.254.169.254 and an attacker-controlled host; observe responses and timing.",
            "Try alternate encodings (decimal/hex IPs, IPv6, DNS names resolving to internal IPs) and redirects to internal targets.",
        ],
        fix=[
            "Prefer an allow-list of destination hosts/schemes; resolve DNS yourself and reject private, loopback and link-local addresses at connect time.",
            "Disable or tightly limit redirects, restrict outbound network egress, and never return raw fetched content or verbose errors.",
            "Require IMDSv2 / metadata protections in cloud environments.",
        ],
        refs=["OWASP API7:2023", "CWE-918"],
        related=["fn-webhooks", "inj-open-redirect", "api10-unsafe-consumption"],
    ),
    _e(
        "api8-misconfiguration", "owasp", "API8:2023 Security Misconfiguration",
        "security misconfiguration tls https cors headers debug verbose error stack trace default credentials unnecessary http methods patch cache api8 configuration hardening",
        "Insecure defaults or inconsistent configuration across the API stack: missing TLS, permissive CORS, debug mode, verbose errors, unneeded HTTP methods, missing security headers, outdated components, or misconfigured cloud storage.",
        watch=["Debug/actuator/console endpoints exposed; stack traces in responses; wildcard CORS; HTTP allowed alongside HTTPS; default credentials; missing patches."],
        test=["Inspect response headers, error responses and OPTIONS results; scan TLS configuration; look for exposed management endpoints and default accounts."],
        fix=[
            "Ship a hardened, repeatable configuration (infrastructure as code) with TLS, minimal HTTP methods, strict CORS and security headers.",
            "Disable debug and verbose errors in production; review config changes in CI; patch regularly.",
        ],
        refs=["OWASP API8:2023", "CWE-16", "CWE-209"],
        related=["cfg-tls", "cfg-security-headers", "cfg-cors", "fn-error-handling"],
    ),
    _e(
        "api9-inventory", "owasp", "API9:2023 Improper Inventory Management",
        "improper inventory management shadow api zombie api deprecated version old version documentation endpoints hosts environments staging debug api9 asset inventory",
        "You cannot protect APIs you do not know about. Old versions, forgotten test/staging hosts, undocumented (shadow) endpoints and deprecated (zombie) APIs often lack the controls of the current version and expose production data.",
        watch=["/v1 still live beside /v2, dev/staging hosts reachable from the internet, endpoints in traffic but not in the spec, unmaintained documentation."],
        test=["Compare the OpenAPI spec against gateway/traffic logs and DNS; probe older versions and common hidden paths; check non-production hosts."],
        fix=[
            "Maintain a living inventory of hosts, versions, endpoints, owners and data flows; retire deprecated versions on a schedule.",
            "Protect non-production environments; generate documentation from code so it cannot drift.",
        ],
        refs=["OWASP API9:2023", "CWE-1059"],
        related=["fn-versioning", "fn-api-gateway", "std-api-stat-policy"],
    ),
    _e(
        "api10-unsafe-consumption", "owasp", "API10:2023 Unsafe Consumption of APIs",
        "unsafe consumption third party api upstream integration trust webhook response validation partner service supply chain api10 external api",
        "Developers often trust data from third-party APIs more than user input. If an upstream service (or an attacker who compromises it) returns malicious data, redirects, or oversized responses, your API may be attacked through it.",
        watch=["Third-party responses used in SQL/commands/templates without validation; blindly following redirects; missing TLS validation; no timeouts or size limits."],
        test=["Mock the upstream to return malicious, malformed, oversized and slow responses and observe your API's behaviour."],
        fix=[
            "Treat upstream data as untrusted input: validate against a schema, encode on output, enforce TLS, timeouts, size limits and redirect limits.",
            "Evaluate and monitor third-party providers as part of supply-chain risk management.",
        ],
        refs=["OWASP API10:2023", "CWE-20"],
        related=["api7-ssrf", "obj-schema-validation", "std-sbom-dependencies"],
    ),

    # ------------------------------------------------------------------ API objects & properties
    _e(
        "obj-api-object", "object", "API objects (resources)",
        "api object resource entity model user order invoice record data json representation what is an api object resource collection",
        "An API object (resource) is a data entity the API exposes - a user, an order, an invoice - usually represented as JSON with an identifier and a set of properties. Endpoints are the functions that create, read, update or delete objects. Most serious API flaws are about who may touch which object (BOLA) and which properties of it (BOPLA).",
        watch=["Every object type needs an owner/tenant and an access rule; every relationship between objects (user -> orders) is a place where checks get skipped."],
        test=["List the object types from the spec or traffic and, for each, note who owns it, who may read/change it and which endpoints reach it."],
        fix=["Model authorization per object type, centrally, and expose objects through explicit response schemas."],
        related=["obj-identifiers", "obj-properties", "api1-bola", "fn-endpoint-operation"],
    ),
    _e(
        "obj-identifiers", "object", "Object identifiers (IDs)",
        "object id identifier uuid guid sequential guessable numeric id path parameter enumerate primary key reference",
        "An object identifier is the value clients use to reference an object (numeric ID, UUID, slug). Identifiers are not secrets and are not a security control: guessing is only the second step - the real defence is an authorization check on every access.",
        watch=["Sequential integers that allow enumeration; IDs of other users leaked in lists, logs or URLs; IDs accepted from the body that override the token's identity."],
        test=["Collect IDs you legitimately own, then request neighbours and other users' IDs; look for IDs leaked in list responses."],
        fix=["Authorize every ID against the caller; use random UUIDs/ULIDs for external references as defence in depth; never trust a client-supplied owner ID."],
        related=["api1-bola", "obj-api-object"],
    ),
    _e(
        "obj-properties", "object", "Object properties (fields / attributes)",
        "object property properties field attribute key value json member column what is a property api property type string number boolean nested",
        "A property is one named value on an API object (email, role, balance, createdAt). Each property has a type, may be required or optional, may be writable or server-controlled, and may be visible only to some roles. Properties are where data exposure and privilege escalation actually happen.",
        watch=["Properties that hold secrets or personal data; properties that control authorization (role, isAdmin, permissions, ownerId, tenantId); properties that control money or state (price, balance, status)."],
        test=["Diff responses across roles; try to set every property on create/update; check what the spec says vs what the API accepts."],
        fix=["Define request and response schemas per role, allow-list writable properties and never return properties the client does not need."],
        related=["obj-property-flags", "obj-sensitive-properties", "api3-bopla"],
    ),
    _e(
        "obj-property-flags", "object", "Read-only, write-only and server-controlled properties",
        "readonly read only writeonly write only server controlled property immutable id createdat password mass assignment openapi flag",
        "Some properties must never be set by clients (id, createdAt, role, ownerId - readOnly), and some must never be returned (password, secret - writeOnly). OpenAPI can declare readOnly and writeOnly, but the server must enforce them; the spec is documentation, not protection.",
        watch=["Create/update endpoints that bind the whole body; responses that echo writeOnly values; specs that say readOnly while the API accepts the value."],
        test=["Send readOnly properties in POST/PUT/PATCH and check whether they change; look for writeOnly properties in any response."],
        fix=["Bind requests to DTOs that omit server-controlled properties and serialise responses through DTOs that omit writeOnly ones."],
        refs=["CWE-915"],
        related=["data-mass-assignment", "obj-properties", "api3-bopla"],
    ),
    _e(
        "obj-sensitive-properties", "object", "Sensitive and internal properties",
        "returns password hash in response leaks exposed field in response body sensitive property password hash token secret api key ssn credit card cvv iban internal flag isadmin role permission personal data pii exposure",
        "Sensitive properties are those whose exposure or modification causes harm: credentials and secrets (password, passwordHash, token, apiKey), regulated data (SSN, card numbers, health data), and authorization/business flags (isAdmin, role, permissions, price, balance, verified).",
        watch=["Names such as password, secret, token, apiKey, ssn, card, cvv, iban, role, isAdmin, permissions, balance, price, verified, internalNotes appearing in response or request schemas."],
        test=["Search the OpenAPI spec and real responses for these names; verify they are absent from responses (or masked) and cannot be set by low-privilege callers."],
        fix=["Remove from responses, mask or tokenise; mark writeOnly/readOnly; restrict writes to privileged roles; encrypt at rest and exclude from logs."],
        related=["data-excessive-exposure", "data-personal-data", "api3-bopla"],
    ),
    _e(
        "obj-nested-expand", "object", "Nested objects, relationships and expansion",
        "nested object relationship expand include embed graphql field selection join related resource depth n+1 sub resource",
        "Objects often embed or link to other objects (an order contains customer and items). Query options such as ?expand=, ?include= or GraphQL field selection let clients pull related objects in one call. Each expanded object needs its own authorization check, otherwise expansion becomes a BOLA/BOPLA bypass.",
        watch=["Expansion that returns the related object without checking access to it; unbounded depth; different rules on the parent and child endpoints."],
        test=["Expand every relation on an object you own and check that related objects owned by others never appear; test depth limits."],
        fix=["Authorize each object in the graph, cap expansion depth, and use explicit allow-lists of expandable relations."],
        related=["api1-bola", "api3-bopla", "fn-graphql"],
    ),
    _e(
        "obj-schema-validation", "object", "Schemas and input validation",
        "schema validation json schema input validation type length format pattern enum minimum maximum allow list reject unknown additionalproperties openapi maxlength",
        "A schema describes the expected shape of a request or response: property names, types, required fields, formats and limits. Validating every request against the schema (and rejecting unknown properties) stops whole classes of injection, mass-assignment and resource-exhaustion problems early.",
        watch=["Strings without maxLength/pattern/enum, arrays without maxItems, numbers without minimum/maximum, additionalProperties left open, validation only on the client."],
        test=["Send wrong types, oversized values, negative numbers, nulls, extra properties and malformed JSON; confirm consistent 400/422 responses without stack traces."],
        fix=["Validate server-side against a strict schema (allow-list), set length/range limits, reject unknown properties and normalise input before use."],
        refs=["CWE-20"],
        related=["fn-parameters", "data-mass-assignment", "api4-resource-consumption"],
    ),

    # ------------------------------------------------------------------ API functions, endpoints, HTTP
    _e(
        "fn-endpoint-operation", "function", "Endpoints, operations and API functions",
        "endpoint operation function route path method operationid resource action what is an api function api endpoint verb url",
        "An endpoint is a URL path; an operation (API function) is an HTTP method on that path - for example GET /orders/{id} and DELETE /orders/{id} are two different functions with different risks. OpenAPI identifies each with an operationId. Security must be decided per operation, not per path.",
        watch=["Paths where some methods are protected and others are not; undocumented operations; state-changing functions reachable with GET."],
        test=["For every path try every method; compare the spec with observed behaviour; look for hidden functions in JS bundles and error messages."],
        fix=["Declare and enforce authentication and authorization per operation; disable methods you do not use."],
        related=["fn-http-methods", "api5-bfla", "fn-admin-functions"],
    ),
    _e(
        "fn-http-methods", "function", "HTTP methods (GET, POST, PUT, PATCH, DELETE, OPTIONS)",
        "http method get post put patch delete options head trace safe idempotent verb tampering crud what does mean",
        "GET reads, POST creates or triggers actions, PUT replaces, PATCH partially updates, DELETE removes, HEAD returns headers only, OPTIONS describes allowed methods (CORS preflight). GET, HEAD and OPTIONS are *safe* (no state change); GET, HEAD, OPTIONS, PUT and DELETE are *idempotent* (repeating has the same effect). POST and PATCH are not idempotent by definition.",
        watch=["State changes behind GET (CSRF/prefetch risk); TRACE enabled; method override headers (X-HTTP-Method-Override) that bypass checks; authorization applied to some methods only."],
        test=["Send every method to every path and compare status codes; try method-override headers; inspect the Allow header from OPTIONS."],
        fix=["Allow only required methods per path, return 405 with Allow otherwise, and apply the same authorization to every method."],
        related=["fn-endpoint-operation", "fn-idempotency", "api5-bfla"],
    ),
    _e(
        "fn-idempotency", "function", "Idempotency and safe requests",
        "idempotency idempotent idempotency key retry duplicate request replay safe method double submit payment",
        "An idempotent operation gives the same result when repeated. This matters for retries and for security: without idempotency keys, a retried or replayed POST (payment, transfer, coupon) can be applied twice.",
        watch=["Payments, transfers or redemptions that accept the same request twice; retries after timeouts that create duplicates."],
        test=["Replay the same POST twice and in parallel; check that the second is rejected or returns the first result."],
        fix=["Require an Idempotency-Key for unsafe operations, store the result server-side and use unique constraints/transactions."],
        related=["biz-race-conditions", "fn-http-methods"],
    ),
    _e(
        "fn-admin-functions", "function", "Administrative and privileged functions",
        "admin administrative privileged function internal management endpoint debug actuator backoffice role elevate export delete user impersonate",
        "Administrative functions (create users, change roles, export data, impersonate, manage keys, debug) are the highest-value targets. They must be authorised by role or permission on the server, ideally exposed on a separate host or gateway from the public API.",
        watch=["Paths like /admin, /internal, /manage, /actuator, /debug, /export; functions protected by 'hidden URL' only; admin actions callable with a normal token."],
        test=["Call each privileged function with a normal user's token and with no token; look for them in the spec, JS files and robots/sitemap."],
        fix=["Deny by default, require an explicit privileged role/permission, separate admin APIs, audit-log every use and require step-up authentication."],
        related=["api5-bfla", "test-authz-matrix", "auth-scopes-roles"],
    ),
    _e(
        "fn-batch-bulk", "function", "Batch and bulk operations",
        "batch bulk operation array many items import export multiple ids graphql batching mass request bypass rate limit",
        "Batch endpoints accept many items or many operations in one request. They multiply BOLA/BFLA risk (one authorised ID hides ten unauthorised ones), bypass per-request rate limits and can exhaust resources.",
        watch=["Arrays of IDs or operations; GraphQL batching/aliases; import/export endpoints; per-request rate limits."],
        test=["Mix owned and foreign IDs in one batch; send very large batches; use GraphQL aliases to repeat a sensitive operation."],
        fix=["Authorise every element, cap batch size, and count each item against rate limits and quotas."],
        related=["api1-bola", "api4-resource-consumption", "fn-graphql"],
    ),
    _e(
        "fn-parameters", "function", "Parameters: path, query, header, cookie and body",
        "parameter path query string header cookie body request body argument input untrusted user controlled param name in openapi",
        "Every value a client sends is untrusted input. Path parameters identify resources, query parameters filter and paginate, headers carry metadata and credentials, cookies carry sessions, and the body carries the object. OpenAPI records each parameter's location (in: path/query/header/cookie) and schema.",
        watch=["Identity or role taken from a header/body instead of the token; parameters reflected in errors; duplicate parameters handled differently by different layers."],
        test=["Fuzz each parameter with wrong types, boundary values and special characters; move values between locations; send duplicates."],
        fix=["Validate each parameter against a schema, take identity only from the validated token and treat every location as untrusted."],
        related=["obj-schema-validation", "inj-hpp", "inj-sql"],
    ),
    _e(
        "fn-search-filter-sort", "function", "Filtering, sorting and search parameters",
        "filter sort order by search query parameter field selection sql injection expensive query orderby limit column allow list",
        "Filter, sort and search parameters are turned into database queries. If field names or operators are taken from the client unchecked, they enable injection, data leakage through filtering on hidden properties, and expensive queries.",
        watch=["?sort=, ?filter[...], ?fields=, free-form search, operators like $where or regex; filtering on properties the caller cannot read."],
        test=["Filter or sort on hidden/sensitive properties; inject special characters; submit expensive patterns."],
        fix=["Allow-list sortable/filterable fields and operators, parameterise queries, and apply the same property-level authorization to filters as to responses."],
        related=["inj-sql", "inj-nosql", "api4-resource-consumption"],
    ),
    _e(
        "fn-pagination", "function", "Pagination and result limits",
        "pagination page size limit offset cursor per page max results list endpoint unbounded collection total count",
        "Pagination splits large collections into pages (offset/limit or cursor). Without an enforced maximum, one call can return the entire table - a resource-consumption and data-exposure risk.",
        watch=["List endpoints with no limit parameter or a very high maximum; huge offsets; totals that reveal data volume."],
        test=["Request limit=100000 and limit=-1; page beyond the end; check response size and time."],
        fix=["Set a default and a hard maximum page size, prefer cursor pagination and apply authorization before paginating."],
        related=["api4-resource-consumption", "fn-search-filter-sort"],
    ),
    _e(
        "fn-versioning", "function", "API versioning and deprecation",
        "api version versioning v1 v2 deprecated deprecation sunset old version retire header path inventory zombie",
        "Versions let an API evolve without breaking clients (/v1, /v2 or a header). Each live version is attack surface: old versions often miss fixes made to newer ones.",
        watch=["Old versions still routable; deprecated operations with no removal date; inconsistent auth between versions."],
        test=["Try older version prefixes and compare authorization and validation behaviour with the current version."],
        fix=["Publish a deprecation policy (Sunset header), monitor use of old versions and remove them on schedule."],
        related=["api9-inventory", "fn-api-gateway"],
    ),
    _e(
        "fn-status-codes", "function", "HTTP status codes (401 vs 403 vs 404 and others)",
        "status code http response 400 401 403 404 405 409 415 422 429 500 unauthorized forbidden not found too many requests unprocessable meaning difference",
        "2xx success, 3xx redirect, 4xx client error, 5xx server error. Key API cases: 400 malformed request; 401 not authenticated (missing/invalid credentials, should send WWW-Authenticate); 403 authenticated but not permitted; 404 not found (also used to avoid revealing that an object exists); 405 method not allowed (send Allow); 409 conflict; 415 unsupported media type; 422 semantically invalid; 429 too many requests (send Retry-After); 500 unhandled server error.",
        watch=["200 with an error body; 500 with stack traces; different codes/timings that reveal whether a user or object exists; 401/403 mixed up."],
        test=["Compare responses for: no token, bad token, valid token without permission, missing object, other user's object."],
        fix=["Use codes consistently, return generic error bodies and treat 500s as bugs to fix."],
        related=["fn-error-handling", "auth-authn-vs-authz", "biz-enumeration"],
    ),
    _e(
        "fn-error-handling", "function", "Error handling and information disclosure",
        "error handling verbose error stack trace exception message debug information disclosure sql error framework version leak generic error response",
        "Error responses should help legitimate clients without helping attackers. Stack traces, SQL errors, framework versions, file paths and internal hostnames in responses are information disclosure and make other attacks easier.",
        watch=["Stack traces or debug pages; database errors echoed to the client; different messages for 'user not found' vs 'wrong password'."],
        test=["Trigger errors with malformed JSON, wrong types, huge values and unsupported methods; read the full body and headers."],
        fix=["Return a generic, structured error (code, message, correlation ID); log details server-side; disable debug in production."],
        refs=["CWE-209"],
        related=["api8-misconfiguration", "fn-status-codes"],
    ),
    _e(
        "fn-content-types", "function", "Content types and content negotiation",
        "content type content-type accept json xml form multipart charset media type negotiation 415 sniffing xxe parser",
        "Content-Type states how a request/response body is encoded; Accept states what the client wants. APIs that accept several formats (JSON, XML, forms) expose more parsers - and XML parsers bring XXE risk. Wrong response types can enable content sniffing.",
        watch=["Endpoints that silently accept XML or form data as well as JSON; missing Content-Type on responses; missing nosniff."],
        test=["Send the same request as JSON, XML and form-encoded; send a wrong Content-Type and check for 415."],
        fix=["Accept only the content types you document, reject others with 415, set Content-Type and X-Content-Type-Options: nosniff on responses."],
        related=["inj-xxe", "cfg-security-headers"],
    ),
    _e(
        "fn-file-upload", "function", "File upload endpoints",
        "file upload multipart image document avatar attachment filename content type size malware storage path traversal",
        "Upload endpoints accept attacker-controlled bytes and names. Risks: executable or script uploads, path traversal in filenames, oversized files, malware, and stored content served back with a dangerous type.",
        watch=["Trusting the client's filename or Content-Type; no size limit; files stored in a web-served directory."],
        test=["Upload oversized files, double extensions, path-traversal names and content that does not match the declared type."],
        fix=["Validate type by content, cap size, generate server-side names, store outside the web root/object storage, scan for malware and serve with nosniff and download disposition."],
        related=["inj-path-traversal", "api4-resource-consumption"],
    ),
    _e(
        "fn-webhooks", "function", "Webhooks and callbacks",
        "webhook callback notification event delivery signature hmac replay secret subscribe url register endpoint ssrf",
        "Webhooks let your API call a client-supplied URL when something happens. They create SSRF risk (the server makes requests to attacker-chosen URLs) and, on the receiving side, need authenticity checks.",
        watch=["Registration of arbitrary callback URLs; no signature on delivered events; no replay protection."],
        test=["Register internal or metadata URLs; check redirects; verify signature and timestamp handling on receipt."],
        fix=["Validate and restrict callback destinations, sign payloads (HMAC + timestamp), verify signatures on receipt and use per-subscriber secrets."],
        related=["api7-ssrf", "api10-unsafe-consumption"],
    ),
    _e(
        "fn-graphql", "function", "GraphQL security",
        "graphql query mutation introspection depth complexity batching alias resolver field level authorization schema gql rest difference",
        "GraphQL exposes one endpoint where the client chooses fields and can nest and batch queries. Main risks: introspection revealing the whole schema, unbounded query depth/complexity, alias/batch abuse to bypass rate limits, and missing authorization at resolver/field level.",
        watch=["Introspection enabled in production; no depth/cost limits; auth only at the HTTP layer; batching allowed without limits."],
        test=["Run an introspection query; send deeply nested and alias-heavy queries; request fields you should not see; brute-force logins through aliases."],
        fix=["Enforce authorization in every resolver/field, limit depth, complexity and batch size, disable introspection where not needed and use persisted queries."],
        related=["api4-resource-consumption", "obj-nested-expand", "fn-batch-bulk"],
    ),
    _e(
        "fn-grpc-websocket", "function", "gRPC and WebSocket APIs",
        "grpc websocket ws protobuf streaming reflection origin cswsh interceptor realtime socket message",
        "gRPC and WebSocket APIs are long-lived, message-based channels. Authorization must be checked per message, not only at connect time. WebSockets also need Origin checks (cross-site WebSocket hijacking); gRPC needs TLS, auth interceptors and reflection disabled in production.",
        watch=["Authentication only at connect time; missing Origin validation; gRPC reflection exposed; no message size limits."],
        test=["Send unauthorised messages after connecting; connect from a foreign Origin; call gRPC methods with another user's token."],
        fix=["Authorise every message/method, validate Origin, use TLS, cap message size and rate, and disable reflection in production."],
        related=["api5-bfla", "api4-resource-consumption"],
    ),
    _e(
        "fn-api-gateway", "function", "API gateway",
        "api gateway proxy waf edge routing rate limit authentication offload central policy kong apigee envoy nginx",
        "An API gateway is the front door that routes requests and applies shared policy - TLS termination, authentication, rate limits, schema validation and logging. It reduces duplicated checks but does not replace per-object authorization, which only the application can decide.",
        watch=["Direct access to backends bypassing the gateway; gateway-only auth with no backend checks; inconsistent policy between routes."],
        test=["Reach backend hosts directly; send requests with spoofed forwarding headers; compare behaviour with and without the gateway."],
        fix=["Restrict backends to gateway traffic (network policy/mTLS), keep object-level checks in the application and manage gateway config as code."],
        related=["api9-inventory", "cfg-rate-limiting"],
    ),

    # ------------------------------------------------------------------ Authentication & authorization
    _e(
        "auth-authn-vs-authz", "auth", "Authentication vs authorization",
        "authentication authorization difference authn authz identity permission 401 403 access control who are you what can you do",
        "Authentication (authn) proves who the caller is; authorization (authz) decides what that caller may do. An API can authenticate everyone perfectly and still be broken if it never checks authorization - BOLA, BFLA and BOPLA are all authorization failures.",
        watch=["'Logged in' treated as 'allowed'; authorization implemented only in the UI; checks that depend on client-supplied data."],
        test=["Use valid tokens of different users/roles against each other's objects and functions."],
        fix=["Authenticate once at the edge, authorize on every request at object, function and property level on the server."],
        related=["api1-bola", "api5-bfla", "api3-bopla", "fn-status-codes"],
    ),
    _e(
        "auth-api-keys", "auth", "API keys",
        "api key apikey x-api-key secret static key header query rotate leak identify application client key management",
        "An API key identifies the calling *application* (and often its plan), not the *user*. It is a shared secret: anyone holding it is the client. Keys are fine for identification and quota, but weak for user-level authorization.",
        watch=["Keys in URLs (they land in logs and history), in source control or mobile apps; one key shared by many clients; no rotation or revocation."],
        test=["Search repos and client bundles for keys; check whether a key alone grants user data; test revoked/rotated keys."],
        fix=["Send keys in headers, store them in a secret manager, scope and rotate them, and use OAuth/OIDC tokens for user-level access."],
        refs=["CWE-798", "CWE-598"],
        related=["auth-oauth2", "cfg-secrets", "api2-broken-auth"],
    ),
    _e(
        "auth-jwt", "auth", "JSON Web Tokens (JWT)",
        "jwt json web token header payload claims signature alg none hs256 rs256 exp iss aud kid jku bearer decode validate signing key confusion",
        "A JWT is three base64url parts - header.payload.signature. It is *signed*, not encrypted: anyone can read the payload. Security depends on the server validating the signature with an allow-listed algorithm and checking exp, nbf, iss and aud on every request.",
        watch=[
            "alg=none or an algorithm taken from the token; RS256/HS256 key confusion; weak HMAC secrets.",
            "No exp or very long lifetime; missing iss/aud checks; roles trusted from the token with no server-side check.",
            "Header injection via kid, jku, x5u or jwk pointing to attacker-controlled keys; secrets or PII in the payload.",
        ],
        test=[
            "Decode the token (base64url) and inspect claims; change a claim and resend; try alg=none and an empty signature.",
            "Use an expired token and a token for another audience; try to crack weak HS256 secrets offline (authorised testing only).",
        ],
        fix=[
            "Pin the accepted algorithms, validate signature, exp, nbf, iss and aud, and use strong asymmetric keys with rotation.",
            "Keep tokens short-lived with refresh-token rotation; do not put secrets in claims and keep authorization decisions server-side.",
        ],
        refs=["RFC 7519", "RFC 8725 (JWT BCP)", "CWE-347"],
        related=["api2-broken-auth", "auth-oauth2", "auth-scopes-roles"],
    ),
    _e(
        "auth-oauth2", "auth", "OAuth 2.0 and OpenID Connect",
        "oauth oauth2 openid oidc authorization code pkce implicit client credentials refresh token scope redirect uri state access token id token flow grant",
        "OAuth 2.0 delegates access: a client obtains an access token from an authorization server and presents it to a resource server (the API). OpenID Connect adds an ID token that says who signed in. Use Authorization Code with PKCE for user flows and Client Credentials for service-to-service; avoid implicit and password grants.",
        watch=["Loose redirect_uri matching; missing state/PKCE; tokens without audience restriction; long-lived access tokens; scopes mistaken for authorization; ID tokens used as access tokens."],
        test=["Tamper with redirect_uri and state; replay authorization codes; use a token issued for another API; check scope enforcement."],
        fix=["Exact-match redirect URIs, require PKCE, restrict token audience and lifetime, validate scopes server-side and rotate refresh tokens."],
        refs=["RFC 6749", "RFC 7636", "OpenID Connect Core"],
        related=["auth-jwt", "auth-scopes-roles", "api2-broken-auth"],
    ),
    _e(
        "auth-sessions-cookies", "auth", "Sessions and cookies",
        "session cookie httponly secure samesite csrf set-cookie session fixation cookie flags cross site request forgery browser",
        "Browser-based APIs often use cookies for sessions. Cookies are sent automatically, so they need Secure (HTTPS only), HttpOnly (not readable by scripts) and SameSite (limits cross-site sending), plus CSRF protection for state-changing requests.",
        watch=["Session cookies without Secure/HttpOnly/SameSite; session IDs in URLs; no rotation after login; state-changing GET requests."],
        test=["Inspect Set-Cookie flags; check whether the session ID changes at login and logout; try cross-site requests without a CSRF token."],
        fix=["Set Secure, HttpOnly and SameSite=Lax/Strict, rotate session IDs at login, use CSRF tokens or SameSite plus custom headers."],
        refs=["CWE-352", "CWE-614", "CWE-1004"],
        related=["cfg-cors", "cfg-security-headers"],
    ),
    _e(
        "auth-scopes-roles", "auth", "Scopes, roles, claims and permissions",
        "scope scopes role roles claim claims permission permissions rbac abac policy least privilege entitlement access control model",
        "Roles group permissions (RBAC); attributes and context drive decisions in ABAC; OAuth scopes describe what a token may do on behalf of a user. A scope says a token is *allowed to attempt* something - the API must still check that this user may do it to this object.",
        watch=["Roles or scopes trusted from client-side data; overly broad 'admin' or '*' scopes; no separation between read and write permissions."],
        test=["Use tokens with minimal scopes against every endpoint; escalate by editing claims or requesting extra scopes."],
        fix=["Apply least privilege, define scopes per operation, and enforce roles, scopes and ownership together on the server."],
        related=["api5-bfla", "auth-oauth2", "auth-jwt"],
    ),
    _e(
        "auth-credential-stuffing", "auth", "Credential stuffing, brute force and account takeover",
        "credential stuffing brute force password spraying lockout account takeover login rate limit captcha otp mfa breached password enumeration",
        "Attackers replay leaked username/password pairs (credential stuffing) or guess passwords/OTPs (brute force) against login and reset endpoints. Success depends on missing rate limits, predictable OTPs and response differences that confirm valid accounts.",
        watch=["No throttling by account and IP; distinct errors for unknown user vs wrong password; short numeric OTPs without attempt limits."],
        test=["Submit repeated logins/OTPs at a controlled rate; compare error messages and timing."],
        fix=["Throttle by account and IP, use generic errors, MFA, breached-password checks and monitoring for stuffing patterns."],
        refs=["CWE-307"],
        related=["api2-broken-auth", "cfg-rate-limiting", "biz-enumeration"],
    ),
    _e(
        "auth-password-storage", "auth", "Password storage and reset flows",
        "password storage hash bcrypt argon2 scrypt salt pepper reset token forgot password email change credential",
        "Passwords must be stored only as salted, slow hashes (Argon2id, scrypt or bcrypt) and never returned by the API. Reset flows need single-use, short-lived, unpredictable tokens and must not reveal whether an account exists.",
        watch=["MD5/SHA-1/unsalted hashes; password hashes in responses; reset tokens that are guessable or long-lived."],
        test=["Request resets repeatedly and compare tokens; reuse tokens; check responses for account enumeration."],
        fix=["Use Argon2id/bcrypt, single-use expiring reset tokens, generic responses and re-authentication for sensitive changes."],
        refs=["CWE-916", "CWE-640"],
        related=["api2-broken-auth", "obj-sensitive-properties"],
    ),
]

KB.extend([
    # ------------------------------------------------------------------ Configuration & transport
    _e(
        "cfg-tls", "config", "TLS / HTTPS and HSTS",
        "tls https ssl certificate hsts strict transport security cipher protocol version downgrade plaintext http encryption in transit certificate validation",
        "TLS encrypts API traffic and authenticates the server. Serve everything over HTTPS (TLS 1.2+ , preferably 1.3), redirect or refuse HTTP, and send Strict-Transport-Security so browsers never downgrade. Clients must validate certificates - verify=False defeats TLS.",
        watch=["HTTP endpoints alongside HTTPS; old protocol versions and weak ciphers; expired/self-signed certs; HSTS missing or with a short max-age; certificate validation disabled in client code."],
        test=["Request the API over http://; scan the TLS configuration; inspect the Strict-Transport-Security header; grep client code for verify=False / rejectUnauthorized:false."],
        fix=["Enforce HTTPS everywhere, use modern protocols/ciphers, set Strict-Transport-Security: max-age=31536000; includeSubDomains and never disable certificate validation."],
        refs=["CWE-319", "CWE-295"],
        related=["cfg-security-headers", "api8-misconfiguration"],
    ),
    _e(
        "cfg-security-headers", "config", "Security response headers",
        "security headers hsts csp content security policy x content type options nosniff x frame options cache control referrer policy permissions policy server x powered by header",
        "Response headers harden clients that consume the API. Useful set for APIs: Strict-Transport-Security; X-Content-Type-Options: nosniff; Cache-Control: no-store for sensitive responses; Content-Security-Policy: frame-ancestors 'none' (or X-Frame-Options: DENY); a correct Content-Type; and no Server/X-Powered-By version disclosure.",
        watch=["Missing nosniff or HSTS; sensitive responses cacheable; version banners; wildcard CORS headers."],
        test=["Send a normal and an error request and read every response header; check Cache-Control on authenticated responses."],
        fix=["Set the headers centrally (gateway or middleware), remove version banners and verify them in CI."],
        related=["cfg-tls", "cfg-cors", "api8-misconfiguration"],
    ),
    _e(
        "cfg-cors", "config", "CORS (Cross-Origin Resource Sharing)",
        "cors cross origin resource sharing access-control-allow-origin allow credentials preflight options origin wildcard reflect null origin browser same origin policy",
        "CORS lets a browser page from one origin read responses from another. Access-Control-Allow-Origin: * lets any site read (non-credentialed) responses; reflecting the request Origin together with Access-Control-Allow-Credentials: true lets any site read a logged-in user's data. CORS is a browser rule, not an authentication mechanism.",
        watch=["Wildcard origin on authenticated APIs; Origin reflected without an allow-list; 'null' origin allowed; credentials allowed with broad origins."],
        test=["Send requests with Origin: https://evil.example and Origin: null; inspect Access-Control-Allow-Origin and -Credentials; test the OPTIONS preflight."],
        fix=["Use an explicit allow-list of origins, never combine credentials with wildcards or reflection and keep authorization server-side."],
        refs=["CWE-942"],
        related=["auth-sessions-cookies", "cfg-security-headers", "api8-misconfiguration"],
    ),
    _e(
        "cfg-rate-limiting", "config", "Rate limiting, quotas and throttling",
        "rate limit rate limiting quota throttle throttling 429 retry after burst per user per ip token bucket abuse ratelimit header",
        "Rate limits cap how often a client can call the API; quotas cap total use over a period. They protect availability, cost and authentication endpoints. A good limit is per identity and per operation, answers 429 with Retry-After and can be observed through RateLimit headers.",
        watch=["No limit at all; limits only per IP; limits that reset by changing a header or token; limits missing on login, OTP, search, export and other costly functions."],
        test=["Send a controlled burst and look for 429; rotate IP/headers/tokens to see whether the limit follows the right identity."],
        fix=["Enforce limits at the gateway and application, per identity and per endpoint, with stricter limits on authentication and expensive operations."],
        refs=["CWE-770"],
        related=["api4-resource-consumption", "auth-credential-stuffing"],
    ),
    _e(
        "cfg-logging", "config", "Logging, monitoring and audit",
        "logging log monitoring audit trail alerting siem security events authentication failure access denied correlation id log injection sensitive data in logs",
        "Security logging records who did what and when so attacks can be detected and investigated: authentication successes/failures, access-control denials, validation failures, admin actions. Logs must not contain secrets or personal data, and must be protected from tampering.",
        watch=["No logging of authorization failures; tokens, passwords or full card numbers in logs; user input written unsanitised (log injection); logs nobody monitors."],
        test=["Trigger failed logins and denied requests, then confirm they are logged with user, IP and correlation ID and that sensitive values are masked."],
        fix=["Log security events with context, mask secrets/PII, ship logs to protected storage and alert on anomalies."],
        refs=["CWE-778", "CWE-532"],
        related=["cfg-secrets", "data-personal-data"],
    ),
    _e(
        "cfg-secrets", "config", "Secrets management (keys, tokens, passwords)",
        "secret secrets hardcoded credential api key token password private key vault secret manager rotate environment variable git leak commit env file",
        "Secrets are credentials the system uses: API keys, tokens, database passwords, signing keys. They must not live in source code, images, client apps, URLs or logs. Store them in a secret manager, scope them narrowly and rotate them - and rotate immediately if one leaks.",
        watch=["Literals such as api_key = 'sk_live_...' in code; .env files committed; secrets in mobile apps or JS bundles; the same key used everywhere."],
        test=["Run secret scanning over the repository history and build artifacts; review client bundles and container images."],
        fix=["Move secrets to a vault or environment-backed secret store, add pre-commit/CI secret scanning, and rotate any exposed credential."],
        refs=["CWE-798", "CWE-312"],
        related=["auth-api-keys", "cfg-logging"],
    ),

    # ------------------------------------------------------------------ Injection & data handling
    _e(
        "inj-sql", "inject", "SQL injection",
        "sql injection sqli database query string concatenation parameterized prepared statement orm union blind error based quote tautology",
        "User input concatenated into a SQL statement changes the query's meaning, letting attackers read or modify data. Parameterised queries keep code and data separate.",
        watch=["String formatting/concatenation into queries; dynamic ORDER BY or column names from the client; verbose SQL errors."],
        test=["Send quotes, boolean payloads and time-delay payloads in every parameter; watch for errors and behaviour changes (authorised testing only)."],
        fix=["Use parameterised queries/ORM bindings, allow-list identifiers such as sort columns and run the database account with least privilege."],
        example="""
# Vulnerable
cursor.execute("SELECT * FROM users WHERE email = '" + email + "'")

# Fixed
cursor.execute("SELECT * FROM users WHERE email = %s", (email,))""",
        refs=["CWE-89"],
        related=["fn-search-filter-sort", "inj-nosql"],
    ),
    _e(
        "inj-nosql", "inject", "NoSQL and JSON injection",
        "nosql injection mongodb operator $ne $gt $where json injection query object type confusion",
        "Document databases accept structured queries. If the client can send an object where a string was expected (for example {\"$ne\": null} as a password), the query semantics change and authentication or filtering can be bypassed.",
        watch=["Request JSON passed straight into query filters; operators such as $ne, $gt, $where, $regex accepted from clients."],
        test=["Replace string values with operator objects; test login and filter endpoints."],
        fix=["Validate types strictly (schema), reject operator keys and build queries from allow-listed fields."],
        refs=["CWE-943"],
        related=["obj-schema-validation", "inj-sql"],
    ),
    _e(
        "inj-command", "inject", "Command and code injection",
        "command injection os command shell exec eval system subprocess code injection template injection ssti remote code execution rce",
        "Passing untrusted input to a shell, eval or a template engine can let attackers run code on the server. It is usually critical severity.",
        watch=["os.system, subprocess with shell=True, eval/exec, child_process.exec, template rendering of user input."],
        test=["Send shell metacharacters and time-delay payloads to parameters that reach system calls (authorised testing only)."],
        fix=["Avoid shells; use argument arrays and library APIs, allow-list inputs and never evaluate user data."],
        refs=["CWE-78", "CWE-94"],
        related=["obj-schema-validation"],
    ),
    _e(
        "inj-xxe", "inject", "XML External Entities (XXE)",
        "xxe xml external entity dtd parser soap xml upload doctype entity expansion billion laughs",
        "XML parsers that process DTDs can be tricked into reading local files, making network requests (SSRF) or exhausting memory. It affects SOAP and any endpoint that accepts XML or XML-based formats (SVG, DOCX).",
        watch=["Endpoints that accept XML; libraries with default entity resolution."],
        test=["Send XML with an external entity that points to a local file or a callback host (authorised testing only)."],
        fix=["Disable DTDs and external entity resolution in the parser, or use a hardened parser; prefer JSON."],
        refs=["CWE-611"],
        related=["fn-content-types", "api7-ssrf"],
    ),
    _e(
        "inj-deserialization", "inject", "Insecure deserialization",
        "deserialization pickle yaml load objectinputstream unserialize gadget chain serialized object untrusted data remote code",
        "Deserializing attacker-controlled data with a format that can instantiate arbitrary objects (pickle, Java serialization, PHP unserialize, unsafe YAML load) can lead to remote code execution.",
        watch=["pickle.loads, yaml.load without SafeLoader, ObjectInputStream, unserialize on request data or cookies."],
        test=["Identify serialized blobs in cookies/bodies and review code paths that deserialize them."],
        fix=["Use data-only formats (JSON) with schema validation; use safe loaders and never deserialize untrusted native objects."],
        refs=["CWE-502"],
        related=["inj-command"],
    ),
    _e(
        "inj-path-traversal", "inject", "Path traversal",
        "path traversal directory traversal dot dot slash file path filename read file lfi send_file download arbitrary file",
        "If a filename or path from the client is used to open files, sequences such as ../ can escape the intended directory and read or overwrite arbitrary files.",
        watch=["open(), send_file(), readFile() using request-controlled names; file download endpoints that take a path."],
        test=["Send ../ sequences, absolute paths and encoded variants in file parameters."],
        fix=["Map identifiers to files server-side, canonicalise and verify the resolved path stays inside the base directory, and never use raw client paths."],
        refs=["CWE-22"],
        related=["fn-file-upload"],
    ),
    _e(
        "inj-open-redirect", "inject", "Open redirect",
        "open redirect redirect url return url next parameter location header phishing login redirect uri",
        "APIs and login flows that redirect to a client-supplied URL can send users to attacker sites (phishing) and can be chained with OAuth or SSRF.",
        watch=["Parameters named redirect, next, return, url, callback."],
        test=["Supply external URLs and protocol-relative variants (//evil.example) to redirect parameters."],
        fix=["Allow-list redirect destinations or use relative paths / server-side identifiers."],
        refs=["CWE-601"],
        related=["api7-ssrf", "auth-oauth2"],
    ),
    _e(
        "inj-hpp", "inject", "HTTP parameter pollution",
        "hpp http parameter pollution duplicate parameter same name multiple values array proxy backend waf bypass",
        "Sending the same parameter more than once can be interpreted differently by the gateway, framework and business logic (first value, last value or array), letting an attacker slip a malicious value past a check.",
        watch=["Validation at the gateway with different parsing than the backend."],
        test=["Duplicate parameters in query and body (id=1&id=2) and compare behaviour."],
        fix=["Reject duplicate parameters, parse consistently and validate the final value the business logic uses."],
        refs=["CWE-235"],
        related=["fn-parameters"],
    ),
    _e(
        "data-mass-assignment", "inject", "Mass assignment",
        "mass assignment autobinding auto binding over posting overposting bind request body to model property role isadmin privilege escalation dto allow list",
        "Frameworks can bind a whole request body onto a model automatically. If the client adds properties like role, isAdmin or ownerId, they may be written too - privilege escalation without any 'exploit'.",
        watch=["User(**request.json), Model.update(body), automatic binders; properties marked readOnly in the spec but accepted."],
        test=["Add extra properties to create/update requests and re-read the object."],
        fix=["Bind to DTOs with allow-listed properties and reject unknown properties."],
        refs=["CWE-915"],
        related=["api3-bopla", "obj-property-flags"],
    ),
    _e(
        "data-excessive-exposure", "inject", "Excessive data exposure",
        "excessive data exposure over exposure returns too much data full object serialise database row sensitive fields client side filtering response filter",
        "The API returns more data than the client needs and relies on the UI to hide it. Anyone calling the API directly sees everything, including other users' data or internal properties.",
        watch=["Responses that mirror database rows; 'filtering' done in JavaScript; different roles receiving identical payloads."],
        test=["Read raw responses (not the UI) and list every property; compare with what the screen shows."],
        fix=["Return explicit response schemas with only required properties, per role."],
        refs=["CWE-213", "CWE-200"],
        related=["api3-bopla", "obj-sensitive-properties"],
    ),
    _e(
        "data-personal-data", "inject", "Personal and regulated data (PII, PCI, PHI)",
        "personal data pii pci phi gdpr privacy sensitive data card number health data masking encryption retention minimisation",
        "Personal and regulated data needs extra protection: collect only what is needed, encrypt in transit and at rest, mask in responses and logs, and delete on schedule.",
        watch=["Full card/ID numbers in responses or logs; personal data returned to other users; data kept indefinitely."],
        test=["Search responses and logs for personal data patterns; verify masking and access rules."],
        fix=["Minimise and mask data, tokenise payment data, restrict access by role and set retention limits."],
        related=["obj-sensitive-properties", "cfg-logging"],
    ),
    _e(
        "biz-race-conditions", "inject", "Race conditions and business-logic abuse",
        "race condition concurrency double spend toctou parallel request coupon redeem limit overrun business logic abuse lock transaction",
        "When two requests run at the same time, checks and updates can interleave: a coupon is redeemed twice, a balance goes negative, a limit is exceeded. It is a design flaw, invisible to scanners.",
        watch=["Check-then-act code without transactions or locks; limits enforced in application memory; redeem/transfer/withdraw endpoints."],
        test=["Send many identical requests in parallel (single-packet or threaded) and compare the outcome with the limit."],
        fix=["Use atomic database operations, unique constraints, row locks and idempotency keys."],
        refs=["CWE-362"],
        related=["fn-idempotency", "api6-business-flows"],
    ),
    _e(
        "biz-enumeration", "inject", "User and object enumeration",
        "enumeration user enumeration account discovery valid usernames timing difference response differences guess ids harvest",
        "Different responses, status codes or timings for 'exists' and 'does not exist' let attackers discover valid accounts or objects and target them.",
        watch=["Login/reset/registration messages that reveal existence; 403 vs 404 on objects; timing differences."],
        test=["Compare responses and timings for existing vs non-existing users/objects."],
        fix=["Return uniform responses and comparable timing, and rate-limit lookups."],
        refs=["CWE-204"],
        related=["auth-credential-stuffing", "fn-status-codes"],
    ),

    # ------------------------------------------------------------------ Standards, scoring, process
    _e(
        "std-cvss", "standard", "CVSS scores and severity ratings",
        "cvss score severity base score vector av ac pr ui scope confidentiality integrity availability critical high medium low rating calculator",
        "CVSS scores technical severity from 0.0 to 10.0 using base metrics (attack vector, complexity, privileges, user interaction, scope, and impact on confidentiality, integrity and availability). CVSS v3.x ratings: 0.1-3.9 Low, 4.0-6.9 Medium, 7.0-8.9 High, 9.0-10.0 Critical. It measures severity, not business risk.",
        watch=["A 'Critical' label with a low CVSS (or the reverse); scores without a vector so nobody can check them; environment ignored (an internal-only API is not the same as a public one)."],
        test=["Recompute the score from the vector and compare with the reported value and the severity label."],
        fix=["Publish the vector with the score, apply environmental context, and combine CVSS with exploitability data (EPSS, KEV) to prioritise."],
        refs=["FIRST CVSS v3.1 / v4.0 specification"],
        related=["std-cve-cwe-epss-kev", "rpt-severity-cvss"],
    ),
    _e(
        "std-cve-cwe-epss-kev", "standard", "CVE, CWE, EPSS, KEV, OSV - what is what",
        "cve cwe epss kev osv nvd advisory ghsa identifier weakness exploit prediction known exploited vulnerabilities catalog difference",
        "CVE = an identifier for one publicly disclosed vulnerability in a product. CWE = a category of weakness (for example CWE-79 XSS). CVSS = the severity score. EPSS = the estimated probability (0-1) that a CVE will be exploited in the next 30 days. KEV = CISA's catalog of vulnerabilities known to be exploited in the wild. OSV/NVD/GHSA = databases and advisories that publish the details.",
        watch=["Prioritising only on CVSS; ignoring KEV/EPSS; CVEs reported for a library that the code never calls."],
        test=["Match dependency versions to advisories, then check reachability of the vulnerable function."],
        fix=["Patch KEV-listed and high-EPSS items first, track dependencies with an SBOM and re-scan regularly."],
        refs=["cve.org", "cwe.mitre.org", "first.org/epss", "CISA KEV"],
        related=["std-cvss", "std-sbom-dependencies"],
    ),
    _e(
        "std-sbom-dependencies", "standard", "Dependencies, SCA and SBOM",
        "sbom software bill of materials dependency sca software composition analysis library package vulnerable component cyclonedx spdx supply chain osv",
        "APIs are built from many third-party libraries. Software Composition Analysis (SCA) matches your dependency versions to known vulnerabilities; an SBOM (CycloneDX or SPDX) is the machine-readable list of components that makes this possible.",
        watch=["Unpinned or very old versions; transitive dependencies; vulnerabilities in code paths that are actually used."],
        test=["Generate an SBOM, scan it with OSV/SCA tooling and triage by reachability and exploitability."],
        fix=["Pin and update dependencies, automate scanning in CI and remove unused packages."],
        related=["std-cve-cwe-epss-kev", "api10-unsafe-consumption"],
    ),
    _e(
        "std-threat-modeling", "standard", "Threat modeling (STRIDE)",
        "threat modeling threat model stride spoofing tampering repudiation information disclosure denial of service elevation of privilege data flow trust boundary design review",
        "Threat modeling asks 'what can go wrong?' before code is written. STRIDE prompts you to consider Spoofing, Tampering, Repudiation, Information disclosure, Denial of service and Elevation of privilege across each data flow and trust boundary.",
        watch=["Trust boundaries drawn around 'internal' services that are actually reachable; no analysis of third-party integrations."],
        test=["Draw the data flows, list assets and entry points, and walk each through STRIDE."],
        fix=["Turn each threat into a control or test and revisit when the design changes."],
        related=["std-ssdf", "api6-business-flows"],
    ),
    _e(
        "std-asvs", "standard", "OWASP ASVS",
        "asvs application security verification standard level 1 2 3 requirements checklist verification chapters controls",
        "The OWASP Application Security Verification Standard is a list of testable security requirements for web applications and APIs, grouped by area (authentication, access control, validation, cryptography, logging, configuration and more) with three assurance levels (L1-L3).",
        test=["Pick a level, map requirements to the areas your API uses and verify each with a test or review."],
        fix=["Use ASVS as the acceptance criteria for security reviews and as a checklist for test plans."],
        refs=["OWASP ASVS"],
        related=["std-ssdf", "std-api-stat-policy"],
    ),
    _e(
        "std-ssdf", "standard", "NIST SSDF (SP 800-218)",
        "nist ssdf sp 800-218 secure software development framework practice prepare protect produce respond vulnerabilities sdlc",
        "The NIST Secure Software Development Framework groups practices into four areas: Prepare the Organization, Protect the Software, Produce Well-Secured Software and Respond to Vulnerabilities. It helps integrate security into every stage of the SDLC.",
        fix=["Map your engineering process to the four groups and close gaps (threat modelling, code review, dependency management, vulnerability response)."],
        refs=["NIST SP 800-218"],
        related=["std-asvs", "std-threat-modeling"],
    ),
    _e(
        "std-api-stat-policy", "standard", "API-STAT Security Policy (summary)",
        "api-stat policy baseline minimum requirement verification authentication authorization transport configuration input validation resource controls secrets dependencies inventory logging assessment ai evidence",
        "The bundled API-STAT policy sets minimum controls for authentication, authorization, transport security, configuration, input validation, resource controls, secrets, dependencies, inventory and logging. It states that AI output is contextual analysis and must not be the sole evidence for a finding, and that critical/high findings should be reproduced where safe, assigned an owner, remediated and re-tested, with reports preserving evidence, confidence, severity, remediation guidance and assessment date.",
        related=["api9-inventory", "rpt-evidence-retest"],
    ),
    _e(
        "test-methods", "standard", "Security testing methods (SAST, DAST, IAST, SCA, fuzzing, pentest)",
        "sast dast iast sca fuzzing penetration test pentest static dynamic analysis code review scanner black box white box testing method",
        "SAST analyses source code without running it; DAST attacks a running API from outside; IAST instruments the running app; SCA checks dependencies; fuzzing sends malformed/random input to find crashes and logic gaps; a penetration test combines tools with human creativity. Each finds different problems - authorization flaws (BOLA/BFLA) usually need manual, context-aware testing.",
        fix=["Combine SAST + SCA in CI, DAST/fuzzing in staging and manual authorization testing for critical APIs."],
        related=["test-authz-matrix", "std-asvs"],
    ),
    _e(
        "test-authz-matrix", "standard", "Authorization test matrix",
        "authorization matrix test cases role endpoint method user a user b tenant cross account access control testing checklist",
        "An authorization matrix lists every role against every operation (and object owner) with the expected result. Testing each cell with real tokens is the most reliable way to find BOLA and BFLA.",
        test=[
            "List roles, endpoints/methods and object owners; define expected allow/deny for each.",
            "Run each cell with the matching token and record any difference; automate it in CI.",
        ],
        related=["api1-bola", "api5-bfla", "test-methods"],
    ),

    # ------------------------------------------------------------------ Reading security reports
    _e(
        "rpt-good-finding", "report", "What a good security finding contains",
        "what makes a good pentest finding penetration test finding write up quality report finding quality title severity cvss affected endpoint description evidence proof of concept impact likelihood remediation references owner retest reproduction steps",
        "A useful finding has: a clear title; severity with a score and vector; the affected asset/endpoint; a description; evidence (request/response, screenshots) and steps to reproduce; business impact and likelihood; specific remediation; references (CWE, OWASP); an owner and a retest status.",
        watch=["Findings with no evidence or reproduction steps, generic remediation ('follow best practices'), no affected endpoint, or scanner output pasted unverified."],
        related=["rpt-severity-cvss", "rpt-false-positives", "rpt-evidence-retest"],
    ),
    _e(
        "rpt-severity-cvss", "report", "Consistency of severity and CVSS in reports",
        "severity cvss consistency inconsistent rating mismatch critical low score label calculation report review rating scheme",
        "The severity label should match the score band (Low 0.1-3.9, Medium 4.0-6.9, High 7.0-8.9, Critical 9.0-10.0 for CVSS v3.x) and, if a vector is given, the score should match what the vector calculates. Deliberate adjustments (for environment or compensating controls) must be explained.",
        watch=["A 'Critical' finding with CVSS 4.3, a 'Low' with 9.8, scores that do not match their vector, or a rating scheme that is never defined."],
        related=["std-cvss", "rpt-good-finding"],
    ),
    _e(
        "rpt-false-positives", "report", "Triaging false positives and unverified findings",
        "false positive triage unverified scanner finding reachable exploitable duplicate confirm validate noise reachability",
        "Automated scanners over-report. Before acting, confirm the finding is real (reproduce it), reachable (the vulnerable code or endpoint is actually used), and not a duplicate. Record the decision and reasoning.",
        test=["Reproduce with a manual request, check whether the vulnerable code path is used and whether compensating controls exist."],
        related=["rpt-good-finding", "rpt-evidence-retest"],
    ),
    _e(
        "rpt-evidence-retest", "report", "Evidence, ownership and retest",
        "evidence retest re-test verification owner remediation status reproduced critical high assessment date confidence report policy tracking",
        "For critical and high findings, good practice (and the API-STAT policy) is to reproduce them where safe, assign an owner, remediate and re-test, and keep evidence, confidence, severity, remediation guidance and the assessment date in the report.",
        watch=["No retest section; no owner or due date; no assessment date; findings marked 'fixed' without verification."],
        related=["std-api-stat-policy", "rpt-good-finding"],
    ),
])


# ---------------------------------------------------------------------- index & lookup
_BY_ID: Dict[str, dict] = {e["id"]: e for e in KB}
_index: Optional[TfidfIndex] = None
_lock = threading.Lock()

OWASP_IDS = [e["id"] for e in KB if e["cat"] == "owasp"]


def get_entry(entry_id: str) -> Optional[dict]:
    return _BY_ID.get(entry_id)


def kb_index() -> TfidfIndex:
    """Lazily-built, process-wide TF-IDF index over the knowledge base."""
    global _index
    if _index is None:
        with _lock:
            if _index is None:
                idx = TfidfIndex({"keywords": 3.0, "title": 2.5, "summary": 1.2, "detail": 0.8})
                for e in KB:
                    idx.add(
                        e["id"],
                        {
                            "keywords": e["keywords"],
                            "title": e["title"],
                            "summary": e["summary"],
                            "detail": " ".join(e["watch"] + e["test"] + e["fix"]),
                        },
                        e,
                    )
                idx.build()
                _index = idx
    return _index


# Words that appear everywhere in this domain carry little signal about *which* topic is meant.
GENERIC_TERMS = {"api": 0.35, "object": 0.6, "endpoint": 0.7, "request": 0.7, "response": 0.7, "return": 0.6}


def search_kb(query: str, k: int = 4, min_score: float = 0.06, cats=None):
    """Return vector hits over the knowledge base, optionally restricted to categories."""
    accept = (lambda p: p.get("cat") in cats) if cats else None
    return kb_index().query(query, k=k, min_score=min_score, accept=accept, damp=GENERIC_TERMS)


_owasp_idx: Optional[TfidfIndex] = None


def owasp_index() -> TfidfIndex:
    """Separate index containing only the ten OWASP categories (used to map findings)."""
    global _owasp_idx
    if _owasp_idx is None:
        with _lock:
            if _owasp_idx is None:
                idx = TfidfIndex({"keywords": 3.0, "title": 2.0, "summary": 1.0, "detail": 1.0})
                for e in KB:
                    if e["cat"] == "owasp":
                        idx.add(
                            e["id"],
                            {"keywords": e["keywords"], "title": e["title"], "summary": e["summary"],
                             "detail": " ".join(e["watch"] + e["test"])},
                            e,
                        )
                idx.build()
                _owasp_idx = idx
    return _owasp_idx


def owasp_label(entry_id: str) -> str:
    """'api1-bola' -> 'API1:2023'."""
    e = _BY_ID.get(entry_id)
    return e["title"].split(" ")[0] if e else entry_id
