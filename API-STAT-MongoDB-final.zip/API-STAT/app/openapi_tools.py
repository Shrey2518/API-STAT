"""Static security review of an OpenAPI 3.x / Swagger 2.0 description.

Explains an API's *objects* (schemas), *properties* and *functions* (operations)
and flags design-level risks that can be seen from the contract alone. A spec
cannot prove a vulnerability - findings are review candidates, worded as such.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Set, Tuple

HTTP_METHODS = ("get", "put", "post", "delete", "options", "head", "patch", "trace")
SENSITIVE_RESPONSE = re.compile(
    r"pass(?:word|wd)?|secret|token|api_?key|apikey|private_?key|ssn|social_?security|credit_?card|card_?number|cvv|cvc|iban|"
    r"salt|hash|otp|pin_?code|refresh_?token", re.I)
PRIVILEGED_WRITE = re.compile(
    r"^(?:role|roles|is_?admin|admin|is_?staff|is_?superuser|permissions?|scopes?|privileges?|owner_?id|user_?id|account_?id|tenant_?id|"
    r"org(?:anization)?_?id|balance|credit|price|discount|verified|is_?verified|email_?verified|approved|status|plan|tier)$", re.I)
ID_PARAM = re.compile(r"(?:^|_)(?:id|uuid|guid)$|Id$|^id$", re.I)
ADMIN_PATH = re.compile(r"/(?:admin|internal|manage|management|debug|actuator|console|private|superuser|backoffice)(?:/|$)", re.I)
SSRF_PARAM = re.compile(r"^(?:url|uri|link|callback|callback_?url|webhook|webhook_?url|redirect|redirect_?uri|return_?url|next|image_?url|feed|target|endpoint|host|proxy)$", re.I)
PAGING_PARAM = re.compile(r"^(?:limit|page|page_?size|per_?page|offset|cursor|size|top|skip|take|next_?token|after|before)$", re.I)
MAX_FINDINGS = 60


def _resolve(spec: dict, node: Any, seen: Optional[Set[str]] = None, depth: int = 0) -> Any:
    """Resolve local $ref pointers (with a cycle/depth guard)."""
    if not isinstance(node, dict) or "$ref" not in node:
        return node
    ref = node["$ref"]
    seen = seen or set()
    if not isinstance(ref, str) or not ref.startswith("#/") or ref in seen or depth > 12:
        return {}
    cur: Any = spec
    for part in ref[2:].split("/"):
        part = part.replace("~1", "/").replace("~0", "~")
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return {}
    return _resolve(spec, cur, seen | {ref}, depth + 1)


def _schema_props(spec: dict, schema: Any, depth: int = 0, seen: Optional[Set[int]] = None) -> Dict[str, dict]:
    """Flatten (allOf/nested) object properties: name -> resolved property schema. Nested names use dots."""
    out: Dict[str, dict] = {}
    seen = seen or set()
    schema = _resolve(spec, schema)
    if not isinstance(schema, dict) or depth > 4 or id(schema) in seen:
        return out
    seen = seen | {id(schema)}
    for sub in schema.get("allOf", []) or []:
        out.update(_schema_props(spec, sub, depth, seen))
    for name, prop in (schema.get("properties") or {}).items():
        p = _resolve(spec, prop)
        if not isinstance(p, dict):
            continue
        out[str(name)] = p
        child = p.get("items") if p.get("type") == "array" else p
        if isinstance(child, dict) and (child.get("properties") or child.get("$ref") or child.get("allOf")):
            for cname, cp in _schema_props(spec, child, depth + 1, seen).items():
                out[f"{name}.{cname}"] = cp
    if schema.get("type") == "array" and schema.get("items"):
        out.update(_schema_props(spec, schema["items"], depth + 1, seen))
    return out


def _body_schema(spec: dict, op: dict, is_v3: bool) -> Any:
    if is_v3:
        rb = _resolve(spec, op.get("requestBody") or {})
        for _ct, media in (rb.get("content") or {}).items():
            if isinstance(media, dict) and media.get("schema"):
                return media["schema"]
        return None
    for prm in op.get("parameters", []) or []:
        prm = _resolve(spec, prm)
        if prm.get("in") == "body":
            return prm.get("schema")
    return None


def _response_schemas(spec: dict, op: dict, is_v3: bool) -> List[Any]:
    out = []
    for code, resp in (op.get("responses") or {}).items():
        if not str(code).startswith("2"):
            continue
        resp = _resolve(spec, resp)
        if is_v3:
            for _ct, media in (resp.get("content") or {}).items():
                if isinstance(media, dict) and media.get("schema"):
                    out.append(media["schema"])
        elif resp.get("schema"):
            out.append(resp["schema"])
    return out


def _add(findings: List[dict], sev: str, owasp: str, title: str, where: str, detail: str):
    if len(findings) < MAX_FINDINGS:
        findings.append({"severity": sev, "owasp": owasp, "title": title, "where": where, "detail": detail})


def analyze_openapi(spec: Any, ask: str = "") -> dict:
    if not isinstance(spec, dict) or not isinstance(spec.get("paths"), dict):
        return {"ok": False, "error": "This does not look like an OpenAPI/Swagger document (no 'paths')."}
    is_v3 = "openapi" in spec
    version = str(spec.get("openapi") or spec.get("swagger"))
    info = spec.get("info") or {}
    findings: List[dict] = []

    # ---- servers / transport
    servers = [s.get("url", "") for s in (spec.get("servers") or []) if isinstance(s, dict)] if is_v3 else \
        [f"{sch}://{spec.get('host', '')}{spec.get('basePath', '')}" for sch in (spec.get("schemes") or [])]
    for s in servers:
        if s.startswith("http://") and not re.match(r"http://(?:localhost|127\.0\.0\.1)", s):
            _add(findings, "MEDIUM", "API8:2023", "Server declared over plain HTTP", s, "The spec advertises an unencrypted server URL. Confirm production is HTTPS-only.")

    # ---- security schemes
    schemes = (spec.get("components") or {}).get("securitySchemes") if is_v3 else spec.get("securityDefinitions")
    schemes = schemes if isinstance(schemes, dict) else {}
    scheme_summary = []
    for name, sc in schemes.items():
        sc = _resolve(spec, sc)
        typ = sc.get("type", "?")
        detail = sc.get("scheme") or sc.get("in") or sc.get("flow") or ""
        scheme_summary.append({"name": name, "type": typ, "detail": str(detail)})
        if typ == "apiKey" and sc.get("in") == "query":
            _add(findings, "MEDIUM", "API2:2023", f"API key sent in the query string ({name})", f"securityScheme {name}", "Keys in URLs end up in logs, browser history and referrers. Use a header.")
        if typ == "http" and str(sc.get("scheme", "")).lower() == "basic":
            _add(findings, "LOW", "API2:2023", f"HTTP Basic authentication ({name})", f"securityScheme {name}", "Basic auth sends static credentials on every request; prefer short-lived tokens.")
        flows = sc.get("flows") or {}
        if typ == "oauth2" and ("implicit" in flows or sc.get("flow") == "implicit" or "password" in flows or sc.get("flow") == "password"):
            _add(findings, "MEDIUM", "API2:2023", f"OAuth2 implicit/password flow ({name})", f"securityScheme {name}", "These flows are discouraged; use Authorization Code with PKCE or Client Credentials.")
    global_security = spec.get("security")
    if not schemes:
        _add(findings, "HIGH", "API2:2023", "No security schemes defined", "components.securitySchemes",
             "The contract declares no authentication at all. Confirm authentication is enforced elsewhere and document it.")

    # ---- walk operations
    ops: List[dict] = []
    method_count: Dict[str, int] = {}
    schema_use: Dict[str, int] = {}
    versions: Set[str] = set()
    unpaged, unsecured_mut, unsecured_read, deprecated = [], [], [], []
    doc429 = False
    for path, item in spec["paths"].items():
        item = _resolve(spec, item)
        if not isinstance(item, dict):
            continue
        m = re.search(r"/v(\d+)(?:/|$)", path)
        if m:
            versions.add("v" + m.group(1))
        shared_params = item.get("parameters", []) or []
        for method in HTTP_METHODS:
            op = item.get(method)
            if not isinstance(op, dict):
                continue
            method_count[method.upper()] = method_count.get(method.upper(), 0) + 1
            label = f"{method.upper()} {path}"
            params = [_resolve(spec, p) for p in (shared_params + (op.get("parameters") or []))]
            eff_sec = op["security"] if "security" in op else global_security
            secured = bool(eff_sec) and any(bool(r) for r in eff_sec if isinstance(r, dict)) if eff_sec is not None else False
            mutating = method in ("post", "put", "patch", "delete")
            ops.append({"op": label, "method": method.upper(), "path": path, "secured": secured,
                        "operation_id": op.get("operationId"), "summary": op.get("summary") or ""})
            if op.get("deprecated"):
                deprecated.append(label)
            if not secured and schemes:
                (unsecured_mut if mutating else unsecured_read).append(label)
            for code in (op.get("responses") or {}):
                if str(code) == "429":
                    doc429 = True

            # BOLA candidates
            id_params = [p.get("name") for p in params if p.get("in") == "path" and ID_PARAM.search(str(p.get("name", "")))]
            if id_params:
                _add(findings, "INFO", "API1:2023", "Object-ID parameter: verify ownership check", label,
                     f"Path parameter(s) {', '.join(map(str, id_params))} select a specific object. Confirm the server checks that the caller may access that object (BOLA).")
            if ADMIN_PATH.search(path):
                _add(findings, "MEDIUM", "API5:2023", "Privileged-looking function", label,
                     "Admin/internal-style path. Confirm role-based function-level authorization and that it is not exposed on the public API.")
            for p in params:
                if SSRF_PARAM.match(str(p.get("name", ""))):
                    _add(findings, "MEDIUM", "API7:2023", f"URL-like parameter '{p.get('name')}'", label, "If the server fetches or redirects to this value, review for SSRF/open redirect.")

            # request body
            body = _body_schema(spec, op, is_v3)
            if body is not None:
                props = _schema_props(spec, body)
                for name, p in props.items():
                    leaf = name.split(".")[-1]
                    if PRIVILEGED_WRITE.match(leaf) and not p.get("readOnly"):
                        _add(findings, "MEDIUM", "API3:2023", f"Client-writable privileged property '{name}'", label,
                             "Not marked readOnly. If bound directly to the model this enables mass assignment/privilege escalation.")
                    if SSRF_PARAM.match(leaf):
                        _add(findings, "MEDIUM", "API7:2023", f"URL-like body property '{name}'", label, "Review for SSRF/open redirect.")
                bs = _resolve(spec, body)
                if isinstance(bs, dict) and bs.get("type") in (None, "object") and bs.get("additionalProperties") is not False and props:
                    schema_use["open_bodies"] = schema_use.get("open_bodies", 0) + 1
                for name, p in props.items():
                    if p.get("type") == "string" and not any(k in p for k in ("maxLength", "enum", "pattern", "format")):
                        schema_use["unbounded_strings"] = schema_use.get("unbounded_strings", 0) + 1
                    if p.get("type") == "array" and "maxItems" not in p:
                        schema_use["unbounded_arrays"] = schema_use.get("unbounded_arrays", 0) + 1
            # responses
            for rs in _response_schemas(spec, op, is_v3):
                for name, p in _schema_props(spec, rs).items():
                    leaf = name.split(".")[-1]
                    if SENSITIVE_RESPONSE.search(leaf) and not p.get("writeOnly"):
                        _add(findings, "HIGH" if re.search(r"pass|secret|private|ssn|card|cvv|hash", leaf, re.I) else "MEDIUM", "API3:2023",
                             f"Sensitive property '{name}' in a response", label,
                             "Returned to the client. Remove, mask, or restrict by role; if it is input only, mark it writeOnly.")
                rsr = _resolve(spec, rs)
                if method == "get" and isinstance(rsr, dict) and rsr.get("type") == "array":
                    if not any(PAGING_PARAM.match(str(p.get("name", ""))) for p in params):
                        unpaged.append(label)
            if "multipart/form-data" in str((op.get("requestBody") or {}).get("content", {})) or "file" in [str(p.get("type")) for p in params]:
                _add(findings, "INFO", "API4:2023", "File upload operation", label, "Verify size limits, content-type validation and storage location.")

    for lst, sev, owasp, title, detail in [
        (unsecured_mut, "HIGH", "API2:2023", "State-changing operation without security requirement",
         "No effective security requirement in the contract. Confirm this is intentionally public."),
        (unsecured_read, "LOW", "API2:2023", "Read operation without security requirement",
         "Publicly readable per the contract. Confirm no sensitive data is returned."),
        (unpaged, "MEDIUM", "API4:2023", "List endpoint without pagination parameters",
         "Returns an array but declares no limit/page/cursor parameter - risk of unbounded responses."),
    ]:
        for label in lst[:12]:
            _add(findings, sev, owasp, title, label, detail)
    if deprecated:
        _add(findings, "LOW", "API9:2023", f"{len(deprecated)} deprecated operation(s) still documented", ", ".join(deprecated[:4]),
             "Verify deprecated endpoints are monitored and retired on schedule.")
    if len(versions) > 1:
        _add(findings, "LOW", "API9:2023", "Multiple API versions documented", ", ".join(sorted(versions)),
             "Older versions frequently lack newer controls; confirm each is intentionally live.")
    if ops and not doc429:
        _add(findings, "LOW", "API4:2023", "No 429 (rate limit) response documented", "all operations",
             "Rate limiting may exist at the gateway, but it is not visible in the contract.")
    if schema_use.get("open_bodies"):
        _add(findings, "INFO", "API3:2023", f"{schema_use['open_bodies']} request bodies allow additional properties", "requestBody schemas",
             "Set additionalProperties: false so unknown properties are rejected.")
    if schema_use.get("unbounded_strings") or schema_use.get("unbounded_arrays"):
        _add(findings, "INFO", "API4:2023", "Unbounded input properties",
             f"{schema_use.get('unbounded_strings', 0)} strings / {schema_use.get('unbounded_arrays', 0)} arrays",
             "Add maxLength/pattern/enum to strings and maxItems to arrays to bound input.")

    # ---- object catalogue
    schemas_node = (spec.get("components") or {}).get("schemas") if is_v3 else spec.get("definitions")
    catalogue = []
    for name, sch in (schemas_node or {}).items():
        props = _schema_props(spec, sch)
        top = {k: v for k, v in props.items() if "." not in k}
        catalogue.append({
            "name": name, "property_count": len(top),
            "sensitive": [k for k in top if SENSITIVE_RESPONSE.search(k)],
            "privileged": [k for k in top if PRIVILEGED_WRITE.match(k)],
            "read_only": [k for k, v in top.items() if v.get("readOnly")],
            "write_only": [k for k, v in top.items() if v.get("writeOnly")],
            "required": list((_resolve(spec, sch) or {}).get("required", []) or [])[:12],
            "properties": [{"name": k, "type": v.get("type") or ("ref" if "$ref" in v else "object"), "format": v.get("format"),
                            "readOnly": bool(v.get("readOnly")), "writeOnly": bool(v.get("writeOnly"))} for k, v in list(top.items())[:40]],
        })
    focus = None
    ask_l = (ask or "").lower()
    for c in catalogue:
        if re.search(r"(?<![a-z0-9])" + re.escape(c["name"].lower()) + r"(?![a-z0-9])", ask_l):
            focus = c
            break

    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    findings.sort(key=lambda f: sev_rank.get(f["severity"], 9))
    return {
        "ok": True, "title": info.get("title") or "Untitled API", "spec_version": version, "api_version": info.get("version"),
        "servers": servers[:5], "security_schemes": scheme_summary,
        "path_count": len(spec["paths"]), "operation_count": len(ops), "methods": method_count,
        "schema_count": len(catalogue), "operations": ops[:200], "schemas": catalogue[:60], "focus_schema": focus,
        "findings": findings, "secured_operations": sum(1 for o in ops if o["secured"]),
    }


def suggest_tests(result: dict, limit: int = 8) -> List[dict]:
    """Per-operation test ideas derived from the review findings and operation shape."""
    tests: List[dict] = []
    by_op: Dict[str, List[dict]] = {}
    for f in result.get("findings", []):
        by_op.setdefault(f["where"], []).append(f)
    for o in result.get("operations", []):
        steps = []
        fs = by_op.get(o["op"], [])
        if any(f["owasp"] == "API1:2023" for f in fs):
            steps.append("Replay with another user's token and object ID (expect 403/404).")
        if any(f["owasp"] == "API5:2023" for f in fs):
            steps.append("Call with a low-privilege token and with no token (expect 401/403).")
        if any(f["owasp"] == "API3:2023" for f in fs):
            if o["method"] in ("POST", "PUT", "PATCH"):
                steps.append("Send extra privileged properties (role, isAdmin, ownerId) and re-read the object.")
            else:
                steps.append("Read the raw response for each role and confirm sensitive properties are absent.")
        if any(f["owasp"] == "API7:2023" for f in fs):
            steps.append("Submit internal/metadata URLs (127.0.0.1, 169.254.169.254) in the URL parameter.")
        if any(f["owasp"] == "API4:2023" for f in fs):
            steps.append("Test very large limit/page values and oversized bodies; look for 429.")
        if not o["secured"] and steps == []:
            continue
        if steps:
            tests.append({"operation": o["op"], "steps": steps})
        if len(tests) >= limit:
            break
    return tests
