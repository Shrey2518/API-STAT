import json
import html
from datetime import datetime, timezone
from fpdf import FPDF

from app.report_dynamic import generate_live_report_html, generate_source_report_html

try:
    from docx import Document
except Exception:
    Document = None


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _safe(value):
    return html.escape("" if value is None else str(value))


def _json(value):
    try:
        return json.dumps(value, indent=2, default=str)
    except Exception:
        return str(value)


def _severity(score):
    try:
        score = float(score or 0)
    except Exception:
        score = 0
    if score >= 8:
        return "Critical", "critical"
    if score >= 6:
        return "High", "high"
    if score >= 4:
        return "Medium", "medium"
    return "Low", "low"


def _recommendations(summary):
    recommendations = []
    if isinstance(summary, dict):
        for key in ("remediation", "recommendations", "ai_remediation"):
            value = summary.get(key)
            if isinstance(value, list):
                recommendations.extend(value)
            elif value:
                recommendations.append(value)
        ai = summary.get("ai")
        if isinstance(ai, dict):
            value = ai.get("remediation") or ai.get("recommendations")
            if isinstance(value, list):
                recommendations.extend(value)
    return list(dict.fromkeys(str(x) for x in recommendations if x))


def _checks(summary):
    value = summary.get("checks", []) if isinstance(summary, dict) else []
    return value if isinstance(value, list) else []


def _findings(summary):
    value = summary.get("findings", []) if isinstance(summary, dict) else []
    return value if isinstance(value, list) else []


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------

class ReportPDF(FPDF):
    def header(self):
        self.set_fill_color(13, 42, 77)
        self.rect(0, 0, 210, 18, "F")
        self.set_text_color(255, 255, 255)
        self.set_font("Helvetica", "B", 14)
        self.cell(0, 12, "API-STAT | Security Assessment", ln=True)
        self.set_text_color(32, 48, 69)
        self.ln(5)

    def footer(self):
        self.set_y(-12)
        self.set_text_color(105, 120, 138)
        self.set_font("Helvetica", "", 8)
        self.cell(0, 8, f"API-STAT | Confidential | Page {self.page_no()}", align="C")


def generate_pdf(scan_id, security_score, risk_score, risk_percent,
                 category_scores, findings, source_name,
                 ai_summary_json, output_path):
    pdf = ReportPDF()
    pdf.add_page()
    pdf.set_auto_page_break(True, 16)

    pdf.set_text_color(23, 36, 58)
    pdf.set_font("Helvetica", "B", 20)
    pdf.cell(0, 10, "API Security Assessment Report", ln=True)
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(100, 116, 139)
    pdf.multi_cell(0, 5, f"Assessment ID: API-STAT-{scan_id:05d}\nSource: {source_name or 'Not specified'}\nGenerated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
    pdf.ln(5)

    pdf.set_fill_color(236, 243, 251)
    pdf.set_text_color(25, 52, 91)
    pdf.set_font("Helvetica", "B", 11)
    pdf.cell(60, 16, "Security Score", border=1, fill=True, align="C")
    pdf.cell(60, 16, "Risk Score", border=1, fill=True, align="C")
    pdf.cell(60, 16, "Findings", border=1, fill=True, align="C", ln=True)
    pdf.set_font("Helvetica", "B", 18)
    pdf.set_text_color(31, 111, 235)
    pdf.cell(60, 14, f"{security_score}/10", border=1, align="C")
    pdf.cell(60, 14, f"{risk_score}/10", border=1, align="C")
    pdf.cell(60, 14, str(len(findings)), border=1, align="C", ln=True)
    pdf.ln(6)

    pdf.set_text_color(23, 36, 58)
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 7, "Executive Summary", ln=True)
    pdf.set_font("Helvetica", "", 9)
    ai = json.loads(ai_summary_json or "{}")
    pdf.multi_cell(0, 5, str(ai.get("executive_summary", "The assessment completed successfully.")))
    pdf.ln(4)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 7, "Category Risk Profile", ln=True)
    pdf.set_font("Helvetica", "", 9)
    for name, value in category_scores.items():
        level, _ = _severity(value)
        pdf.cell(0, 6, f"{name}: {value}/10 ({level})", ln=True)
    pdf.ln(4)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 7, "Prioritized Findings", ln=True)
    for f in sorted(findings, key=lambda x: x.get("finding_score", 0), reverse=True):
        level, _ = _severity(f.get("finding_score", 0))
        pdf.set_font("Helvetica", "B", 9)
        pdf.set_text_color(23, 36, 58)
        title = f.get("title") or f.get("rule_id") or f.get("cve_id") or "Security finding"
        pdf.multi_cell(0, 5, f"[{level}] {title} | {f.get('finding_score', 0)}/10")
        pdf.set_font("Helvetica", "", 8)
        meta = [f"Category: {f.get('category', 'Unclassified')}"]
        if f.get("cve_id"):
            meta.append(f"CVE: {f['cve_id']}")
        if f.get("cvss_score") is not None:
            meta.append(f"CVSS: {f['cvss_score']}")
        meta.append("Public exploit: Yes" if f.get("exploit_available") else "Public exploit: No")
        pdf.multi_cell(0, 4, " | ".join(meta))
        if f.get("file_path") or f.get("endpoint"):
            location = f.get("file_path") or f.get("endpoint")
            pdf.multi_cell(0, 4, f"Location: {location}:{f.get('line_number', '')}")
        if f.get("ai_explanation"):
            pdf.multi_cell(0, 4, "Explanation: " + str(f["ai_explanation"]))
        if f.get("ai_fix_snippet"):
            pdf.multi_cell(0, 4, "Suggested fix: " + str(f["ai_fix_snippet"])[:900])
        pdf.ln(2)

    pdf.output(output_path)
    return output_path


# ---------------------------------------------------------------------------
# DOCX
# ---------------------------------------------------------------------------

def generate_docx(scan_id, security_score, risk_score, risk_percent,
                  category_scores, findings, source_name,
                  ai_summary_json, output_path):
    if Document is None:
        raise RuntimeError("python-docx is not installed.")

    doc = Document()
    doc.add_heading("API-STAT Security Assessment Report", 0)
    doc.add_paragraph(
        f"Assessment ID: API-STAT-{scan_id:05d}\n"
        f"Source: {source_name or 'Not specified'}"
    )

    table = doc.add_table(rows=4, cols=2)
    rows = [
        ("Security score", f"{security_score}/10"),
        ("Risk score", f"{risk_score}/10 ({risk_percent}%)"),
        ("Findings", len(findings)),
        ("Generated", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")),
    ]
    for i, (key, value) in enumerate(rows):
        table.rows[i].cells[0].text = key
        table.rows[i].cells[1].text = str(value)

    doc.add_heading("Executive Summary", level=1)
    ai = json.loads(ai_summary_json or "{}")
    doc.add_paragraph(str(ai.get("executive_summary", "The assessment completed successfully.")))

    doc.add_heading("Category Risk Profile", level=1)
    for name, value in category_scores.items():
        level, _ = _severity(value)
        doc.add_paragraph(f"{name}: {value}/10 ({level})")

    doc.add_heading("Prioritized Findings", level=1)
    for f in sorted(findings, key=lambda x: x.get("finding_score", 0), reverse=True):
        title = f.get("title") or f.get("rule_id") or f.get("cve_id") or "Security finding"
        level, _ = _severity(f.get("finding_score", 0))
        doc.add_heading(title, level=2)
        doc.add_paragraph(
            f"Severity: {level} | Category: {f.get('category', '')} | Score: {f.get('finding_score', 0)}/10"
        )
        if f.get("cve_id"):
            doc.add_paragraph(
                f"CVE: {f['cve_id']} | CVSS: {f.get('cvss_score', '—')} | Public exploit: {'Yes' if f.get('exploit_available') else 'No'}"
            )
        if f.get("ai_explanation"):
            doc.add_paragraph("Explanation: " + str(f["ai_explanation"]))
        if f.get("ai_justification"):
            doc.add_paragraph("AI justification: " + str(f["ai_justification"]))
        if f.get("ai_fix_steps") and isinstance(f["ai_fix_steps"], list):
            doc.add_paragraph("Recommended remediation:")
            for step in f["ai_fix_steps"]:
                doc.add_paragraph(str(step), style="List Bullet")
        if f.get("ai_fix_snippet"):
            doc.add_paragraph("Suggested fix:")
            doc.add_paragraph(str(f["ai_fix_snippet"]))

    doc.save(output_path)
    return output_path


# ---------------------------------------------------------------------------
# Formal HTML report
# ---------------------------------------------------------------------------

def generate_html(title, summary, output_path):
    'Generate a professional, print-ready, color-formatted HTML report.'
    now = datetime.now(timezone.utc).strftime('%d %b %Y, %H:%M UTC')
    data = summary if isinstance(summary, dict) else {'assessment': summary}

    # The live endpoint and source-code scanner have different evidence models; keep
    # their reports purpose-built rather than flattening them into the calculator template.
    if data.get('report_mode') == 'live':
        return generate_live_report_html(title, data, output_path)
    if data.get('report_mode') == 'source':
        return generate_source_report_html(title, data, output_path)

    security_score = data.get('security_score')
    risk_score = data.get('risk_score')
    category_scores = data.get('category_scores') or data.get('category_risk_scores') or {}
    findings = _findings(data)
    checks = _checks(data)
    recs = _recommendations(data)
    ai = data.get('ai') if isinstance(data.get('ai'), dict) else data.get('ai_summary')
    ai = ai or {}
    executive = ai.get('executive_summary') or data.get('executive_summary') or 'The assessment was completed and the available evidence is summarized below.'
    secure_practices = ai.get('secure_api_coding_practices') or ai.get('security_controls') or []

    if security_score is not None:
        try:
            score_class = 'good' if float(security_score) >= 8 else 'warn' if float(security_score) >= 5 else 'bad'
        except Exception:
            score_class = 'neutral'
    else:
        score_class = 'neutral'

    scope = data.get('source') or data.get('url') or data.get('effective_url') or data.get('assessment_scope') or 'API security assessment'
    assessment_type = data.get('type') or data.get('assessment_type') or 'Security Assessment'

    finding_html = []
    for f in sorted(findings, key=lambda x: x.get('finding_score', 0), reverse=True):
        level, cls = _severity(f.get('finding_score', 0))
        meta = [f"<span><b>Category</b> {_safe(f.get('category', 'Unclassified'))}</span>"]
        if f.get('cve_id'):
            meta.append(f"<span><b>CVE</b> {_safe(f.get('cve_id'))}</span>")
        if f.get('cvss_score') is not None:
            meta.append(f"<span><b>CVSS</b> {_safe(f.get('cvss_score'))}</span>")
        meta.append(f"<span><b>Exploit</b> {'Available' if f.get('exploit_available') else 'Not identified'}</span>")
        location = ''
        if f.get('file_path') or f.get('endpoint'):
            location = f"<div class='location'><b>Location:</b> {_safe(f.get('file_path') or f.get('endpoint'))}{(':' + _safe(f.get('line_number'))) if f.get('line_number') else ''}</div>"
        justification = ''
        if f.get('ai_justification'):
            justification = f"<div class='finding-section'><b>AI Justification</b><p>{_safe(f.get('ai_justification'))}</p></div>"
        remediation = ''
        if f.get('ai_fix_snippet'):
            remediation = f"<div class='remediation'><b>Recommended Fix</b><p>{_safe(f.get('ai_fix_snippet'))}</p></div>"
        steps = f.get('ai_fix_steps') if isinstance(f.get('ai_fix_steps'), list) else []
        step_html = ''.join(f"<li>{_safe(step)}</li>" for step in steps)
        finding_html.append(
            "<article class='finding-card'>"
            f"<div class='finding-top'><span class='severity {cls}'>{_safe(level)}</span><span class='finding-score'>Score {_safe(f.get('finding_score', 0))}/10</span></div>"
            f"<h3>{_safe(f.get('title') or f.get('rule_id') or f.get('cve_id') or 'Security finding')}</h3>"
            f"<div class='finding-meta'>{''.join(meta)}</div>"
            f"{location}"
            f"<div class='finding-section'><b>Explanation</b><p>{_safe(f.get('ai_explanation') or f.get('raw_message') or 'No additional explanation was recorded.')}</p></div>"
            f"{justification}{remediation}"
            f"{('<ul class=\\\"steps\\\">' + step_html + '</ul>') if step_html else ''}"
            "</article>"
        )

    check_html = []
    for c in checks:
        status = str(c.get('status', 'INFO')).upper()
        cls = 'pass' if status == 'PASS' else 'warn' if status in {'WARN', 'WARNING'} else 'info'
        check_html.append(
            f"<tr><td>{_safe(c.get('name'))}</td><td><span class='status {cls}'>{_safe(status)}</span></td><td>{_safe(c.get('detail'))}</td></tr>"
        )

    category_html = []
    for name, value in category_scores.items():
        try:
            pct = max(0, min(100, float(value) * 10))
        except Exception:
            pct = 0
        level, cls = _severity(value)
        category_html.append(
            f"<div class='category-card'><div class='category-head'><span>{_safe(name)}</span><b class='score-text {cls}'>{_safe(value)}/10</b></div><div class='bar'><i class='{cls}' style='width:{pct}%'></i></div><small>{_safe(level)} exposure</small></div>"
        )

    rec_html = ''.join(f"<li>{_safe(r)}</li>" for r in recs)
    if not rec_html:
        rec_html = '<li>Review all WARN and HIGH/CRITICAL findings above and validate remediation before release.</li>'

    extra = ''
    if checks:
        extra += (
            "<section class='section'><div class='section-kicker'>CONTROL VERIFICATION</div>"
            "<h2>Observed Security Controls</h2><div class='table-wrap'><table>"
            "<thead><tr><th>Control</th><th>Status</th><th>Evidence</th></tr></thead>"
            f"<tbody>{''.join(check_html)}</tbody></table></div></section>"
        )

    if data.get('factors'):
        factor_rows = ''.join(
            f"<tr><td>{_safe(str(k).replace('_', ' ').title())}</td><td>{_safe(v)}/10</td></tr>"
            for k, v in data.get('factors', {}).items()
        )
        extra += (
            "<section class='section'><div class='section-kicker'>THREAT MODEL</div>"
            "<h2>Risk Input Parameters</h2><div class='table-wrap'><table>"
            f"<thead><tr><th>Parameter</th><th>Value</th></tr></thead><tbody>{factor_rows}</tbody></table></div></section>"
        )

    if secure_practices:
        practice_rows = []
        for item in secure_practices:
            if not isinstance(item, dict):
                practice_rows.append(f"<tr><td colspan='4'>{_safe(item)}</td></tr>")
                continue
            practice = item.get('practice') or item.get('control') or item.get('name') or 'Security practice'
            status = str(item.get('status', 'INFO')).upper()
            cls = 'pass' if status == 'PASS' else 'warn' if status in {'WARN', 'WARNING', 'FAIL'} else 'info'
            evidence = item.get('evidence') or item.get('why') or item.get('detail') or ''
            remediation = item.get('remediation') or item.get('fix') or ''
            if isinstance(remediation, list): remediation = '; '.join(str(x) for x in remediation)
            practice_rows.append(
                f"<tr><td>{_safe(practice)}</td><td><span class='status {cls}'>{_safe(status)}</span></td><td>{_safe(evidence)}</td><td>{_safe(remediation)}</td></tr>"
            )
        extra += (
            "<section class='section'><div class='section-kicker'>SECURE API CODING REVIEW</div>"
            "<h2>Observed Coding Practices</h2><p class='executive'>AI-assisted review of authentication, authorization, input validation, secrets and configuration practices observed in the submitted API source.</p>"
            "<div class='table-wrap'><table><thead><tr><th>Practice / Control</th><th>Status</th><th>Evidence</th><th>Recommended Action</th></tr></thead><tbody>"
            + ''.join(practice_rows)
            + "</tbody></table></div></section>"
        )

    raw = {k: v for k, v in data.items() if k not in {'findings', 'checks', 'ai_summary', 'ai'}}

    template = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>
<style>
:root{--navy:#102a4c;--ink:#18283d;--muted:#65768c;--line:#d9e2ee;--paper:#fff;--bg:#eef3f8;--green:#16855b;--amber:#c98200;--red:#d64557;--bluegray:#41637f}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,Segoe UI,Arial,sans-serif;line-height:1.55}.report{max-width:1120px;margin:34px auto 60px;padding:0 22px}
.cover{background:linear-gradient(135deg,#0b2444,#18497f 58%,#2b70cb);color:#fff;border-radius:22px;padding:38px 42px;box-shadow:0 20px 55px rgba(16,42,76,.18)}.brand{font-weight:900;letter-spacing:.11em;font-size:13px;opacity:.9}.cover h1{font-size:40px;line-height:1.08;margin:18px 0 10px}.cover p{margin:6px 0;color:#dceaff}.meta{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:28px}.meta-card{background:rgba(255,255,255,.11);border:1px solid rgba(255,255,255,.18);padding:14px;border-radius:13px}.meta-card small{display:block;color:#bcd3ef;text-transform:uppercase;letter-spacing:.08em;font-size:10px}.meta-card b{display:block;margin-top:4px}
.section{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:28px;margin-top:18px;box-shadow:0 9px 28px rgba(18,37,63,.06)}.section-kicker{font-size:10px;letter-spacing:.17em;font-weight:900;color:#6d839c}h2{font-size:24px;margin:6px 0 12px}h3{margin:8px 0;font-size:18px}.executive{font-size:16px;color:#40556e}
.score-grid{display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:14px}.score-card{padding:20px;border-radius:15px;background:#f7faff;border:1px solid #dce8f6}.score-card.main{background:linear-gradient(135deg,#eaf3ff,#f9fcff)}.score-label{font-size:11px;text-transform:uppercase;letter-spacing:.12em;color:#657a92;font-weight:900}.score{font-size:42px;font-weight:950;color:#173a67;margin-top:6px}.score.good{color:var(--green)}.score.warn{color:var(--amber)}.score.bad{color:var(--red)}
.category-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.category-card{border:1px solid var(--line);border-radius:14px;padding:16px;background:#fbfcfe}.category-head{display:flex;justify-content:space-between;gap:10px}.score-text{font-weight:900}.score-text.good{color:var(--green)}.score-text.warn{color:var(--amber)}.score-text.bad{color:var(--red)}.bar{height:8px;background:#e8edf4;border-radius:999px;overflow:hidden;margin:10px 0}.bar i{display:block;height:100%;border-radius:999px;background:#7896b6}.bar i.good{background:linear-gradient(90deg,#59c98f,#16855b)}.bar i.warn{background:linear-gradient(90deg,#f2c15d,#c98200)}.bar i.bad{background:linear-gradient(90deg,#f18c99,#d64557)}.category-card small{color:var(--muted)}
.finding-card{border:1px solid var(--line);border-left:5px solid #9fb5cc;border-radius:14px;padding:20px;margin:13px 0;background:#fff}.finding-top{display:flex;justify-content:space-between;align-items:center;gap:12px}.severity,.status{display:inline-flex;align-items:center;padding:5px 10px;border-radius:999px;font-size:11px;font-weight:900}.severity.critical,.severity.high{background:#fff0f2;color:var(--red)}.severity.medium{background:#fff7e7;color:var(--amber)}.severity.low{background:#eaf8f1;color:var(--green)}.finding-score{font-size:12px;color:var(--muted);font-weight:800}.finding-meta{display:flex;flex-wrap:wrap;gap:9px;color:#5d7189;font-size:12px;margin:12px 0}.finding-meta span{background:#f4f7fb;border:1px solid #e3e9f1;border-radius:8px;padding:6px 8px}.location{font-size:12px;color:#536880;margin:8px 0 14px}.finding-section{margin-top:14px}.finding-section b,.remediation b{font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:#647a92}.finding-section p,.remediation p{margin:5px 0;color:#42566e}.remediation{background:#f3f8fd;border:1px solid #d4e3f2;padding:14px;border-radius:12px;margin-top:14px}.steps{color:#42566e}.table-wrap{overflow:auto;border:1px solid var(--line);border-radius:12px}table{width:100%;border-collapse:collapse;background:#fff}th,td{padding:12px 14px;border-bottom:1px solid #e6ebf2;text-align:left;vertical-align:top}th{background:#f3f6fa;color:#425872;font-size:12px;text-transform:uppercase;letter-spacing:.07em}td{font-size:13px}tr:last-child td{border-bottom:0}.status.pass{background:#eaf8f1;color:var(--green)}.status.warn{background:#fff7e7;color:var(--amber)}.status.info{background:#edf4fb;color:var(--bluegray)}
.footer{text-align:center;color:#7a8ca0;font-size:11px;margin-top:20px}pre{background:#0b1930;color:#e9f1fb;padding:16px;border-radius:12px;overflow:auto;font-size:11px}@media(max-width:800px){.meta,.score-grid,.category-grid{grid-template-columns:1fr}.cover{padding:28px 24px}.cover h1{font-size:31px}}@media print{body{background:#fff}.report{max-width:none;margin:0;padding:0}.section,.cover{box-shadow:none;break-inside:avoid}.cover{border-radius:0}.finding-card{break-inside:avoid}}
</style>
</head>
<body>
<div class="report">
<header class="cover"><div class="brand">API-STAT • API SECURITY WORKBENCH</div><h1>__TITLE__</h1><p>Formal security assessment and remediation report</p><div class="meta"><div class="meta-card"><small>Assessment type</small><b>__TYPE__</b></div><div class="meta-card"><small>Scope</small><b>__SCOPE__</b></div><div class="meta-card"><small>Generated</small><b>__DATE__</b></div></div></header>
<section class="section"><div class="section-kicker">EXECUTIVE SUMMARY</div><h2>Management Overview</h2><p class="executive">__EXECUTIVE__</p></section>
<section class="section"><div class="section-kicker">RISK SNAPSHOT</div><h2>Assessment Results</h2><div class="score-grid"><div class="score-card main"><div class="score-label">Security score</div><div class="score __SCORE_CLASS__">__SECURITY_SCORE__</div></div><div class="score-card"><div class="score-label">Risk score</div><div class="score">__RISK_SCORE__</div></div><div class="score-card"><div class="score-label">Findings</div><div class="score">__FINDING_COUNT__</div></div></div></section>
__CATEGORY_SECTION__
<section class="section"><div class="section-kicker">FINDINGS</div><h2>Prioritized Security Findings</h2>__FINDINGS__</section>
__EXTRA__
<section class="section"><div class="section-kicker">REMEDIATION</div><h2>Recommended Actions</h2><ol class="steps">__REMEDIATION__</ol></section>
<section class="section"><div class="section-kicker">METHODOLOGY</div><h2>Assessment Notes</h2><p class="executive">API-STAT combines deterministic security checks with AI-assisted analysis. Results should be reviewed by an application owner or security engineer before production remediation. Live API findings are based on observable endpoint behavior and do not replace a full penetration test.</p></section>
<section class="section"><div class="section-kicker">TECHNICAL APPENDIX</div><h2>Assessment Metadata</h2><details><summary>Show technical payload</summary><pre>__RAW__</pre></details></section>
<div class="footer">Generated by API-STAT • Treat this report as security-sensitive internal documentation.</div>
</div></body></html>'''

    category_section = ''
    if category_html:
        category_section = "<section class='section'><div class='section-kicker'>SECURITY DOMAINS</div><h2>Category Risk Profile</h2><div class='category-grid'>" + ''.join(category_html) + '</div></section>'

    findings_section = ''.join(finding_html) if finding_html else "<p class='executive'>No actionable findings were recorded for this assessment.</p>"

    replacements = {
        '__TITLE__': _safe(title),
        '__TYPE__': _safe(assessment_type),
        '__SCOPE__': _safe(scope),
        '__DATE__': _safe(now),
        '__EXECUTIVE__': _safe(executive),
        '__SCORE_CLASS__': score_class,
        '__SECURITY_SCORE__': _safe(f'{security_score}/10' if security_score is not None else 'N/A'),
        '__RISK_SCORE__': _safe(f'{risk_score}/10' if risk_score is not None else 'N/A'),
        '__FINDING_COUNT__': str(len(findings)),
        '__CATEGORY_SECTION__': category_section,
        '__FINDINGS__': findings_section,
        '__EXTRA__': extra,
        '__REMEDIATION__': rec_html,
        '__RAW__': _safe(_json(raw)),
    }

    body = template
    for key, value in replacements.items():
        body = body.replace(key, value)

    with open(output_path, 'w', encoding='utf-8') as handle:
        handle.write(body)
    return output_path
