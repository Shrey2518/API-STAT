CATEGORIES=['Cryptographic Failure','Broken Authentication','Security Misconfiguration','Design Flaw']

def run_scoring(findings):
    for f in findings:
        base=float(f.get('base_severity') or 0)
        exploit=1.3 if f.get('exploit_available') else 1.0
        conf=float(f.get('ai_relevance_confidence',1.0) or 0)
        f['finding_score']=round(min(10,base*exploit*conf),2)
    cats={c:0.0 for c in CATEGORIES}
    for c in CATEGORIES:
        vals=[f['finding_score'] for f in findings if f.get('category')==c and f.get('relevance','')!='NOT_APPLICABLE']
        cats[c]=round(sum(vals)/len(vals),2) if vals else 0.0
    overall_risk=round(sum(cats.values())/len(CATEGORIES),2)
    security_score=round(max(0,10-overall_risk),2)
    risk_percent=round(overall_risk*10,1)
    return findings,cats,security_score,overall_risk,risk_percent
