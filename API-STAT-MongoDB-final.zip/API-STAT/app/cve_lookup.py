import json, os, re, csv, io, time
from pathlib import Path
import requests

OSV_API_URL='https://api.osv.dev/v1/query'
EXPLOITDB_CSV_URL=os.getenv('EXPLOITDB_CSV_URL','https://gitlab.com/exploit-database/exploitdb/-/raw/main/files_exploits.csv')
CACHE_DIR=Path(os.getenv('CACHE_DIR','cache')); CACHE_DIR.mkdir(parents=True, exist_ok=True)
EXPLOIT_CACHE=CACHE_DIR/'files_exploits.csv'


def _version(value):
    m=re.search(r'(\d+(?:\.\d+){0,3})', str(value or ''))
    return m.group(1) if m else ''

def parse_requirements(path):
    pairs=[]
    for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
        line=line.strip()
        if not line or line.startswith('#') or line.startswith(('-r','--')): continue
        m=re.match(r'^([A-Za-z0-9_.-]+)\s*(?:==|~=|>=|<=|>|<|===)\s*([A-Za-z0-9_.-]+)',line)
        if m and _version(m.group(2)): pairs.append((m.group(1),_version(m.group(2)),'PyPI'))
    return pairs

def parse_package(path):
    try: data=json.loads(path.read_text(encoding='utf-8',errors='ignore'))
    except Exception: return []
    out=[]
    for sec in ('dependencies','devDependencies','peerDependencies'):
        for lib,ver in data.get(sec,{}).items():
            if _version(ver): out.append((lib,_version(ver),'npm'))
    return out

def parse_go_mod(path):
    out=[]
    for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
        m=re.match(r'\s*([\w./-]+)\s+v([0-9][^\s]+)',line)
        if m: out.append((m.group(1),m.group(2),'Go'))
    return out

def discover_dependency_pairs(root):
    pairs=[]
    for p in root.rglob('*'):
        if not p.is_file(): continue
        n=p.name.lower()
        try:
            if n=='requirements.txt': pairs+=parse_requirements(p)
            elif n=='package.json': pairs+=parse_package(p)
            elif n=='go.mod': pairs+=parse_go_mod(p)
        except Exception: pass
    return list(dict.fromkeys(pairs))

def _cvss(vuln):
    scores=[]
    for item in vuln.get('severity',[]) or []:
        s=str(item.get('score',''))
        m=re.search(r'(?<!\d)(\d(?:\.\d+)?)(?!\d)',s)
        if m:
            try: scores.append(float(m.group(1)))
            except ValueError: pass
    for key in ('database_specific','credits'):
        _=key
    return max(scores) if scores else None

def query_osv(lib,version,ecosystem):
    try:
        r=requests.post(OSV_API_URL,json={'package':{'name':lib,'ecosystem':ecosystem},'version':version},timeout=12)
        r.raise_for_status(); vulns=r.json().get('vulns',[])
    except requests.RequestException:
        return []
    out=[]
    for v in vulns:
        cvss=_cvss(v)
        aliases=v.get('aliases') or []
        cve=next((x for x in aliases if str(x).startswith('CVE-')), v.get('id'))
        out.append({
            'source':'cve','tool':'osv','library':lib,'installed_version':version,
            'cve_id':cve,'osv_id':v.get('id'),'base_severity':cvss or 5.0,'cvss_score':cvss,
            'summary':(v.get('summary') or '')[:1000], 'details':(v.get('details') or '')[:2500],
            'ai_relevance_confidence':0.5
        })
    return out

def _download_exploitdb():
    max_age=int(os.getenv('EXPLOITDB_CACHE_HOURS','24'))*3600
    if EXPLOIT_CACHE.exists() and time.time()-EXPLOIT_CACHE.stat().st_mtime < max_age:
        return True
    try:
        r=requests.get(EXPLOITDB_CSV_URL,timeout=30,headers={'User-Agent':'API-STAT/3.0'})
        r.raise_for_status(); EXPLOIT_CACHE.write_bytes(r.content); return True
    except requests.RequestException:
        return EXPLOIT_CACHE.exists()

def exploitdb_match(cve_id):
    if not cve_id or not _download_exploitdb(): return None
    needle=cve_id.upper()
    try:
        with EXPLOIT_CACHE.open('r',encoding='utf-8',errors='ignore',newline='') as fh:
            reader=csv.DictReader(fh)
            for row in reader:
                blob=' '.join(str(v or '') for v in row.values()).upper()
                if needle in blob:
                    return {'available':True,'exploit_id':str(row.get('id') or ''),'description':str(row.get('description') or '')[:500]}
    except Exception: return None
    return None

def run_cve_scan(root,progress_cb=None):
    pairs=discover_dependency_pairs(root); out=[]
    for i,(lib,ver,eco) in enumerate(pairs):
        vulns=query_osv(lib,ver,eco)
        for v in vulns:
            ex=exploitdb_match(v.get('cve_id'))
            if ex:
                v['exploit_available']=True; v['exploit_id']=ex['exploit_id']; v['exploit_description']=ex['description']
            else: v['exploit_available']=False
            v['dependency_context']=f'{lib} {ver} ({eco})'
            out.append(v)
        if progress_cb: progress_cb(42+int(18*(i+1)/max(1,len(pairs))))
    return out
