"""Small, self-contained security analysers used by chatbot capabilities:
JWT inspection (decode only - never verifies or trusts), HTTP header review,
and CVE lookups (NVD, falling back to OSV)."""
from __future__ import annotations

import base64
import json
import re
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import requests

JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_\-]{5,}\.eyJ[A-Za-z0-9_\-]{5,}\.[A-Za-z0-9_\-]*")
CVE_RE = re.compile(r"\bCVE-\d{4}-\d{4,7}\b", re.I)


def _b64json(part: str) -> Optional[dict]:
    try:
        pad = "=" * (-len(part) % 4)
        data = json.loads(base64.urlsafe_b64decode(part + pad).decode("utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _finding(sev: str, title: str, detail: str, fix: str = "") -> dict:
    return {"severity": sev, "title": title, "detail": detail, "fix": fix}


# ============================================================ JWT
def analyze_jwt(token: str, now: Optional[float] = None) -> dict:
    """Decode (without verifying) and review a JWT. Signature is masked in the output."""
    now = now or time.time()
    parts = token.split(".")
    if len(parts) != 3:
        return {"ok": False, "error": "Not a three-part JWT."}
    header, payload = _b64json(parts[0]), _b64json(parts[1])
    if header is None or payload is None:
        return {"ok": False, "error": "Header or payload is not valid base64url JSON."}
    issues: List[dict] = []
    alg = str(header.get("alg", "")).strip()
    if not alg:
        issues.append(_finding("HIGH", "No 'alg' in header", "The token does not declare a signing algorithm.", "Reject tokens without an allow-listed algorithm."))
    elif alg.lower() == "none":
        issues.append(_finding("CRITICAL", "Unsigned token (alg=none)", "If the API accepts this, anyone can forge tokens.", "Reject alg=none; pin accepted algorithms server-side."))
    elif alg.upper().startswith("HS"):
        issues.append(_finding("INFO", f"Symmetric algorithm ({alg})", "The same secret signs and verifies; a weak secret can be brute-forced offline, and RS256->HS256 confusion is possible if keys are mishandled.", "Use a long random secret or asymmetric keys (RS256/ES256) and pin the algorithm."))
    if not parts[2]:
        issues.append(_finding("HIGH", "Empty signature", "The token carries no signature.", "Reject unsigned tokens."))
    for h in ("jku", "x5u", "jwk", "kid"):
        if h in header:
            issues.append(_finding("MEDIUM", f"Header '{h}' present", "Key-selection headers are a classic injection/SSRF vector (attacker-controlled key URL or path traversal in kid).", "Ignore these headers or resolve keys only from a fixed, trusted key set."))
    exp, iat, nbf = payload.get("exp"), payload.get("iat"), payload.get("nbf")
    status = "no expiry"
    if not isinstance(exp, (int, float)):
        issues.append(_finding("HIGH", "No expiry (exp)", "The token never expires, so a leaked token is valid forever.", "Issue short-lived access tokens with exp and use refresh tokens."))
    else:
        status = "expired" if exp < now else "valid (not expired)"
        if exp < now:
            issues.append(_finding("INFO", "Token is expired", f"exp was {_ts(exp)}. A correct API must reject it.", "Test that the API returns 401 for this token."))
        if isinstance(iat, (int, float)) and exp - iat > 24 * 3600:
            issues.append(_finding("MEDIUM", "Long lifetime", f"Lifetime is about {round((exp - iat) / 3600)} hours.", "Prefer minutes for access tokens."))
    if isinstance(nbf, (int, float)) and nbf > now:
        issues.append(_finding("INFO", "Not valid yet (nbf in the future)", f"nbf is {_ts(nbf)}.", ""))
    for claim in ("iss", "aud"):
        if claim not in payload:
            issues.append(_finding("MEDIUM", f"No '{claim}' claim", "Without issuer/audience checks a token minted for another service may be accepted.", f"Set and validate {claim}."))
    for k in payload:
        if re.search(r"pass|secret|ssn|card|cvv|private", k, re.I):
            issues.append(_finding("HIGH", f"Sensitive claim '{k}' in payload", "JWT payloads are readable by anyone holding the token.", "Never put secrets or regulated data in claims."))
    authz = [k for k in payload if k.lower() in ("role", "roles", "scope", "scopes", "scp", "permissions", "is_admin", "admin", "groups")]
    if authz:
        issues.append(_finding("INFO", f"Authorization data in token ({', '.join(authz)})", "Claims are client-visible; the API must still enforce object- and function-level checks server-side.", "Treat claims as inputs to authorization, not the whole decision."))
    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    issues.sort(key=lambda i: sev_rank[i["severity"]])
    return {
        "ok": True, "header": header, "payload": payload, "algorithm": alg or None, "status": status,
        "signature": f"{parts[2][:6]}…[masked]" if parts[2] else "(empty)", "issues": issues,
        "times": {k: _ts(v) for k, v in (("issued", iat), ("not_before", nbf), ("expires", exp)) if isinstance(v, (int, float))},
    }


def _ts(v: float) -> str:
    try:
        return time.strftime("%Y-%m-%d %H:%M:%SZ", time.gmtime(v))
    except Exception:
        return str(v)


# ============================================================ HTTP headers
_HEADER_LINE = re.compile(r"^\s*([A-Za-z][A-Za-z0-9\-]{1,60})\s*:\s*(.*)$")
_REQUEST_ONLY = {"host", "user-agent", "authorization", "cookie", "accept", "accept-encoding", "accept-language", "origin", "referer", "content-length"}


def parse_headers(text: str) -> Tuple[Dict[str, List[str]], Optional[str]]:
    """Parse pasted raw headers -> ({lowercase name: [values]}, status_line)."""
    headers: Dict[str, List[str]] = {}
    status = None
    for line in text.splitlines():
        if re.match(r"^\s*HTTP/\d(?:\.\d)?\s+\d{3}", line):
            status = line.strip()
            continue
        m = _HEADER_LINE.match(line)
        if m:
            headers.setdefault(m.group(1).lower(), []).append(m.group(2).strip())
    return headers, status


def looks_like_headers(text: str) -> bool:
    if re.search(r"^\s*HTTP/\d(?:\.\d)?\s+\d{3}", text, re.M):
        return True
    known = ("content-type", "strict-transport-security", "set-cookie", "access-control-allow-origin", "cache-control",
             "x-content-type-options", "server", "content-security-policy", "x-frame-options", "www-authenticate", "x-powered-by")
    h, _ = parse_headers(text)
    return len(h) >= 2 and sum(1 for k in h if k in known) >= 2


def analyze_headers(headers: Dict[str, List[str]], status: Optional[str] = None, https: Optional[bool] = None) -> dict:
    h = {k.lower(): v for k, v in headers.items()}
    first = lambda n: (h.get(n) or [""])[0]
    checks: List[dict] = []

    def add(name, st, detail, fix="", owasp="API8:2023"):
        checks.append({"name": name, "status": st, "detail": detail, "fix": fix, "owasp": owasp})

    if set(h) & _REQUEST_ONLY and not (set(h) & {"content-type", "server", "set-cookie", "strict-transport-security", "cache-control"}) and not status:
        return {"ok": True, "direction": "request", "checks": [], "counts": {},
                "notes": ["These look like REQUEST headers. Paste the RESPONSE headers to review security controls. "
                          "Never log or share Authorization/Cookie values."]}
    # HSTS
    if "strict-transport-security" not in h:
        add("HSTS", "WARN", "Strict-Transport-Security is missing.", "Send Strict-Transport-Security: max-age=31536000; includeSubDomains")
    else:
        m = re.search(r"max-age\s*=\s*(\d+)", first("strict-transport-security"), re.I)
        age = int(m.group(1)) if m else 0
        add("HSTS", "PASS" if age >= 15552000 else "WARN", f"max-age={age}." + ("" if age >= 15552000 else " Shorter than 180 days."),
            "" if age >= 15552000 else "Use max-age=31536000 or more.")
    # nosniff
    add("X-Content-Type-Options", "PASS" if "nosniff" in first("x-content-type-options").lower() else "WARN",
        "nosniff is set." if "nosniff" in first("x-content-type-options").lower() else "nosniff is missing.",
        "" if "nosniff" in first("x-content-type-options").lower() else "Send X-Content-Type-Options: nosniff")
    # content type
    ct = first("content-type")
    add("Content-Type", "PASS" if ct else "WARN", f"Content-Type: {ct}" if ct else "No Content-Type on the response.", "" if ct else "Always send an accurate Content-Type.")
    # cache
    cc = first("cache-control").lower()
    sensitive = "authorization" in h or "set-cookie" in h
    if "no-store" in cc:
        add("Cache-Control", "PASS", "no-store is set.")
    elif sensitive:
        add("Cache-Control", "WARN", "Response to an authenticated/cookie-setting request without no-store.", "Send Cache-Control: no-store for sensitive responses.")
    else:
        add("Cache-Control", "INFO", "Cache-Control: " + (cc or "not set") + ". Fine for public data; use no-store for sensitive responses.")
    # framing / CSP
    csp = first("content-security-policy").lower()
    if "frame-ancestors" in csp or "x-frame-options" in h:
        add("Clickjacking protection", "PASS", "frame-ancestors or X-Frame-Options present.")
    else:
        add("Clickjacking protection", "INFO", "No frame-ancestors / X-Frame-Options (mainly relevant if responses render in browsers).", "Add Content-Security-Policy: frame-ancestors 'none'")
    # CORS
    acao, acac = first("access-control-allow-origin"), first("access-control-allow-credentials").lower()
    if acao == "*" and acac == "true":
        add("CORS", "FAIL", "Wildcard origin together with credentials.", "Use an explicit origin allow-list; never combine * with credentials.", "API8:2023")
    elif acao == "null":
        add("CORS", "FAIL", "Origin 'null' is allowed (sandboxed iframes/files can read responses).", "Remove null from the allow-list.")
    elif acao == "*":
        add("CORS", "WARN", "Wildcard CORS - any website can read non-credentialed responses.", "Restrict to trusted origins if the data is not public.")
    elif acao:
        add("CORS", "PASS" if acac != "true" else "INFO", f"Allows {acao}" + (" with credentials - confirm the origin is validated against an allow-list, not reflected." if acac == "true" else "."))
    else:
        add("CORS", "PASS", "No cross-origin access granted on this response.")
    # cookies
    for c in h.get("set-cookie", []):
        name = c.split("=", 1)[0].strip()
        low = c.lower()
        miss = [f for f, ok in (("Secure", "secure" in low), ("HttpOnly", "httponly" in low), ("SameSite", "samesite" in low)) if not ok]
        add(f"Cookie '{name}'", "WARN" if miss else "PASS", ("Missing flags: " + ", ".join(miss) + ".") if miss else "Secure, HttpOnly and SameSite set.",
            "Set Secure; HttpOnly; SameSite=Lax (or Strict)." if miss else "", "API2:2023")
    # disclosure
    for hn in ("server", "x-powered-by", "x-aspnet-version", "x-aspnetmvc-version"):
        if hn in h and re.search(r"\d", first(hn)):
            add("Version disclosure", "WARN", f"{hn}: {first(hn)} reveals software/version.", "Remove or genericise the header.")
        elif hn in ("x-powered-by",) and hn in h:
            add("Technology disclosure", "INFO", f"{hn}: {first(hn)}", "Remove the header.")
    # rate limits
    rl = [k for k in h if k in ("retry-after",) or k.startswith("ratelimit") or k.startswith("x-ratelimit") or k.startswith("x-rate-limit")]
    add("Rate-limit signalling", "PASS" if rl else "INFO", ("Present: " + ", ".join(rl)) if rl else "No rate-limit headers observed (limits may still exist).", "", "API4:2023")
    if status and re.search(r"\s401\b", status) and "www-authenticate" not in h:
        add("WWW-Authenticate", "INFO", "401 without WWW-Authenticate.", "Send WWW-Authenticate for 401 responses.", "API2:2023")
    if "x-xss-protection" in h:
        add("X-XSS-Protection", "INFO", "Deprecated header; rely on CSP instead.")
    if https is False:
        add("Transport", "FAIL", "Response was served over HTTP.", "Serve only over HTTPS.")
    counts = {s: sum(1 for c in checks if c["status"] == s) for s in ("FAIL", "WARN", "INFO", "PASS")}
    return {"ok": True, "direction": "response", "status_line": status, "checks": checks, "counts": counts, "notes": []}


# ============================================================ CVE lookup
_CACHE: Dict[str, Tuple[float, dict]] = {}
_CACHE_LOCK = threading.Lock()
_TTL = 24 * 3600
_HEADERS = {"User-Agent": "API-STAT-Agent/5.0"}


def _nvd(cve: str, timeout: float) -> Optional[dict]:
    r = requests.get("https://services.nvd.nist.gov/rest/json/cves/2.0", params={"cveId": cve}, headers=_HEADERS, timeout=timeout)
    if r.status_code != 200:
        return None
    vulns = (r.json() or {}).get("vulnerabilities") or []
    if not vulns:
        return None
    c = vulns[0].get("cve", {})
    desc = next((d.get("value") for d in c.get("descriptions", []) if d.get("lang") == "en"), "")
    score = sev = vector = None
    metrics = c.get("metrics", {}) or {}
    for key in ("cvssMetricV40", "cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        arr = metrics.get(key)
        if arr:
            data = arr[0].get("cvssData", {})
            score, vector = data.get("baseScore"), data.get("vectorString")
            sev = data.get("baseSeverity") or arr[0].get("baseSeverity")
            break
    cwes = [d.get("value") for w in c.get("weaknesses", []) for d in w.get("description", []) if str(d.get("value", "")).startswith("CWE-")]
    return {"id": cve, "source": "NVD", "summary": desc[:600], "cvss": score, "severity": (sev or "").upper() or None, "vector": vector,
            "cwe": list(dict.fromkeys(cwes))[:4], "published": (c.get("published") or "")[:10],
            "kev": bool(c.get("cisaExploitAdd")), "url": f"https://nvd.nist.gov/vuln/detail/{cve}"}


def _osv(cve: str, timeout: float) -> Optional[dict]:
    r = requests.get(f"https://api.osv.dev/v1/vulns/{cve}", headers=_HEADERS, timeout=timeout)
    if r.status_code != 200:
        return None
    v = r.json() or {}
    sev = next((s.get("score") for s in v.get("severity", []) if s.get("score")), None)
    return {"id": cve, "source": "OSV", "summary": (v.get("summary") or v.get("details") or "")[:600], "cvss": None, "severity": None,
            "vector": sev, "cwe": [], "published": (v.get("published") or "")[:10], "kev": False, "url": f"https://osv.dev/vulnerability/{cve}"}


def lookup_cve(cve: str, timeout: float = 6.0) -> dict:
    cve = cve.upper()
    with _CACHE_LOCK:
        hit = _CACHE.get(cve)
        if hit and time.time() - hit[0] < _TTL:
            return hit[1]
    result: Optional[dict] = None
    err = None
    for fn in (_nvd, _osv):
        try:
            result = fn(cve, timeout)
        except (requests.RequestException, ValueError) as exc:
            err = type(exc).__name__
            result = None
        if result:
            break
    if result:
        with _CACHE_LOCK:
            _CACHE[cve] = (time.time(), result)
        return result
    return {"id": cve, "source": None, "summary": "", "error": "Lookup unavailable" + (f" ({err})" if err else " (not found in NVD/OSV)"),
            "url": f"https://nvd.nist.gov/vuln/detail/{cve}"}
