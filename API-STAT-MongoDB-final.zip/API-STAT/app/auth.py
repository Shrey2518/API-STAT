from datetime import datetime
from flask import Blueprint, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from app.models import db, User, ActionLog


auth_bp = Blueprint("auth", __name__)


@auth_bp.post("/signup")
def signup():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))

    if not email or len(password) < 6:
        return jsonify({"error": "Email and password (6+ chars) required"}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Account already exists"}), 409

    user = User(
        email=email,
        password_hash=generate_password_hash(password),
    )
    user.last_login_at = datetime.utcnow()
    db.session.add(user)
    db.session.commit()
    login_user(user)

    db.session.add(
        ActionLog(
            user_id=user.id,
            action="signup",
            details="Account created",
        )
    )
    db.session.commit()

    return jsonify({"user_id": user.id, "email": user.email}), 201


@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    user = User.query.filter_by(email=email).first()

    if not user or not check_password_hash(
        user.password_hash,
        str(data.get("password", "")),
    ):
        return jsonify({"error": "Invalid credentials"}), 401

    user.last_login_at = datetime.utcnow()
    db.session.add(user)
    db.session.commit()
    login_user(user)

    db.session.add(
        ActionLog(
            user_id=user.id,
            action="login",
            details="Password login",
        )
    )
    db.session.commit()

    return jsonify({"user_id": user.id, "email": user.email})


@auth_bp.post("/logout")
@login_required
def logout():
    db.session.add(
        ActionLog(
            user_id=current_user.id,
            action="logout",
            details="User logged out",
        )
    )
    db.session.commit()
    logout_user()
    return jsonify({"message": "logged out"})


@auth_bp.get("/me")
@login_required
def me():
    return jsonify({
        "user_id": current_user.id,
        "email": current_user.email,
    })
