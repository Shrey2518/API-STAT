import json,os,shutil,time,subprocess,hashlib
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from flask import Blueprint,request,jsonify,send_file,current_app,send_from_directory,Response,stream_with_context
from flask_login import login_required,current_user
from werkzeug.utils import secure_filename
from app.models import db,Scan,Finding,ActionLog,PolicyDocument,CalculatorAssessment,ConfigAssessment,LiveAPIAssessment
from app.scan_engine import acquire_source, discover_files, run_fast_static_scan, live_api_test, basic_api_config_check, run_api_config_command, source_contains_api_key, extract_endpoints, endpoint_context, find_dependency_context
from app.cve_lookup import run_cve_scan
from app.agent import agent_reply, retrieve_policy, analyze_visual_evidence
from app.pipeline import run_pipeline, STAGES
from app.capabilities import Ctx, public_registry, BY_ID
from app.report_ingest import parse_upload, ParseError, MAX_UPLOAD_BYTES, ALLOWED_EXT, redact_secrets
from app.llm import enrich_findings_batch,enrich_cves_batch,analyze_design_flaws,explain_scan,provider_name,model_name,analyze_live_api,analyze_api_calculator
from app.scoring import run_scoring,CATEGORIES
from app.report import generate_pdf,generate_docx,generate_html

scan_bp=Blueprint('scan',__name__)
EXECUTOR=ThreadPoolExecutor(max_workers=int(os.getenv('SCAN_WORKERS','2')))
ROOT=os.getenv('WORK_ROOT','uploads_tmp');os.makedirs(ROOT,exist_ok=True)

def _owned_scan(scan_id):return Scan.query.filter_by(id=scan_id,user_id=current_user.id).first_or_404()
def _update(scan_id,progress,stage,status=None,**kwargs):
    scan=Scan.query.get(scan_id)
    if not scan:return
    scan.progress=max(int(scan.progress or 0),int(progress));scan.stage=stage
    if status:scan.status=status
    for k,v in kwargs.items():setattr(scan,k,v)
    db.session.commit()

def _pipeline_step(name,status):return {'step':name,'status':status}


def _redact_target_url(value):
    """Remove URL userinfo and credential-like query values before storing a target."""
    raw = str(value or '')
    try:
        parts = urlsplit(raw)
        sensitive_names = {
            'api-key', 'apikey', 'api_key', 'key', 'token', 'access-token',
            'access_token', 'refresh-token', 'refresh_token', 'secret',
            'client-secret', 'client_secret', 'password', 'passwd',
            'authorization', 'signature', 'x-api-key', 'auth',
        }
        query = []
        for name, item in parse_qsl(parts.query, keep_blank_values=True):
            normalized = name.strip().lower().replace('-', '_')
            query.append((name, '[REDACTED]' if normalized in {n.replace('-', '_') for n in sensitive_names} else item))
        # Drop any embedded username/password but keep the host and port.
        netloc = parts.netloc.rsplit('@', 1)[-1]
        return urlunsplit((parts.scheme, netloc, parts.path, urlencode(query), parts.fragment))
    except (ValueError, TypeError):
        return redact_secrets(raw)


def _redact_security_evidence(value, key=''):
    """Redact credential-bearing fields before AI processing or persistence."""
    sensitive = ('authorization', 'api-key', 'apikey', 'cookie', 'password', 'secret', 'token')
    normalized = str(key).lower().replace('_', '-')
    if any(marker in normalized for marker in sensitive):
        return '[REDACTED]'
    if isinstance(value, dict):
        return {str(k): _redact_security_evidence(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact_security_evidence(item, key) for item in value]
    if isinstance(value, tuple):
        return [_redact_security_evidence(item, key) for item in value]
    if isinstance(value, str):
        if normalized in {'url', 'target', 'effective-url', 'source-url'}:
            return _redact_target_url(value)
        return redact_secrets(value)
    return value

def _job(app,scan_id,uploads,source_url,evidence_image=None):
    with app.app_context():
        scan=Scan.query.get(scan_id);pipeline=[]
        try:
            pipeline.append(_pipeline_step('1. Acquire source','running'));_update(scan_id,4,'Acquiring source','running')
            root,meta=acquire_source(uploads,source_url,os.path.join(ROOT,str(scan_id)));files=discover_files(root)
            if not source_contains_api_key(root):
                raise ValueError('This scan requires source code containing an API key/token/credential-like value. No API-key pattern was found.')
            scan.source_path=str(root);scan.source_name=meta.get('name');scan.source_kind=meta.get('kind');scan.source_url=_redact_target_url(meta.get('source_url')) if meta.get('source_url') else None;scan.file_count=len(files);scan.llm_provider=provider_name()
            if evidence_image:
                visual=analyze_visual_evidence(evidence_image)
                pipeline.append({'step':'Visual evidence analysis','status':'complete','available':bool(visual.get('available')),'summary':visual.get('summary',''),'signals':visual.get('security_signals',[])[:8],'recommended_checks':visual.get('recommended_checks',[])[:8]})
            db.session.commit();pipeline[0]['status']='complete'

            pipeline.append(_pipeline_step('2. Static analysis','running'));_update(scan_id,10,'Fast source analysis')
            static_findings,tool_status=run_fast_static_scan(root,lambda p:_update(scan_id,p,'Static analysis'))
            pipeline[-1].update(status='complete',details=tool_status)

            pipeline.append(_pipeline_step('3. AI categorization','running'));_update(scan_id,41,'AI categorization')
            # Code findings are batched to reduce LLM latency.
            ai_calls=0
            for i in range(0,len(static_findings),int(os.getenv('AI_BATCH_SIZE','8'))):ai_calls+=enrich_findings_batch(static_findings[i:i+int(os.getenv('AI_BATCH_SIZE','8'))])
            pipeline[-1].update(status='complete',calls=ai_calls)

            pipeline.append(_pipeline_step('4. Dependency + CVE matching','running'));_update(scan_id,52,'Matching dependencies with OSV')
            cves=run_cve_scan(root,lambda p:_update(scan_id,p,'Checking dependency vulnerabilities'))
            dep_context=find_dependency_context(root)
            for i in range(0,len(cves),int(os.getenv('AI_BATCH_SIZE','8'))):enrich_cves_batch(cves[i:i+int(os.getenv('AI_BATCH_SIZE','8'))],dep_context)
            # Drop only explicit NOT_APPLICABLE CVEs from the scored list, but keep count in pipeline.
            cves=[c for c in cves if c.get('relevance','MEDIUM')!='NOT_APPLICABLE']
            pipeline[-1].update(status='complete',count=len(cves))

            pipeline.append(_pipeline_step('5. Exploit-DB cross-check','running'));_update(scan_id,66,'Cross-checking public exploits')
            exploit_count=sum(1 for c in cves if c.get('exploit_available'));pipeline[-1].update(status='complete',count=exploit_count)

            pipeline.append(_pipeline_step('6. BOLA/BFLA design analysis','running'));_update(scan_id,70,'AI analysis of API authorization')
            endpoints=extract_endpoints(root);design=analyze_design_flaws(endpoints,endpoint_context(root,endpoints));pipeline[-1].update(status='complete',endpoints=len(endpoints),findings=len(design))

            findings=static_findings+cves+design
            _update(scan_id,78,f'Prioritizing {len(findings)} findings')
            findings,cat_risk,security_score,risk_score,risk_percent=run_scoring(findings)

            pipeline.append(_pipeline_step('7. Scoring engine','complete'))
            pipeline.append(_pipeline_step('8. AI remediation report','running'));_update(scan_id,83,'Generating remediation guidance')
            summary={'security_score':security_score,'risk_score':risk_score,'risk_percent':risk_percent,'category_risk_scores':cat_risk,'finding_count':len(findings)}
            ai_summary=explain_scan(summary, findings=findings, pipeline=pipeline);pipeline[-1]['status']='complete'

            for f in findings:
                db.session.add(Finding(scan_id=scan_id,user_id=scan.user_id,severity=f.get('severity'),source=f.get('source'),tool=f.get('tool'),category=f.get('category'),rule_id=f.get('rule_id'),cve_id=f.get('cve_id'),file_path=f.get('file_path'),line_number=f.get('line_number'),code_snippet=f.get('code_snippet'),endpoint=f.get('endpoint'),http_method=f.get('http_method'),base_severity=f.get('base_severity',0),cvss_score=f.get('cvss_score'),exploit_available=f.get('exploit_available',False),exploit_id=f.get('exploit_id'),ai_relevance_confidence=f.get('ai_relevance_confidence',1),finding_score=f.get('finding_score',0),title=f.get('title'),ai_explanation=f.get('ai_explanation'),ai_justification=f.get('ai_justification'),ai_fix_snippet=f.get('ai_fix_snippet'),ai_fix_steps=f.get('ai_fix_steps'),raw_message=f.get('raw_message')))

            scan.overall_score=security_score;scan.risk_score=risk_score;scan.risk_percent=risk_percent;scan.llm_provider=provider_name()
            scan.crypto_score=cat_risk['Cryptographic Failure'];scan.auth_score=cat_risk['Broken Authentication'];scan.misconfig_score=cat_risk['Security Misconfiguration'];scan.design_flaw_score=cat_risk['Design Flaw']
            scan.finding_count=len(findings);scan.cve_count=len(cves);scan.design_flaw_count=len(design);scan.exploit_count=exploit_count;scan.ai_summary_json=json.dumps(ai_summary);scan.pipeline_json=json.dumps(pipeline);scan.status='complete';scan.stage='Scan complete';scan.progress=100;scan.completed_at=datetime.utcnow();db.session.commit()
        except Exception as exc:
            scan.status='failed';scan.stage='Scan failed';scan.error_message=str(exc);scan.pipeline_json=json.dumps(pipeline);db.session.commit()

@scan_bp.get('/health')
def health():return jsonify({'status':'ok','service':'api-stat','version':'4.0','llm_provider':provider_name(),'llm_model':model_name(),'workers':EXECUTOR._max_workers,'timestamp':datetime.utcnow().isoformat()+'Z'})

@scan_bp.get('/api/status')
def api_status():
    return jsonify({'status':'operational','version':'4.0','service':'api-stat','llm':{'provider':provider_name(),'model':model_name()},'pipeline':['source','static','ai-categorization','osv-cve','exploit-db','bola-bfla','scoring','ai-remediation','report','history'],'modes':['files','url'],'developer_api':{'endpoint':'/api/v1/live-test','live_methods':['GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS']}})

@scan_bp.get('/api/config')
def api_config():
    return jsonify({'service':'api-stat','llm_provider':provider_name(),'llm_model':model_name(),'database':'mongodb' if os.getenv('MONGODB_URI','').strip() else 'mongodb-not-configured','tools':{'bandit':bool(shutil.which('bandit')),'semgrep':bool(shutil.which('semgrep')),'git':bool(shutil.which('git'))},'features':{'osv':True,'exploitdb':True,'openapi_ai':True,'github_oauth':False,'github_source_url':True,'developer_api_key_required':bool(os.getenv('DEVELOPER_API_KEY'))},'limits':{'max_source_mb':int(os.getenv('MAX_SOURCE_BYTES',str(50*1024*1024)))//(1024*1024),'max_files':int(os.getenv('MAX_FILES','5000'))}})

@scan_bp.post('/scan/new')
@login_required
def new_scan():
    files=request.files.getlist('source_files')
    source_url=(request.form.get('source_url') or '').strip() or None
    evidence=request.files.get('evidence_image')
    # Deliberately enforce a single input mode: files OR URL, never both.
    if files and source_url:return jsonify({'error':'Choose one scan input: files OR URL, not both.'}),400
    if not files and not source_url:return jsonify({'error':'Choose one scan input: files OR URL.'}),400
    if files and any(Path(getattr(f,'filename','')).suffix.lower() not in __import__('app.scan_engine',fromlist=['CODE_EXTENSIONS']).CODE_EXTENSIONS for f in files):
        return jsonify({'error':'Only source-code files are accepted. Archives, JSON/YAML/OpenAPI specs, dependency files and webpages are rejected.'}),400
    if any(not getattr(f,'filename','') for f in files):return jsonify({'error':'One or more selected files are empty.'}),400
    if evidence and evidence.filename:
        ext=Path(evidence.filename).suffix.lower()
        if ext not in {'.png','.jpg','.jpeg','.webp'}: return jsonify({'error':'Scan evidence image must be PNG, JPG, JPEG or WEBP.'}),400
    scan=Scan(user_id=current_user.id,scan_type='source_code',status='queued',progress=0,stage='Queued',source_url=source_url);db.session.add(scan);db.session.flush()
    evidence_path=None
    if evidence and evidence.filename:
        ed=Path(ROOT)/'user'/str(current_user.id)/'scan-evidence';ed.mkdir(parents=True,exist_ok=True)
        evidence_path=str(ed/f'scan-{scan.id}{Path(evidence.filename).suffix.lower()}')
        raw=evidence.read()
        if len(raw)>5*1024*1024:return jsonify({'error':'Scan evidence image must be 5 MB or smaller.'}),400
        Path(evidence_path).write_bytes(raw)
    db.session.add(ActionLog(user_id=current_user.id,action='security_scan_started',target=_redact_target_url(source_url) if source_url else ','.join(getattr(f,'filename','') for f in files),details=json.dumps({'input_mode':'url' if source_url else 'files','scan_id':scan.id,'visual_evidence':bool(evidence_path)})));db.session.commit()
    payload=[]
    for f in files:
        data=f.read();payload.append(type('Upload',(object,),{'filename':secure_filename(f.filename),'read':lambda self,data=data:data})())
    app=current_app._get_current_object();EXECUTOR.submit(_job,app,scan.id,payload,source_url,evidence_path)
    return jsonify({'scan_id':scan.id,'status':'queued','next':'/scan/'+str(scan.id),'message':'Scan accepted.'}),202

@scan_bp.get('/scan/<int:scan_id>/status')
@login_required
def scan_status(scan_id):
    s=_owned_scan(scan_id);return jsonify({'scan_id':s.id,'status':s.status,'progress':s.progress,'stage':s.stage,'security_score':s.overall_score,'risk_score':s.risk_score,'risk_percent':s.risk_percent,'finding_count':s.finding_count,'error':s.error_message})

@scan_bp.get('/scan/<int:scan_id>/summary')
@login_required
def scan_summary(scan_id):
    s=_owned_scan(scan_id)
    return jsonify({'scan_id':s.id,'status':s.status,'progress':s.progress,'security_score':s.overall_score,'risk_score':s.risk_score,'risk_percent':s.risk_percent,'categories':{'Cryptographic Failure':s.crypto_score,'Broken Authentication':s.auth_score,'Security Misconfiguration':s.misconfig_score,'Design Flaw':s.design_flaw_score},'source':{'name':s.source_name,'kind':s.source_kind,'url':s.source_url,'files':s.file_count},'stats':{'findings':s.finding_count,'cves':s.cve_count,'design_flaws':s.design_flaw_count,'public_exploits':s.exploit_count},'api_result':None,'llm':{'provider':s.llm_provider,'model':model_name()},'ai_summary':json.loads(s.ai_summary_json or '{}'),'pipeline':json.loads(s.pipeline_json or '[]')})

@scan_bp.get('/scan/<int:scan_id>/findings')
@login_required
def scan_findings(scan_id):
    s=_owned_scan(scan_id);return jsonify([f.to_dict() for f in Finding.query.filter_by(scan_id=s.id).order_by(Finding.finding_score.desc()).all()])

@scan_bp.get('/scan/<int:scan_id>/pipeline')
@login_required
def scan_pipeline(scan_id):
    s=_owned_scan(scan_id);return jsonify(json.loads(s.pipeline_json or '[]'))

@scan_bp.get('/scan/<int:scan_id>/report/<fmt>')
@login_required
def scan_report(scan_id,fmt):
    s=_owned_scan(scan_id);findings=[f.to_dict() for f in Finding.query.filter_by(scan_id=s.id).all()];cats={'Cryptographic Failure':s.crypto_score or 0,'Broken Authentication':s.auth_score or 0,'Security Misconfiguration':s.misconfig_score or 0,'Design Flaw':s.design_flaw_score or 0};base=os.path.join(ROOT,str(scan_id));os.makedirs(base,exist_ok=True)
    if fmt=='pdf':path=os.path.join(base,'api-stat-report.pdf');generate_pdf(s.id,s.overall_score or 0,s.risk_score or 0,s.risk_percent or 0,cats,findings,s.source_name,s.ai_summary_json,path);return send_file(path,as_attachment=True,download_name=f'api-stat-scan-{scan_id}.pdf')
    if fmt in {'docx','word'}:path=os.path.join(base,'api-stat-report.docx');generate_docx(s.id,s.overall_score or 0,s.risk_score or 0,s.risk_percent or 0,cats,findings,s.source_name,s.ai_summary_json,path);return send_file(path,as_attachment=True,download_name=f'api-stat-scan-{scan_id}.docx')
    if fmt=='html':
        path=os.path.join(base,'api-stat-report.html')
        data={
            'report_mode':'source','report_id':f'API-STAT-SOURCE-{s.id:06d}',
            'assessment_type':'Source Code Security Assessment','assessment_status':(s.status or 'unknown').upper(),
            'generated_at':(s.completed_at or s.created_at).isoformat()+'Z' if (s.completed_at or s.created_at) else None,
            'scan_id':s.id,'security_score':s.overall_score,'risk_score':s.risk_score,'risk_percent':s.risk_percent,
            'category_scores':cats,'source':s.source_name,'target':s.source_url or s.source_name,
            'source_url':s.source_url,'source_kind':s.source_kind,'source_file_count':s.file_count,
            'stats':{'findings':s.finding_count,'cves':s.cve_count,'design_flaws':s.design_flaw_count,'public_exploits':s.exploit_count,'files':s.file_count},
            'findings':findings,'ai_summary':json.loads(s.ai_summary_json or '{}'),
            'ai_provider':(json.loads(s.ai_summary_json or '{}').get('provider') or s.llm_provider or provider_name()),
            'ai_model':(model_name() if (json.loads(s.ai_summary_json or '{}').get('provider') or s.llm_provider or provider_name()) not in {'heuristic','heuristic-fallback'} else 'local-heuristic-fallback'),
            'pipeline':json.loads(s.pipeline_json or '[]')
        }
        generate_html(f'API-STAT Source Code Security Report — {s.source_name or "Scan #"+str(s.id)}',data,path)
        return send_file(path,as_attachment=False,download_name=f'api-stat-source-scan-{scan_id}.html',mimetype='text/html')
    return jsonify({'error':'Supported report formats: html, pdf, docx'}),400

@scan_bp.post('/scan/<int:scan_id>/rescan')
@login_required
def rescan_scan(scan_id):
    original = _owned_scan(scan_id)
    if not original.source_path or not os.path.isdir(original.source_path):
        return jsonify({'error':'Original source is no longer available for rescan.'}),404

    source_root = Path(original.source_path)
    upload_files = []
    for path in source_root.rglob('*'):
        if not path.is_file():
            continue
        data = path.read_bytes()
        upload_files.append(type('Upload',(object,),{
            'filename': str(path.relative_to(source_root)),
            'read': (lambda self, data=data: data),
        })())

    if not upload_files:
        return jsonify({'error':'No source files were found for rescan.'}),404

    scan = Scan(user_id=current_user.id,scan_type='source_code',status='queued',progress=0,stage='Queued',source_url=original.source_url)
    db.session.add(scan)
    db.session.flush()
    db.session.add(ActionLog(user_id=current_user.id,action='security_scan_rescanned',target=f'scan:{original.id}',details=json.dumps({'original_scan_id':original.id,'new_scan_id':scan.id,'source_name':original.source_name,'source_kind':original.source_kind})))
    db.session.commit()

    app=current_app._get_current_object()
    EXECUTOR.submit(_job,app,scan.id,upload_files,original.source_url)
    return jsonify({'scan_id':scan.id,'status':'queued','original_scan_id':original.id,'next':f'/scan/{scan.id}'}),202

@scan_bp.get('/scans')
@login_required
def scan_history():
    scans = (
        Scan.query
        .filter_by(user_id=current_user.id)
        .order_by(Scan.created_at.desc())
        .all()
    )

    return jsonify([
        {
            'scan_id': s.id,
            'status': s.status,
            'progress': s.progress,
            'stage': s.stage,
            'security_score': s.overall_score,
            'risk_score': s.risk_score,
            'risk_percent': s.risk_percent,
            'finding_count': s.finding_count,
            'cve_count': s.cve_count,
            'design_flaw_count': s.design_flaw_count,
            'exploit_count': s.exploit_count,
            'source_name': s.source_name,
            'source_kind': s.source_kind,
            'source_url': s.source_url,
            'created_at': s.created_at.isoformat(),
            'completed_at': s.completed_at.isoformat() if s.completed_at else None,
            'error': s.error_message,
        }
        for s in scans
    ])

@scan_bp.post('/developer/calculator')
@login_required
def developer_calculator():
    d=request.get_json(silent=True) or {}
    def n(name,default=0):
        try:return float(d.get(name,default))
        except:return float(default)
    # 0-10 threat-model inputs. Higher means more exposure/risk.
    factors={
      'internet_exposure':n('internet_exposure'),
      'data_sensitivity':n('data_sensitivity'),
      'auth_weakness':n('auth_weakness'),
      'authorization_weakness':n('authorization_weakness'),
      'rate_limit_weakness':n('rate_limit_weakness'),
      'input_validation_weakness':n('input_validation_weakness'),
      'tls_weakness':n('tls_weakness'),
      'cors_weakness':n('cors_weakness'),
      'logging_weakness':n('logging_weakness')}
    weights={'internet_exposure':1.2,'data_sensitivity':1.3,'auth_weakness':1.5,'authorization_weakness':1.6,'rate_limit_weakness':1.0,'input_validation_weakness':1.2,'tls_weakness':0.8,'cors_weakness':0.7,'logging_weakness':0.4}
    total=sum(factors[k]*weights[k] for k in factors); risk=min(10,round(total/sum(weights.values()),2))
    weak=[k.replace('_',' ').title() for k,v in factors.items() if v>=6]
    payload={'risk_score':risk,'factors':factors,'weak_controls':weak}
    ai=analyze_api_calculator(payload);payload['ai']=ai
    db.session.add(CalculatorAssessment(
        user_id=current_user.id,
        input_parameters=factors,
        risk_score=risk,
        risk_level='High' if risk >= 7 else ('Medium' if risk >= 4 else 'Low'),
        ai_interpretation=ai,
        recommendations=(ai.get('recommendations', []) if isinstance(ai, dict) else weak),
    ))
    db.session.add(ActionLog(user_id=current_user.id,action='api_calculator',details=json.dumps(payload)));db.session.commit()
    return jsonify(payload)

@scan_bp.post('/developer/config-check')
@login_required
def developer_config_check():
    d = request.get_json(silent=True) or {}
    url = str(d.get('url', '')).strip()
    command = str(d.get('command', 'site-config')).strip().lower()
    if not url:
        return jsonify({'error': 'Target URL is required.'}), 400
    try:
        result = run_api_config_command(command, url, d.get('timeout', 6))
        # Send only compact, redacted, evidence-based data to AI; preserve the full result for UI/reporting.
        ai_context = {
            'assessment_type': 'API Configuration and Endpoint Discovery',
            'command': result.get('command'), 'url': result.get('url'),
            'status_code': result.get('status_code'), 'security_score': result.get('security_score'),
            'summary': result.get('summary'), 'checks': result.get('checks', []),
            'findings': result.get('findings', []), 'endpoints': (result.get('endpoints') or [])[:30],
        }
        try:
            result['ai'] = analyze_live_api(_redact_security_evidence(ai_context))
        except Exception as ai_exc:
            result['ai'] = {'provider': 'heuristic-fallback', 'overall_assessment': result.get('summary') or 'Scan completed. Review the returned evidence.', 'error': type(ai_exc).__name__}
        result['ai_provider'] = result['ai'].get('provider') or provider_name()
        result['ai_model'] = model_name() if result['ai_provider'] not in {'heuristic', 'heuristic-fallback'} else 'local-heuristic-fallback'
        # Store actual scan-specific evidence under the existing user-owned history action.
        safe_details = _redact_security_evidence(result)
        db.session.add(ConfigAssessment(
            user_id=current_user.id,
            target_url=_redact_target_url(url),
            commands_executed=[str(safe_details.get('command') or command)],
            checks_performed=safe_details.get('checks', []),
            check_results=safe_details,
            risk_score=safe_details.get('risk_score', safe_details.get('security_score')),
            findings=safe_details.get('findings', []),
            recommendations=((safe_details.get('ai') or {}).get('recommendations', []) if isinstance(safe_details.get('ai'), dict) else []),
        ))
        db.session.add(ActionLog(user_id=current_user.id, action='api_config_check', target=_redact_target_url(url), details=json.dumps(safe_details, ensure_ascii=False)))
        db.session.commit()
        return jsonify(result)
    except (ValueError, TypeError) as exc:
        db.session.rollback()
        return jsonify({'error': str(exc)}), 400
    except Exception:
        db.session.rollback()
        current_app.logger.exception('API Config Check failed')
        return jsonify({'error': 'API Config Check failed. Verify the target and application logs.'}), 500

@scan_bp.post('/developer/live-test')
@login_required
def developer_live_test():
    d=request.get_json(silent=True) or {};url=str(d.get('url','')).strip()
    if not url:return jsonify({'error':'url is required'}),400
    try:
        result=live_api_test(url,d.get('method','GET'),d.get('headers') or {},d.get('body'),d.get('timeout',15),d.get('attempts',3),bool(d.get('deep_scan',False)))
        result['ai']=analyze_live_api(_redact_security_evidence(result)); result['ai_provider']=result['ai'].get('provider') or provider_name(); result['ai_model']=model_name() if result['ai_provider'] not in {'heuristic','heuristic-fallback'} else 'local-heuristic-fallback'; result['assessment_type']='Live API Security Test'
        safe_result=_redact_security_evidence(result)
        db.session.add(LiveAPIAssessment(
            user_id=current_user.id,
            target_url=_redact_target_url(url),
            http_method=str(d.get('method','GET')).upper(),
            request_metadata={'deep_scan':bool(d.get('deep_scan',False)),'attempts':d.get('attempts',3)},
            response_status=safe_result.get('status_code', safe_result.get('http_status')),
            security_score=safe_result.get('security_score'),
            findings=safe_result.get('findings', []),
            ai_interpretation=safe_result.get('ai', {}),
            result=safe_result,
        ))
        db.session.add(ActionLog(user_id=current_user.id,action='live_api_test',target=_redact_target_url(url),details=json.dumps(safe_result)));db.session.commit();return jsonify(result)
    except Exception as exc:return jsonify({'error':str(exc)}),400

@scan_bp.post('/api/v1/live-test')
def public_live_test():
    expected=os.getenv('DEVELOPER_API_KEY','').strip()
    if expected and request.headers.get('X-API-KEY')!=expected:return jsonify({'error':'invalid API key'}),401
    d=request.get_json(silent=True) or {};url=str(d.get('url','')).strip()
    if not url:return jsonify({'error':'url is required'}),400
    try:
        result=live_api_test(url,d.get('method','GET'),d.get('headers') or {},d.get('body'),d.get('timeout',15),d.get('attempts',3),bool(d.get('deep_scan',False)));result['ai']=analyze_live_api(_redact_security_evidence(result));return jsonify(result)
    except Exception as exc:return jsonify({'error':str(exc)}),400

@scan_bp.get('/history/logs')
@login_required
def action_history():
    rows=ActionLog.query.filter_by(user_id=current_user.id).order_by(ActionLog.created_at.desc()).limit(200).all()
    return jsonify([{'id':r.id,'action':r.action,'target':r.target,'details':json.loads(r.details) if r.details and r.details[:1] in '[{' else r.details,'created_at':r.created_at.isoformat()} for r in rows])



POLICY_ROOT = os.path.join(ROOT, 'user_policies')
os.makedirs(POLICY_ROOT, exist_ok=True)

@scan_bp.get('/policy/download')
@login_required
def policy_download():
    path=str(Path(__file__).resolve().parent.parent / 'docs' / 'API-STAT Security Policy.pdf')
    if not os.path.isfile(path):
        return jsonify({'error':'Built-in API-STAT policy file is unavailable.'}),404
    return send_file(path,as_attachment=False,download_name='api-stat-version1.pdf',mimetype='application/pdf')

@scan_bp.get('/policy/list')
@login_required
def policy_list():
    rows=[{'id':'builtin','display_name':'api-stat version1','filename':'api-stat-version1.pdf','builtin':True,'created_at':None}]
    docs=PolicyDocument.query.filter_by(user_id=current_user.id).order_by(PolicyDocument.created_at.desc()).all()
    rows += [{'id':d.id,'display_name':d.display_name,'filename':d.filename,'builtin':False,'created_at':d.created_at.isoformat() if d.created_at else None} for d in docs]
    return jsonify(rows)

@scan_bp.get('/policy/view/<doc_id>')
@login_required
def policy_view(doc_id):
    if doc_id=='builtin':
        path=str(Path(__file__).resolve().parent.parent / 'docs' / 'API-STAT Security Policy.pdf')
        if not os.path.isfile(path): return jsonify({'error':'Built-in policy file is unavailable.'}),404
        return send_file(path,as_attachment=False,mimetype='application/pdf')
    try: doc=PolicyDocument.query.filter_by(id=int(doc_id),user_id=current_user.id).first()
    except (TypeError,ValueError): doc=None
    if not doc or not os.path.isfile(doc.path): return jsonify({'error':'Policy document not found.'}),404
    return send_file(doc.path,as_attachment=False,download_name=doc.filename,mimetype='application/pdf')

@scan_bp.post('/policy/upload')
@login_required
def policy_upload():
    f=request.files.get('policy_file')
    if not f or not f.filename: return jsonify({'error':'Select a PDF policy file.'}),400
    filename=secure_filename(f.filename)
    if not filename.lower().endswith('.pdf'): return jsonify({'error':'Only PDF policy files are allowed.'}),400
    data=f.read()
    max_bytes=int(os.getenv('MAX_POLICY_BYTES',str(10*1024*1024)))
    if len(data)>max_bytes: return jsonify({'error':f'Policy PDF must be <= {max_bytes//(1024*1024)} MB.'}),400
    user_dir=os.path.join(POLICY_ROOT,str(current_user.id)); os.makedirs(user_dir,exist_ok=True)
    stamp=datetime.utcnow().strftime('%Y%m%d%H%M%S')
    path=os.path.join(user_dir,f'{stamp}-{filename}')
    with open(path,'wb') as out: out.write(data)
    display_name=Path(filename).stem.replace('_',' ').replace('-',' ').strip() or 'Policy document'
    doc=PolicyDocument(user_id=current_user.id,display_name=display_name,filename=filename,path=path,file_storage_reference=path,file_hash=hashlib.sha256(data).hexdigest())
    db.session.add(doc)
    db.session.add(ActionLog(user_id=current_user.id,action='policy_upload',target=display_name,details=json.dumps({'filename':filename})))
    db.session.commit()
    return jsonify({'id':doc.id,'display_name':doc.display_name,'filename':doc.filename,'builtin':False}),201

@scan_bp.delete('/policy/<doc_id>')
@login_required
def policy_delete(doc_id):
    if doc_id=='builtin': return jsonify({'error':'The built-in api-stat version1 policy cannot be deleted.'}),400
    try: doc=PolicyDocument.query.filter_by(id=int(doc_id),user_id=current_user.id).first()
    except (TypeError,ValueError): doc=None
    if not doc: return jsonify({'error':'Policy document not found.'}),404
    try:
        if os.path.isfile(doc.path): os.remove(doc.path)
    except OSError: pass
    db.session.add(ActionLog(user_id=current_user.id,action='policy_delete',target=doc.display_name,details=json.dumps({'filename':doc.filename})))
    db.session.delete(doc); db.session.commit()
    return jsonify({'deleted':True})

@scan_bp.get('/api/agent/policy')
@login_required
def agent_policy():
    q=str(request.args.get('q','')).strip()
    rows=retrieve_policy(q) if q else []
    return jsonify({'standards':rows})


# ----------------------------------------------------------------------
# Security chatbot: vector-routed capabilities, RAG and streaming reasoning
# ----------------------------------------------------------------------
import threading as _threading
from collections import defaultdict as _dd, deque as _deque

_CHAT_LIMIT=int(os.getenv('AGENT_RATE_LIMIT_PER_MIN','30'))
_chat_hits=_dd(_deque); _chat_lock=_threading.Lock()
MAX_FILES_PER_MESSAGE=3
CONTEXT_KEYS=('target','method','status_code','security_score','findings','source_name','mode')

def _chat_throttle(user_id):
    """Sliding-window limiter (per user, per minute). Returns seconds to wait, or 0."""
    now=time.time()
    with _chat_lock:
        q=_chat_hits[user_id]
        while q and now-q[0]>60:q.popleft()
        if len(q)>=_CHAT_LIMIT:return max(1,int(60-(now-q[0])))
        q.append(now);return 0

def _sse(event,data):
    return 'event: '+event+'\ndata: '+json.dumps(data,default=str)+'\n\n'

def _clean_history(raw):
    out=[]
    if isinstance(raw,list):
        for t in raw[-8:]:
            if isinstance(t,dict) and t.get('role') in ('user','assistant') and isinstance(t.get('content'),str):
                out.append({'role':t['role'],'content':t['content'][:2000]})
    return out

def _clean_context(raw):
    if not isinstance(raw,dict):return {}
    ctx={k:raw[k] for k in CONTEXT_KEYS if raw.get(k) is not None}
    if isinstance(ctx.get('findings'),list):ctx['findings']=[f for f in ctx['findings'][:10] if isinstance(f,dict)]
    return ctx

def _policy_sources(user_id):
    try:return [(r.display_name,r.path) for r in PolicyDocument.query.filter_by(user_id=user_id).all() if r.path and os.path.isfile(r.path)]
    except Exception:return []

def _chat_stream(ctx,user_id,log_target):
    """Turn pipeline events into SSE and log a privacy-safe record (metadata only, secrets redacted)."""
    def generate():
        final_text='';done=None
        try:
            for event,data in run_pipeline(ctx):
                if event=='final_text':final_text=data.get('text','');continue
                if event=='done':done=data
                yield _sse(event,data)
        except GeneratorExit:
            raise
        except Exception:
            current_app.logger.exception('agent pipeline failed')
            yield _sse('error',{'error':'The agent could not complete this request. Try rephrasing or check the LLM configuration.'})
        finally:
            try:
                db.session.add(ActionLog(user_id=user_id,action='ai_agent_chat',target=log_target[:480],details=json.dumps({
                    'message':redact_secrets(ctx.message)[:2000],'attachments':[d.meta() for d in ctx.docs],
                    'capabilities':(done or {}).get('capabilities',[]),'severity':(done or {}).get('severity'),
                    'provider':(done or {}).get('provider'),'answer_preview':redact_secrets(final_text)[:1500]})[:12000]))
                db.session.commit()
            except Exception:
                db.session.rollback()
    return Response(stream_with_context(generate()),mimetype='text/event-stream',headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})

@scan_bp.get('/api/agent/capabilities')
@login_required
def agent_capabilities():
    return jsonify({'capabilities':public_registry(),'stages':[{'id':a,'label':b,'detail':c} for a,b,c in STAGES],
        'provider':provider_name(),'model':model_name(),'max_upload_mb':MAX_UPLOAD_BYTES//(1024*1024),
        'accept':list(ALLOWED_EXT),'max_files':MAX_FILES_PER_MESSAGE,
        'live_probe':os.getenv('AGENT_ENABLE_LIVE_PROBE','true').lower()!='false'})

@scan_bp.post('/api/agent/chat')
@login_required
def agent_chat_post():
    """multipart/form-data (message, context, history, disabled, files[]) or JSON. Responds with an SSE stream."""
    wait=_chat_throttle(current_user.id)
    if wait:
        r=jsonify({'error':f'Too many messages. Try again in {wait}s.'});r.status_code=429;r.headers['Retry-After']=str(wait);return r
    if request.mimetype=='multipart/form-data':
        form=request.form;files=request.files.getlist('files')
        def _j(name,default):
            try:return json.loads(form.get(name) or json.dumps(default))
            except ValueError:return default
        message=str(form.get('message','')).strip();context=_j('context',{});history=_j('history',[]);disabled=_j('disabled',[]);carried=_j('carried',[])
    else:
        d=request.get_json(silent=True) or {};files=[]
        message=str(d.get('message','')).strip();context=d.get('context') or {};history=d.get('history') or [];disabled=d.get('disabled') or [];carried=[]
    if len(files)>MAX_FILES_PER_MESSAGE:return jsonify({'error':f'Attach at most {MAX_FILES_PER_MESSAGE} files per message.'}),400
    if not message and not files:return jsonify({'error':'Type a question or attach a report.'}),400
    if len(message)>8000:return jsonify({'error':'Message is too long (8000 characters maximum).'}),400
    docs=[]
    for f in files:
        data=f.stream.read(MAX_UPLOAD_BYTES+1)
        try:
            doc=parse_upload(f.filename or 'report',data);doc.carried=isinstance(carried,list) and (f.filename in carried);docs.append(doc)
        except ParseError as exc:return jsonify({'error':f'{secure_filename(f.filename or "file")}: {exc}'}),400
    if not message:message='Assess the attached report.' if docs else ''
    ctx=Ctx(message=message,history=_clean_history(history),docs=docs,scan=_clean_context(context),
            policy_sources=_policy_sources(current_user.id),disabled={x for x in disabled if isinstance(x,str) and x in BY_ID},
            live_probe_enabled=os.getenv('AGENT_ENABLE_LIVE_PROBE','true').lower()!='false')
    return _chat_stream(ctx,current_user.id,str((ctx.scan or {}).get('target','agent')))

@scan_bp.get('/api/agent/chat')
@login_required
def agent_chat_stream():
    """Backwards-compatible GET stream (no attachments)."""
    message=str(request.args.get('message','')).strip()
    if not message:return jsonify({'error':'message is required'}),400
    wait=_chat_throttle(current_user.id)
    if wait:
        r=jsonify({'error':f'Too many messages. Try again in {wait}s.'});r.status_code=429;r.headers['Retry-After']=str(wait);return r
    try:context=json.loads(request.args.get('context','{}'))
    except ValueError:context={}
    ctx=Ctx(message=message[:8000],scan=_clean_context(context),policy_sources=_policy_sources(current_user.id),
            live_probe_enabled=os.getenv('AGENT_ENABLE_LIVE_PROBE','true').lower()!='false')
    return _chat_stream(ctx,current_user.id,str(ctx.scan.get('target','agent')))

@scan_bp.get('/developer/report/html/<kind>')
@login_required
def developer_html_report(kind):
    # Reports are built from the latest assessment record belonging to this account.
    action_map={'live':'live_api_test','config':'api_config_check','calculator':'api_calculator'}
    action=action_map.get(kind)
    if not action:return jsonify({'error':'kind must be live, config or calculator'}),400
    row=ActionLog.query.filter_by(user_id=current_user.id,action=action).order_by(ActionLog.created_at.desc()).first()
    if not row:return jsonify({'error':'Run this assessment first.'}),404
    outdir=os.path.join(ROOT,'user',str(current_user.id));os.makedirs(outdir,exist_ok=True);path=os.path.join(outdir,f'{kind}-report.html')
    data=json.loads(row.details) if row.details else {}
    data=dict(data)
    data.setdefault('generated_at', row.created_at.isoformat()+'Z' if row.created_at else None)
    data.setdefault('report_id', f'API-STAT-{kind.upper()}-{row.id:06d}')
    data.setdefault('target', row.target or data.get('effective_url') or data.get('url') or 'API assessment')
    ai_actual_provider = (data.get('ai') or {}).get('provider') if isinstance(data.get('ai'), dict) else None
    data['ai_provider'] = ai_actual_provider or data.get('ai_provider') or provider_name()
    data['ai_model'] = model_name() if data['ai_provider'] not in {'heuristic','heuristic-fallback'} else 'local-heuristic-fallback'
    if kind in {'live','config'}:
        data['report_mode']='live'
        data['assessment_type']='Live API Security Test' if kind=='live' else 'API Configuration Check'
        data.setdefault('url', row.target)
        if not isinstance(data.get('ai'), dict) or not data['ai']:
            data['ai']=analyze_live_api(data)
    generate_html(f'API-STAT {kind.title()} Security Report',data,path)
    return send_file(path,as_attachment=False,download_name=f'api-stat-{kind}-report.html',mimetype='text/html')
