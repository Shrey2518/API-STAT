"""MongoDB persistence layer for API-STAT.

The small query/session facade intentionally preserves the subset of the former
SQLAlchemy API used by this application, so the security scanner, routes and
frontend do not need a wholesale rewrite during the database migration.
"""
from __future__ import annotations

import copy
import threading
from datetime import datetime
from typing import Any

from flask import abort, current_app, has_app_context
from flask_login import UserMixin
from pymongo import MongoClient, DESCENDING, ASCENDING, ReturnDocument


class ModelField:
    """A lightweight model field descriptor used by filters and sort clauses."""
    def __init__(self, default=None):
        self.default = default
        self.name = None

    def __set_name__(self, owner, name):
        self.name = name

    def __get__(self, instance, owner):
        if instance is None:
            return self
        return instance._values.get(self.name)

    def __set__(self, instance, value):
        instance._values[self.name] = value

    def desc(self):
        return SortSpec(self.name, DESCENDING)

    def asc(self):
        return SortSpec(self.name, ASCENDING)


class SortSpec:
    def __init__(self, name, direction):
        self.name = name
        self.direction = direction


class QueryDescriptor:
    def __get__(self, instance, owner):
        return MongoQuery(owner)


class ModelMeta(type):
    def __new__(mcls, name, bases, namespace):
        inherited = {}
        for base in bases:
            inherited.update(getattr(base, "_fields", {}))
        own = {key: value for key, value in namespace.items() if isinstance(value, ModelField)}
        cls = super().__new__(mcls, name, bases, namespace)
        cls._fields = {**inherited, **own}
        return cls


class MongoModel(metaclass=ModelMeta):
    query = QueryDescriptor()
    collection_name = ""
    id = ModelField(default=None)

    def __init__(self, **kwargs):
        object.__setattr__(self, "_values", {})
        object.__setattr__(self, "_extra", {})
        object.__setattr__(self, "_persisted", False)
        object.__setattr__(self, "_mongo_baseline", None)
        for name, field in self._fields.items():
            value = field.default() if callable(field.default) else copy.deepcopy(field.default)
            self._values[name] = value
        for name, value in kwargs.items():
            if name in self._fields:
                self._values[name] = value
            elif not name.startswith("_"):
                self._extra[name] = value

    @classmethod
    def _from_document(cls, document):
        values = dict(document)
        mongo_id = values.pop("_id", None)
        values.setdefault("id", mongo_id)
        obj = cls(**values)
        object.__setattr__(obj, "_persisted", True)
        object.__setattr__(obj, "_mongo_baseline", copy.deepcopy(obj._values))
        return obj

    def _to_document(self):
        document = dict(self._extra)
        document.update(self._values)
        document.pop("_id", None)
        if self.id is None:
            raise ValueError(f"{self.__class__.__name__}.id must be assigned before saving")
        # Keep user-friendly, structured aliases in MongoDB while preserving the
        # names used by the existing route/report layer.
        if self.collection_name == "scans":
            document["started_at"] = document.get("created_at")
            document["current_stage"] = document.get("stage")
            document["source_type"] = document.get("source_kind")
            for source_key, target_key in (("ai_summary_json", "ai_summary"), ("pipeline_json", "pipeline_steps")):
                raw = document.get(source_key)
                if raw:
                    try:
                        import json
                        document[target_key] = json.loads(raw) if isinstance(raw, str) else raw
                    except (TypeError, ValueError):
                        document[target_key] = raw
        elif self.collection_name == "findings":
            if document.get("severity") is None:
                score = document.get("base_severity")
                if score is not None:
                    try:
                        numeric = float(score)
                        document["severity"] = "Critical" if numeric >= 9 else ("High" if numeric >= 7 else ("Medium" if numeric >= 4 else "Low"))
                    except (TypeError, ValueError):
                        document["severity"] = None
            if "remediation_steps" not in document:
                steps = document.get("ai_fix_steps")
                if isinstance(steps, str):
                    try:
                        import json
                        steps = json.loads(steps)
                    except (TypeError, ValueError):
                        steps = [steps] if steps else []
                document["remediation_steps"] = steps or []
        document["_id"] = self.id
        return document

    def _restore(self, snapshot):
        object.__setattr__(self, "_values", copy.deepcopy(snapshot))


class MongoSession:
    """Thread-local unit-of-work for inserts, updates and deletes."""
    def __init__(self, database):
        self.database = database
        self._local = threading.local()

    def _state(self):
        if not hasattr(self._local, "pending"):
            self._local.pending = []
            self._local.deleted = []
            self._local.tracked = {}
        return self._local

    @staticmethod
    def _key(obj):
        return (obj.collection_name, obj.id)

    def add(self, obj):
        state = self._state()
        if obj._persisted:
            key = self._key(obj)
            state.tracked.setdefault(key, (obj, copy.deepcopy(obj._mongo_baseline or obj._values)))
            return
        if all(existing is not obj for existing in state.pending):
            state.pending.append(obj)

    def delete(self, obj):
        state = self._state()
        if all(existing is not obj for existing in state.deleted):
            state.deleted.append(obj)

    def flush(self):
        """Assign IDs now; inserts are committed by commit()."""
        for obj in self._state().pending:
            if obj.id is None:
                obj.id = self.database.next_id(obj.collection_name)

    def track(self, obj):
        if obj.id is None:
            return obj
        state = self._state()
        key = self._key(obj)
        existing = state.tracked.get(key)
        if existing:
            return existing[0]
        snapshot = copy.deepcopy(obj._values)
        state.tracked[key] = (obj, snapshot)
        object.__setattr__(obj, "_mongo_baseline", copy.deepcopy(snapshot))
        return obj

    def identity_get(self, model, object_id):
        existing = self._state().tracked.get((model.collection_name, object_id))
        if existing:
            return existing[0]
        for obj in self._state().pending:
            if isinstance(obj, model) and obj.id == object_id:
                return obj
        return None

    def commit(self):
        state = self._state()
        pending = list(state.pending)
        deleted_keys = {self._key(obj) for obj in state.deleted if obj.id is not None}
        inserted_keys = set()

        try:
            # Inserts first, so linked rows can refer to their assigned IDs.
            for obj in pending:
                if obj.id is None:
                    obj.id = self.database.next_id(obj.collection_name)
                key = self._key(obj)
                if key in deleted_keys:
                    continue
                document = obj._to_document()
                self.database.collection(obj.collection_name).insert_one(document)
                object.__setattr__(obj, "_persisted", True)
                snapshot = copy.deepcopy(obj._values)
                object.__setattr__(obj, "_mongo_baseline", copy.deepcopy(snapshot))
                state.tracked[key] = (obj, snapshot)
                inserted_keys.add(key)

            # Persist changes to loaded objects. MongoDB replacement avoids
            # accidentally retaining fields whose schema has changed.
            for key, (obj, baseline) in list(state.tracked.items()):
                if key in inserted_keys or key in deleted_keys:
                    continue
                if obj._values != baseline:
                    self.database.collection(obj.collection_name).replace_one(
                        {"_id": obj.id}, obj._to_document(), upsert=True
                    )
                    baseline = copy.deepcopy(obj._values)
                    state.tracked[key] = (obj, baseline)
                    object.__setattr__(obj, "_mongo_baseline", copy.deepcopy(baseline))

            for obj in state.deleted:
                if obj.id is not None:
                    self.database.collection(obj.collection_name).delete_one({"_id": obj.id})
                    state.tracked.pop(self._key(obj), None)
                    object.__setattr__(obj, "_persisted", False)

            state.pending.clear()
            state.deleted.clear()
        except Exception:
            # Keep queued work available for rollback, matching the callers'
            # existing try/except semantics.
            raise

    def rollback(self):
        state = self._state()
        for obj in state.pending:
            if not obj._persisted:
                obj.id = None
        for _, (obj, snapshot) in list(state.tracked.items()):
            obj._restore(snapshot)
            object.__setattr__(obj, "_mongo_baseline", copy.deepcopy(snapshot))
        state.pending.clear()
        state.deleted.clear()

    def remove(self):
        if hasattr(self._local, "pending"):
            self._local.pending.clear()
            self._local.deleted.clear()
            self._local.tracked.clear()
            del self._local.pending
            del self._local.deleted
            del self._local.tracked


class MongoQuery:
    def __init__(self, model, filters=None, ordering=None, max_items=None):
        self.model = model
        self.filters = dict(filters or {})
        self.ordering = list(ordering or [])
        self.max_items = max_items

    def filter_by(self, **kwargs):
        return MongoQuery(self.model, {**self.filters, **kwargs}, self.ordering, self.max_items)

    def order_by(self, *items):
        ordering = list(self.ordering)
        for item in items:
            if isinstance(item, SortSpec):
                ordering.append((item.name, item.direction))
            elif isinstance(item, ModelField):
                ordering.append((item.name, ASCENDING))
            else:
                raise TypeError(f"Unsupported order_by value: {item!r}")
        return MongoQuery(self.model, self.filters, ordering, self.max_items)

    def limit(self, count):
        return MongoQuery(self.model, self.filters, self.ordering, max(0, int(count)))

    def _mongo_filter(self):
        result = dict(self.filters)
        if "id" in result:
            result["_id"] = result.pop("id")
        return result

    def all(self):
        collection = self.model._database().collection(self.model.collection_name)
        cursor = collection.find(self._mongo_filter())
        if self.ordering:
            cursor = cursor.sort(self.ordering)
        if self.max_items is not None:
            cursor = cursor.limit(self.max_items)
        results = []
        for document in cursor:
            obj = self.model._from_document(document)
            results.append(self.model._database().session.track(obj))
        return results

    def first(self):
        rows = self.limit(1).all()
        return rows[0] if rows else None

    def first_or_404(self, description=None):
        item = self.first()
        if item is None:
            abort(404, description=description or "The requested record was not found.")
        return item

    def get(self, object_id):
        if object_id is None:
            return None
        # Existing routes use numeric IDs; normalize URL/string IDs carefully.
        try:
            if isinstance(object_id, str) and object_id.isdigit():
                object_id = int(object_id)
        except Exception:
            pass
        db = self.model._database()
        cached = db.session.identity_get(self.model, object_id)
        if cached is not None:
            # SQLAlchemy's Query.get is an identity lookup and does not apply filters.
            return cached
        document = db.collection(self.model.collection_name).find_one({"_id": object_id})
        if document is None:
            return None
        return db.session.track(self.model._from_document(document))

    def get_or_404(self, object_id, description=None):
        item = self.get(object_id)
        if item is None:
            abort(404, description=description or "The requested record was not found.")
        return item


class MongoDatabase:
    def __init__(self):
        self.session = MongoSession(self)
        self._client = None
        self._client_uri = None
        self._database_name = None
        self._lock = threading.Lock()

    def init_app(self, app):
        app.extensions["apistat_mongodb"] = self
        app.teardown_appcontext(self._teardown)

    def _teardown(self, error=None):
        # Session state must not cross requests. The worker thread's app context
        # also gets its own clean unit-of-work when it finishes.
        self.session.remove()

    def _config(self):
        if has_app_context():
            uri = str(current_app.config.get("MONGODB_URI") or "").strip()
            name = str(current_app.config.get("MONGODB_DB") or "apistat").strip()
        else:
            import os
            uri = str(os.getenv("MONGODB_URI", "")).strip()
            name = str(os.getenv("MONGODB_DB", "apistat")).strip()
        return uri, name or "apistat"

    def _get_database(self):
        uri, name = self._config()
        if not uri:
            raise RuntimeError(
                "MongoDB is not configured. Set MONGODB_URI in your .env file "
                "to your MongoDB Atlas connection string."
            )
        with self._lock:
            if self._client is None or self._client_uri != uri or self._database_name != name:
                if self._client is not None:
                    self._client.close()
                self._client = MongoClient(
                    uri,
                    serverSelectionTimeoutMS=6000,
                    connectTimeoutMS=6000,
                    appname="API-STAT",
                )
                self._client_uri = uri
                self._database_name = name
        return self._client[name]

    def collection(self, name):
        return self._get_database()[name]

    def next_id(self, collection_name):
        counters = self.collection("_counters")
        counter = counters.find_one_and_update(
            {"_id": collection_name},
            {"$inc": {"sequence": 1}},
            upsert=True,
            return_document=ReturnDocument.AFTER,
        )
        return int(counter["sequence"])

    def create_all(self):
        """Create indexes when a URI is configured; does not create schemas."""
        uri, _ = self._config()
        if not uri:
            return
        database = self._get_database()
        database.command("ping")
        database["users"].create_index([("email", ASCENDING)], unique=True, name="uq_users_email")
        database["scans"].create_index([("user_id", ASCENDING), ("created_at", DESCENDING)], name="ix_scans_user_created")
        database["findings"].create_index([("scan_id", ASCENDING), ("finding_score", DESCENDING)], name="ix_findings_scan_score")
        database["findings"].create_index([("user_id", ASCENDING)], name="ix_findings_user")
        database["action_logs"].create_index([("user_id", ASCENDING), ("created_at", DESCENDING)], name="ix_logs_user_created")
        database["action_logs"].create_index([("user_id", ASCENDING), ("action", ASCENDING), ("created_at", DESCENDING)], name="ix_logs_user_action_created")
        database["policy_documents"].create_index([("user_id", ASCENDING), ("created_at", DESCENDING)], name="ix_policy_user_created")
        for name in ("calculator_assessments", "config_assessments", "live_api_assessments"):
            database[name].create_index([("user_id", ASCENDING), ("created_at", DESCENDING)], name=f"ix_{name}_user_created")

    def close(self):
        with self._lock:
            if self._client:
                self._client.close()
            self._client = None
            self._client_uri = None
            self._database_name = None


# ---------------------------------------------------------------------------
# Models / collections
# ---------------------------------------------------------------------------


db = MongoDatabase()


class User(MongoModel, UserMixin):
    collection_name = "users"
    email = ModelField()
    password_hash = ModelField()
    created_at = ModelField(default=datetime.utcnow)
    last_login_at = ModelField(default=None)

    @property
    def scans(self):
        return Scan.query.filter_by(user_id=self.id).all()


class ActionLog(MongoModel):
    collection_name = "action_logs"
    user_id = ModelField()
    action = ModelField()
    target = ModelField(default=None)
    details = ModelField(default=None)
    created_at = ModelField(default=datetime.utcnow)


class Scan(MongoModel):
    collection_name = "scans"
    user_id = ModelField()
    scan_type = ModelField(default="source_code")
    status = ModelField(default="queued")
    progress = ModelField(default=0)
    stage = ModelField(default="Queued")
    overall_score = ModelField(default=None)
    risk_score = ModelField(default=None)
    risk_percent = ModelField(default=None)
    crypto_score = ModelField(default=None)
    auth_score = ModelField(default=None)
    misconfig_score = ModelField(default=None)
    design_flaw_score = ModelField(default=None)
    source_path = ModelField(default=None)
    source_name = ModelField(default=None)
    source_kind = ModelField(default=None)
    source_url = ModelField(default=None)
    llm_provider = ModelField(default=None)
    file_count = ModelField(default=0)
    finding_count = ModelField(default=0)
    cve_count = ModelField(default=0)
    design_flaw_count = ModelField(default=0)
    exploit_count = ModelField(default=0)
    api_result_json = ModelField(default=None)
    ai_summary_json = ModelField(default=None)
    pipeline_json = ModelField(default=None)
    error_message = ModelField(default=None)
    created_at = ModelField(default=datetime.utcnow)
    completed_at = ModelField(default=None)

    @property
    def findings(self):
        return Finding.query.filter_by(scan_id=self.id).all()


class Finding(MongoModel):
    collection_name = "findings"
    scan_id = ModelField()
    user_id = ModelField(default=None)
    source = ModelField(default=None)
    tool = ModelField(default=None)
    category = ModelField(default=None)
    rule_id = ModelField(default=None)
    cve_id = ModelField(default=None)
    file_path = ModelField(default=None)
    line_number = ModelField(default=None)
    code_snippet = ModelField(default=None)
    endpoint = ModelField(default=None)
    http_method = ModelField(default=None)
    base_severity = ModelField(default=0)
    cvss_score = ModelField(default=None)
    exploit_available = ModelField(default=False)
    exploit_id = ModelField(default=None)
    ai_relevance_confidence = ModelField(default=1)
    finding_score = ModelField(default=0)
    title = ModelField(default=None)
    ai_explanation = ModelField(default=None)
    ai_justification = ModelField(default=None)
    ai_fix_snippet = ModelField(default=None)
    ai_fix_steps = ModelField(default=None)
    raw_message = ModelField(default=None)

    def to_dict(self):
        import json
        steps = self.ai_fix_steps
        try:
            steps = json.loads(steps) if steps else []
        except Exception:
            steps = [steps] if steps else []
        return {
            "id": self.id, "source": self.source, "tool": self.tool,
            "category": self.category, "rule_id": self.rule_id, "cve_id": self.cve_id,
            "file_path": self.file_path, "line_number": self.line_number,
            "code_snippet": self.code_snippet, "endpoint": self.endpoint,
            "http_method": self.http_method, "base_severity": self.base_severity,
            "cvss_score": self.cvss_score, "exploit_available": self.exploit_available,
            "exploit_id": self.exploit_id, "ai_relevance_confidence": self.ai_relevance_confidence,
            "finding_score": self.finding_score, "title": self.title,
            "ai_explanation": self.ai_explanation, "ai_justification": self.ai_justification,
            "ai_fix_snippet": self.ai_fix_snippet, "ai_fix_steps": steps,
            "raw_message": self.raw_message,
        }


class PolicyDocument(MongoModel):
    collection_name = "policy_documents"
    user_id = ModelField()
    display_name = ModelField()
    filename = ModelField()
    path = ModelField()
    file_storage_reference = ModelField(default=None)
    file_hash = ModelField(default=None)
    created_at = ModelField(default=datetime.utcnow)


class CalculatorAssessment(MongoModel):
    collection_name = "calculator_assessments"
    user_id = ModelField()
    input_parameters = ModelField(default=dict)
    risk_score = ModelField(default=None)
    risk_level = ModelField(default=None)
    ai_interpretation = ModelField(default=None)
    recommendations = ModelField(default=list)
    created_at = ModelField(default=datetime.utcnow)


class ConfigAssessment(MongoModel):
    collection_name = "config_assessments"
    user_id = ModelField()
    target_url = ModelField(default=None)
    commands_executed = ModelField(default=list)
    checks_performed = ModelField(default=list)
    check_results = ModelField(default=dict)
    risk_score = ModelField(default=None)
    findings = ModelField(default=list)
    recommendations = ModelField(default=list)
    created_at = ModelField(default=datetime.utcnow)


class LiveAPIAssessment(MongoModel):
    collection_name = "live_api_assessments"
    user_id = ModelField()
    target_url = ModelField(default=None)
    http_method = ModelField(default="GET")
    request_metadata = ModelField(default=dict)
    response_status = ModelField(default=None)
    security_score = ModelField(default=None)
    findings = ModelField(default=list)
    ai_interpretation = ModelField(default=dict)
    result = ModelField(default=dict)
    created_at = ModelField(default=datetime.utcnow)
