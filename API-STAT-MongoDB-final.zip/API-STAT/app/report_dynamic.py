"""Dynamic, evidence-led HTML reports for live API and source-code assessments.

These report builders intentionally use separate layouts for black-box HTTP tests and
source-code reviews. All report values are derived from the assessment result or its
AI interpretation; warnings are not presented as proof of exploitability.
"""
from __future__ import annotations

import html
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _safe(value: Any) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def _json(value: Any) -> str:
    try:
        return json.dumps(value, indent=2, ensure_ascii=False, default=str)
    except Exception:
        return str(value)


def _as_list(value: Any) -> list:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return []
        try:
            decoded = json.loads(stripped)
            return decoded if isinstance(decoded, list) else [decoded]
        except Exception:
            return [value]
    return [value]


def _float(value: Any, fallback: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _severity(score: Any) -> tuple[str, str]:
    value = _float(score)
    if value >= 8:
        return "Critical", "critical"
    if value >= 6:
        return "High", "high"
    if value >= 4:
        return "Medium", "medium"
    return "Low", "low"


def _status_class(status: Any) -> str:
    status = str(status or "INFO").upper()
    if status in {"PASS", "COMPLETE", "COMPLETED", "OK"}:
        return "pass"
    if status in {"WARN", "WARNING", "NO_RESPONSE"}:
        return "warn"
    if status in {"FAIL", "FAILED", "ERROR"}:
        return "fail"
    return "info"


def _score_class(score: Any, high_is_good: bool = True) -> str:
    try:
        value = float(score)
    except (TypeError, ValueError):
        return "neutral"
    if high_is_good:
        return "good" if value >= 8 else "warn" if value >= 5 else "bad"
    return "bad" if value >= 8 else "warn" if value >= 5 else "good"


def _confidence(value: Any) -> str:
    if value is None:
        return "Not reported"
    number = _float(value, -1)
    if number < 0:
        return "Not reported"
    if number <= 1:
        number *= 100
    return f"{max(0, min(100, number)):.0f}%"


def _date(value: Any) -> str:
    if value:
        return str(value).replace("T", " ")[:32]
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def _redact_evidence(value: Any, key: str = "") -> Any:
    """Redact authentication material from stored request/response evidence."""
    sensitive = ("authorization", "api-key", "apikey", "cookie", "password", "secret", "token")
    if any(marker in key.lower().replace("_", "-") for marker in sensitive):
        return "[REDACTED]"
    if isinstance(value, dict):
        return {str(k): _redact_evidence(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact_evidence(v, key) for v in value]
    return value


_FIX_HINTS = {
    "https": "Serve the endpoint over HTTPS, redirect HTTP to HTTPS, and verify the certificate chain.",
    "hsts": "Add a Strict-Transport-Security response header on HTTPS responses after validating all in-scope hosts.",
    "content-type": "Set X-Content-Type-Options: nosniff on responses where appropriate.",
    "cors": "Replace wildcard cross-origin access with an explicit allowlist of trusted origins, methods and headers.",
    "authentication": "Verify authentication is required for protected operations and test authorization separately for each endpoint.",
    "authorization": "Enforce server-side object ownership and function/role permissions on every protected operation.",
    "rate limit": "Set request limits at the gateway or service layer and verify them with an approved, controlled test.",
    "cache": "Review whether responses can contain sensitive data and apply suitable Cache-Control directives.",
    "csp": "Define a restrictive Content-Security-Policy where the endpoint serves browser-interpreted content.",
}


def _fix_for(name: Any) -> str:
    low = str(name or "").lower()
    for key, hint in _FIX_HINTS.items():
        if key in low:
            return hint
    return "Review the observed control, apply the least-privilege fix appropriate to this endpoint, then rerun the assessment."


def _live_findings(data: dict) -> list[dict]:
    explicit = data.get("findings")
    if isinstance(explicit, list) and explicit:
        return explicit
    derived = []
    for check in _as_list(data.get("checks")):
        if not isinstance(check, dict):
            continue
        status = str(check.get("status") or "INFO").upper()
        if status not in {"WARN", "WARNING", "FAIL", "FAILED", "ERROR"}:
            continue
        name = str(check.get("name") or "Security control")
        score = 7.0 if status in {"FAIL", "FAILED", "ERROR"} else 5.0
        priority = "P1" if score >= 7 or any(x in name.lower() for x in ("https", "authentication", "authorization", "cors")) else "P2"
        derived.append({
            "title": f"{name}: attention required",
            "category": "Security Misconfiguration" if any(x in name.lower() for x in ("header", "hsts", "https", "cors", "csp", "cache", "content-type")) else "API Control Review",
            "severity": "High" if score >= 7 else "Medium",
            "finding_score": score,
            "status": status,
            "evidence": str(check.get("detail") or "A warning status was recorded for this control."),
            "remediation": _fix_for(name),
            "priority": priority,
            "derived_from_control": True,
        })
    return derived


_STYLE = r"""
:root{--navy:#071a2d;--ink:#17283c;--muted:#63778f;--line:#d7e1ec;--paper:#fff;--bg:#edf3f8;--green:#0c8b61;--amber:#b87500;--red:#c9374a;--slate:#43637f}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,Segoe UI,Arial,sans-serif;line-height:1.58}.report{max-width:1180px;margin:28px auto 64px;padding:0 22px}
.cover{background:radial-gradient(circle at 85% 20%,rgba(84,200,239,.23),transparent 35%),linear-gradient(135deg,#06192b 0%,#0c3457 58%,#155b8d 100%);color:#fff;border-radius:24px;padding:42px 46px;box-shadow:0 22px 58px rgba(7,26,45,.23);position:relative;overflow:hidden}.brand{font-size:13px;font-weight:900;letter-spacing:.16em;color:#9fd9f2}.cover h1{font-size:40px;line-height:1.08;margin:17px 0 11px;max-width:900px}.cover .subtitle{font-size:16px;color:#d8e9f8;max-width:800px}.hero-meta{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:28px}.hero-box{border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.08);padding:14px;border-radius:13px;min-width:0}.hero-box small{display:block;color:#a8c9df;text-transform:uppercase;letter-spacing:.1em;font-size:10px}.hero-box b{display:block;margin-top:5px;font-size:13px;color:#fff;word-break:break-word}
.nav{position:sticky;top:0;z-index:5;margin:16px 0;background:rgba(237,243,248,.95);backdrop-filter:blur(10px);border:1px solid var(--line);border-radius:14px;padding:9px;display:flex;flex-wrap:wrap;gap:6px;box-shadow:0 8px 18px rgba(35,58,84,.06)}.nav a{text-decoration:none;color:#305778;font-size:12px;font-weight:800;padding:8px 11px;border-radius:9px}.nav a:hover{background:#fff}
.section{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:28px;margin-top:17px;box-shadow:0 10px 30px rgba(22,45,70,.06)}.kicker{font-size:10px;color:#6d8298;font-weight:900;letter-spacing:.18em}h2{font-size:24px;line-height:1.2;margin:5px 0 12px}h3{font-size:18px;line-height:1.35;margin:8px 0}h4{font-size:11px;text-transform:uppercase;letter-spacing:.09em;color:#60778f;margin:0 0 6px}p{margin:6px 0}.lead{font-size:15px;color:#40566e}.muted{color:var(--muted)}
.doc-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.metric{border:1px solid var(--line);border-radius:15px;background:#f8fbfe;padding:16px;min-width:0}.metric small{display:block;color:#6a8096;text-transform:uppercase;letter-spacing:.09em;font-size:10px;font-weight:900}.metric strong{display:block;font-size:29px;line-height:1.1;margin:7px 0 4px;color:#173858;overflow-wrap:anywhere}.metric strong.good{color:var(--green)}.metric strong.warn{color:var(--amber)}.metric strong.bad,.metric strong.critical,.metric strong.high{color:var(--red)}.metric span{font-size:11px;color:#6c8095}
.doc-table,.data-table{width:100%;border-collapse:collapse}.doc-table th,.doc-table td,.data-table th,.data-table td{padding:11px 13px;border-bottom:1px solid #e6edf4;text-align:left;vertical-align:top;font-size:13px;overflow-wrap:anywhere}.doc-table th{width:34%;background:#f5f8fb;color:#50677f;font-weight:800}.data-table th{background:#f3f6fa;color:#4b647d;text-transform:uppercase;letter-spacing:.07em;font-size:11px}.data-table tr:last-child td,.doc-table tr:last-child td{border-bottom:0}.table-wrap{overflow:auto;border:1px solid var(--line);border-radius:12px}
.tag{display:inline-block;padding:5px 8px;border-radius:8px;background:#edf4fb;border:1px solid #dce8f3;font-size:11px;font-weight:800;color:#42627e}.status,.severity{display:inline-flex;align-items:center;padding:5px 9px;border-radius:999px;font-size:10px;font-weight:900;text-transform:uppercase;letter-spacing:.06em;white-space:nowrap}.status.pass,.severity.low{background:#eaf8f1;color:var(--green)}.status.warn,.severity.medium{background:#fff7e8;color:var(--amber)}.status.fail,.severity.high,.severity.critical{background:#fff0f2;color:var(--red)}.status.info{background:#edf4fb;color:var(--slate)}
.finding-card{border:1px solid var(--line);border-left:5px solid #95abc0;border-radius:15px;padding:19px;margin:13px 0;background:#fff;break-inside:avoid}.finding-card.high,.finding-card.critical{border-left-color:var(--red)}.finding-card.medium{border-left-color:var(--amber)}.finding-head{display:flex;justify-content:space-between;gap:14px;align-items:flex-start}.finding-score{font-size:13px;font-weight:900;color:#516a82;white-space:nowrap}.meta-tags{display:flex;flex-wrap:wrap;gap:7px;margin:10px 0 13px}.meta-tags span{background:#f4f7fa;border:1px solid #e1e8ef;border-radius:8px;padding:6px 8px;color:#526a81;font-size:11px}.finding-block{margin-top:12px}.finding-block p,.finding-block li{color:#40566e;font-size:13px}.finding-block ol,.finding-block ul{margin:6px 0 0 20px;padding:0}.fix-box{margin-top:13px;background:#f2f8fd;border:1px solid #d5e3ef;padding:13px;border-radius:11px}.empty-note{padding:14px;border:1px dashed #cbd8e4;border-radius:12px;color:#667c92;background:#fbfdff}.priority{display:inline-block;padding:5px 8px;border-radius:8px;background:#102a4c;color:#fff;font-size:10px;font-weight:900}.domain-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.domain-card{border:1px solid var(--line);border-radius:14px;padding:16px;background:#fbfcfe}.domain-head{display:flex;justify-content:space-between;gap:10px;font-weight:800}.bar{height:8px;background:#e7edf4;border-radius:99px;overflow:hidden;margin:10px 0}.bar i{display:block;height:100%;border-radius:99px;background:#8ba8c1}.bar i.good{background:linear-gradient(90deg,#5dcc95,#0c8b61)}.bar i.warn{background:linear-gradient(90deg,#f2cb70,#b87500)}.bar i.bad{background:linear-gradient(90deg,#ef8b98,#c9374a)}.domain-card small{color:#687f96}pre{margin:10px 0 0;background:#09192c;color:#e5eff9;padding:15px;border-radius:11px;overflow:auto;font-size:11px;line-height:1.5;white-space:pre-wrap;word-break:break-word}.footer{text-align:center;color:#71849a;font-size:11px;margin-top:18px}.note{font-size:12px;color:#63778f}
@media(max-width:900px){.hero-meta,.metrics,.doc-grid,.domain-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.cover h1{font-size:34px}}@media(max-width:650px){.hero-meta,.metrics,.doc-grid,.domain-grid{grid-template-columns:1fr}.report{padding:0 12px}.cover{padding:30px 24px}.cover h1{font-size:29px}.section{padding:20px}.finding-head{display:block}}
@media print{body{background:#fff}.report{max-width:none;margin:0;padding:0}.nav{display:none}.section,.cover{box-shadow:none;break-inside:avoid}.cover{border-radius:0}.finding-card{break-inside:avoid}a{color:inherit}}
"""


def _page(title: str, content: str) -> str:
    return f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{_safe(title)}</title><style>{_STYLE}</style></head><body><main class='report'>{content}</main></body></html>"


def _nav(items: list[tuple[str, str]]) -> str:
    return "<nav class='nav'>" + "".join(f"<a href='#{_safe(anchor)}'>{_safe(label)}</a>" for anchor, label in items) + "</nav>"


def _metric(label: str, value: Any, note: str = "", cls: str = "") -> str:
    return f"<div class='metric'><small>{_safe(label)}</small><strong class='{_safe(cls)}'>{_safe(value)}</strong><span>{_safe(note)}</span></div>"


def _status_cell(status: Any) -> str:
    text = str(status or "INFO").upper()
    return f"<span class='status {_status_class(text)}'>{_safe(text)}</span>"


def _live_finding_html(finding: dict) -> str:
    name = str(finding.get("title") or "Observed control issue")
    status = finding.get("status") or "WARN"
    score = finding.get("finding_score", 5)
    severity, cls = _severity(score)
    evidence = finding.get("evidence") or finding.get("detail") or "A security control warning was returned by the assessment."
    remediation = finding.get("remediation") or _fix_for(name)
    priority = finding.get("priority") or ("P1" if str(status).upper() in {"FAIL", "FAILED"} else "P2")
    provenance = "Derived from observed control status; validate in context." if finding.get("derived_from_control") else "Assessment finding"
    return (f"<article class='finding-card {cls}'><div class='finding-head'><div><span class='severity {cls}'>{_safe(severity)}</span><h3>{_safe(name)}</h3></div><div class='finding-score'>{_safe(score)}/10</div></div>"
            f"<div class='meta-tags'><span>Control status: <b>{_safe(status)}</b></span><span>Category: <b>{_safe(finding.get('category') or 'API Control Review')}</b></span><span>Priority: <b>{_safe(priority)}</b></span></div>"
            f"<div class='finding-block'><h4>Observed Evidence</h4><p>{_safe(evidence)}</p></div><div class='fix-box'><h4>Recommended Remediation</h4><p>{_safe(remediation)}</p><p class='note'>{_safe(provenance)}</p></div></article>")


def generate_live_report_html(title: str, data: dict, output_path: str | Path) -> str:
    """Create a live/API-configuration report focused on HTTP evidence and controls."""
    ai = data.get("ai") if isinstance(data.get("ai"), dict) else {}
    checks = [c for c in _as_list(data.get("checks")) if isinstance(c, dict)]
    findings = _live_findings(data)
    target = data.get("effective_url") or data.get("url") or data.get("target") or "Not reported"
    method = data.get("method") or "N/A"
    status_code = data.get("status_code")
    status_label = f"HTTP {status_code}" if status_code is not None else str(data.get("test_status") or "No HTTP response")
    score = data.get("security_score")
    attention = sum(1 for c in checks if str(c.get("status", "INFO")).upper() in {"WARN", "WARNING", "FAIL", "FAILED", "ERROR"})
    report_id = data.get("report_id") or "API-STAT-LIVE-" + datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    created = _date(data.get("generated_at"))
    assessment_type = data.get("assessment_type") or "Live API Security Test"
    provider = data.get("ai_provider") or "Not reported"
    model = data.get("ai_model") or "Not reported"
    response_time = data.get("response_time_ms")
    latency = f"{response_time} ms" if response_time is not None else "N/A"
    tries = data.get("attempts", "N/A")
    check_rows = "".join(f"<tr><td>{_safe(c.get('name') or 'Control')}</td><td>{_status_cell(c.get('status'))}</td><td>{_safe(c.get('detail') or 'No evidence text was recorded.')}</td></tr>" for c in checks)
    if not check_rows:
        check_rows = "<tr><td colspan='3'><div class='empty-note'>No control checks were returned for this attempt.</div></td></tr>"
    finding_section = "".join(_live_finding_html(f) for f in findings) or "<div class='empty-note'>No WARN/FAIL control was returned. This does not prove the endpoint is fully secure or that deeper business-logic tests passed.</div>"
    executive = ai.get("executive_summary") or ("The request returned no HTTP response. Review the connectivity diagnostics before drawing conclusions." if not data.get("ok") else "The assessment completed. Review the observed controls and response evidence below.")
    remediation = _as_list(ai.get("remediation"))
    if not remediation:
        remediation = [f.get("remediation") for f in findings if f.get("remediation")]
    if not remediation:
        remediation = ["Validate the observed controls against the API's intended behavior and authentication model.", "Retest after any changes and compare the new response evidence."]
    roadmap = "".join(f"<tr><td><span class='priority'>P{i+1}</span></td><td>{_safe(item)}</td><td>Re-run the relevant API-STAT check and review the resulting evidence.</td></tr>" for i, item in enumerate(list(dict.fromkeys(str(x) for x in remediation if x))[:10]))
    if not roadmap:
        roadmap = "<tr><td colspan='3'>No remediation item was generated for this assessment.</td></tr>"
    observations = _as_list(ai.get("attack_surface_observations"))
    observation_html = "".join(f"<li>{_safe(x)}</li>" for x in observations) or "<li>No separate attack-surface observations were returned by the analysis layer.</li>"
    confidence = _confidence(ai.get("confidence"))
    request_evidence = _redact_evidence(data.get("request") or {"method": method, "url": data.get("url"), "note": "Request evidence was not returned."})
    response_obj = data.get("response") or {"status_code": status_code, "error": data.get("error"), "note": "No response body was captured."}
    response_evidence = _redact_evidence({"status_code": status_code, "effective_url": data.get("effective_url"), "response_time_ms": response_time, "headers": (response_obj.get("headers") if isinstance(response_obj, dict) else {}), "content_type": (response_obj.get("content_type") if isinstance(response_obj, dict) else None), "body_size": (response_obj.get("body_size") if isinstance(response_obj, dict) else None), "body_preview": (str(response_obj.get("body_preview") or "")[:4000] if isinstance(response_obj, dict) else "")})
    deep_label = "Enabled" if data.get("deep_scan") else "Not enabled"
    methodology = ("API-STAT issued the configured HTTP method to the supplied public HTTP(S) endpoint and recorded the response status, timing, headers, transport indicators, CORS signals and available probe results. "
                   "Any probes not run are not treated as passing. Results describe the observed request/response only and do not replace authenticated business-logic testing or a full penetration test.")
    content = f"""
<header class='cover'><div class='brand'>API-STAT • API SECURITY WORKBENCH</div><h1>{_safe(title)}</h1><div class='subtitle'>Live HTTP security assessment with observed evidence, control verification and scan-specific remediation.</div><div class='hero-meta'><div class='hero-box'><small>Report ID</small><b>{_safe(report_id)}</b></div><div class='hero-box'><small>Assessment</small><b>{_safe(assessment_type)}</b></div><div class='hero-box'><small>Target</small><b>{_safe(target)}</b></div><div class='hero-box'><small>Generated</small><b>{_safe(created)}</b></div></div></header>
{_nav([('document-control','Document Control'),('executive-summary','Executive Summary'),('scope-methodology','Scope & Methodology'),('risk-analysis','Findings & Risk'),('control-verification','Control Verification'),('remediation','Remediation'),('appendices','Evidence Appendix')])}
<section class='section' id='document-control'><div class='kicker'>TITLE PAGE & DOCUMENT CONTROL</div><h2>Assessment Identification</h2><div class='doc-grid'><div><p class='lead'>This report is generated from the API-STAT result stored for this specific test. Credential-like request and response headers are redacted in the displayed technical evidence.</p><table class='doc-table'><tr><th>Report ID</th><td>{_safe(report_id)}</td></tr><tr><th>Assessment Type</th><td>{_safe(assessment_type)}</td></tr><tr><th>Target / Scope</th><td>{_safe(target)}</td></tr><tr><th>Assessment Status</th><td>{_safe(data.get('test_status') or ('COMPLETE' if data.get('completed') else 'NO RESPONSE'))}</td></tr><tr><th>HTTP Method</th><td>{_safe(method)}</td></tr><tr><th>Generated</th><td>{_safe(created)}</td></tr><tr><th>API-STAT Version</th><td>{_safe(data.get('apistat_version') or '4.1')}</td></tr><tr><th>AI Provider / Model</th><td>{_safe(provider)} / {_safe(model)}</td></tr></table></div><div><h4>Assessment Snapshot</h4><div class='meta-tags'><span>HTTP result: <b>{_safe(status_label)}</b></span><span>Duration: <b>{_safe(latency)}</b></span><span>Attempts: <b>{_safe(tries)}</b></span><span>Deep scan: <b>{_safe(deep_label)}</b></span></div><p class='muted'>Treat this report as security-sensitive documentation. Any finding inferred from a warning control must be validated in the endpoint's actual context.</p><p><span class='tag'>Dynamic assessment data</span> <span class='tag'>Evidence-led</span> <span class='tag'>AI-assisted where configured</span></p></div></div></section>
<section class='section' id='executive-summary'><div class='kicker'>1 • EXECUTIVE SUMMARY</div><h2>Management Overview</h2><p class='lead'>{_safe(executive)}</p><div class='metrics' style='margin-top:18px'>{_metric('Security Score',f'{score}/10' if score is not None else 'N/A','Observed control posture',_score_class(score))}{_metric('HTTP Response',status_label,'Observed response')}{_metric('Control Checks',len(checks),'Recorded checks')}{_metric('Needs Attention',attention,f'{len(findings)} prioritized item(s)', 'warn' if attention else 'good')}</div></section>
<section class='section' id='scope-methodology'><div class='kicker'>2 • SCOPE & ASSESSMENT METHODOLOGY</div><h2>Scope and Methodology</h2><p class='lead'><b>Scope:</b> {_safe(target)}</p><p>{_safe(methodology)}</p><div class='meta-tags'><span>Method: <b>{_safe(method)}</b></span><span>HTTP status: <b>{_safe(status_label)}</b></span><span>Response time: <b>{_safe(latency)}</b></span><span>Deep scan: <b>{_safe(deep_label)}</b></span></div></section>
<section class='section' id='risk-analysis'><div class='kicker'>3 • TECHNICAL FINDINGS & RISK ANALYSIS</div><h2>Prioritized Security Findings</h2><p class='note'>WARN/FAIL items below are derived from the returned control statuses. They are not claims of confirmed exploitability; validate each item against the API design and deployment.</p>{finding_section}</section>
<section class='section' id='control-verification'><div class='kicker'>CONTROL VERIFICATION</div><h2>Observed Security Controls</h2><div class='table-wrap'><table class='data-table'><thead><tr><th>Control</th><th>Status</th><th>Evidence / Result</th></tr></thead><tbody>{check_rows}</tbody></table></div></section>
<section class='section' id='remediation'><div class='kicker'>4 • REMEDIATION ROADMAP & PRIORITIZATION</div><h2>Scan-Specific Recommended Actions</h2><p class='lead'>Recommendations use the warnings, response evidence and AI analysis returned for this run. Verify each action before applying it to production.</p><div class='table-wrap'><table class='data-table'><thead><tr><th>Priority</th><th>Recommended Action</th><th>Verification</th></tr></thead><tbody>{roadmap}</tbody></table></div></section>
<section class='section' id='ai-analysis'><div class='kicker'>AI ANALYSIS</div><h2>AI Interpretation & Confidence</h2><p class='lead'>{_safe(ai.get('overall_assessment') or executive)}</p><p class='muted'>Provider: {_safe(provider)} · Model: {_safe(model)} · Confidence: {_safe(confidence)}</p><h4 style='margin-top:14px'>Attack-Surface Observations</h4><ul>{observation_html}</ul></section>
<section class='section' id='appendices'><div class='kicker'>5 • APPENDICES</div><h2>Evidence & Technical Appendices</h2><div class='doc-grid'><div><h4>Appendix A — Request Evidence (Redacted)</h4><pre>{_safe(_json(request_evidence))}</pre></div><div><h4>Appendix B — Response Evidence (Redacted)</h4><pre>{_safe(_json(response_evidence))}</pre></div></div><h4 style='margin-top:18px'>Appendix C — Assessment Metadata</h4><details><summary>Show captured assessment payload</summary><pre>{_safe(_json(_redact_evidence(data)))}</pre></details></section>
<div class='footer'>Generated by API-STAT • Treat this report as security-sensitive internal documentation. Observations reflect the available evidence at execution time.</div>
"""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_page(title, content), encoding="utf-8")
    return str(path)


def _source_finding_html(finding: dict, index: int) -> str:
    score = finding.get("finding_score", finding.get("base_severity", 0))
    severity, cls = _severity(score)
    name = finding.get("title") or finding.get("rule_id") or finding.get("cve_id") or f"Security finding {index}"
    location_value = finding.get("file_path") or finding.get("endpoint") or "Location not reported"
    if finding.get("line_number"):
        location_value = f"{location_value}:{finding.get('line_number')}"
    meta = [f"Category: {finding.get('category') or 'Unclassified'}"]
    if finding.get("rule_id"):
        meta.append(f"Rule: {finding.get('rule_id')}")
    if finding.get("cve_id"):
        meta.append(f"CVE: {finding.get('cve_id')}")
    if finding.get("cvss_score") is not None:
        meta.append(f"CVSS: {finding.get('cvss_score')}")
    if finding.get("exploit_available"):
        meta.append(f"Public exploit identified: {finding.get('exploit_id') or 'Yes'}")
    evidence = finding.get("ai_explanation") or finding.get("raw_message") or "No additional evidence explanation was recorded."
    justification = finding.get("ai_justification")
    steps = [str(x) for x in _as_list(finding.get("ai_fix_steps")) if x]
    fix = finding.get("ai_fix_snippet")
    snippet = finding.get("code_snippet")
    extra_evidence = f"<div class='finding-block'><h4>AI Justification</h4><p>{_safe(justification)}</p></div>" if justification else ""
    if steps:
        extra_evidence += "<div class='finding-block'><h4>Remediation Steps</h4><ol>" + "".join(f"<li>{_safe(x)}</li>" for x in steps) + "</ol></div>"
    if fix:
        extra_evidence += f"<div class='fix-box'><h4>Suggested Code / Configuration Fix</h4><pre>{_safe(str(fix)[:6000])}</pre></div>"
    if snippet:
        extra_evidence += f"<div class='finding-block'><h4>Source Evidence</h4><pre>{_safe(str(snippet)[:6000])}</pre></div>"
    return (f"<article class='finding-card {cls}'><div class='finding-head'><div><span class='severity {cls}'>{_safe(severity)}</span><h3>{_safe(name)}</h3></div><div class='finding-score'>Score {_safe(score)}/10</div></div>"
            f"<div class='meta-tags'>" + "".join(f"<span>{_safe(item)}</span>" for item in meta) + f"<span>Location: <b>{_safe(location_value)}</b></span></div>"
            f"<div class='finding-block'><h4>Observed Evidence & Explanation</h4><p>{_safe(evidence)}</p></div>{extra_evidence}</article>")


def generate_source_report_html(title: str, data: dict, output_path: str | Path) -> str:
    """Create a source-code report focused on code locations, rules, dependencies and AI fixes."""
    ai = data.get("ai_summary") if isinstance(data.get("ai_summary"), dict) else {}
    findings = [x for x in _as_list(data.get("findings")) if isinstance(x, dict)]
    findings.sort(key=lambda f: _float(f.get("finding_score", f.get("base_severity", 0))), reverse=True)
    categories = data.get("category_scores") or data.get("category_risk_scores") or {}
    categories = categories if isinstance(categories, dict) else {}
    stats = data.get("stats") if isinstance(data.get("stats"), dict) else {}
    target = data.get("source_url") or data.get("target") or data.get("source") or "Source code submission"
    source_name = data.get("source") or "Source code submission"
    report_id = data.get("report_id") or f"API-STAT-SOURCE-{data.get('scan_id', 'UNKNOWN')}"
    created = _date(data.get("generated_at"))
    score = data.get("security_score")
    risk = data.get("risk_score")
    status = data.get("assessment_status") or "COMPLETED"
    provider = data.get("ai_provider") or "Not reported"
    model = data.get("ai_model") or "Not reported"
    critical = sum(1 for f in findings if _float(f.get("finding_score", f.get("base_severity", 0))) >= 8)
    high = sum(1 for f in findings if 6 <= _float(f.get("finding_score", f.get("base_severity", 0))) < 8)
    medium = sum(1 for f in findings if 4 <= _float(f.get("finding_score", f.get("base_severity", 0))) < 6)
    finding_html = "".join(_source_finding_html(f, i + 1) for i, f in enumerate(findings))
    if not finding_html:
        finding_html = "<div class='empty-note'>No actionable findings were recorded by this scan. This does not prove the code is fully secure; review scan coverage, files analyzed and disabled tools.</div>"
    category_cards = []
    for name, value in categories.items():
        val = _float(value)
        _, cls = _severity(val)
        bar_cls = "bad" if val >= 6 else "warn" if val >= 4 else "good"
        category_cards.append(f"<div class='domain-card'><div class='domain-head'><span>{_safe(name)}</span><b>{_safe(value)}/10</b></div><div class='bar'><i class='{bar_cls}' style='width:{max(0, min(100, val * 10)):.1f}%'></i></div><small>{_safe(_severity(val)[0])} exposure</small></div>")
    categories_html = "<div class='domain-grid'>" + "".join(category_cards) + "</div>" if category_cards else "<div class='empty-note'>The scan did not return category-level scores.</div>"
    practices = ai.get("secure_api_coding_practices") or ai.get("security_controls") or []
    practice_rows = []
    for item in _as_list(practices):
        if not isinstance(item, dict):
            practice_rows.append(f"<tr><td colspan='4'>{_safe(item)}</td></tr>")
            continue
        practice = item.get("practice") or item.get("control") or item.get("name") or "Security practice"
        evidence = item.get("evidence") or item.get("why") or item.get("detail") or ""
        remediation = item.get("remediation") or item.get("fix") or ""
        if isinstance(remediation, list):
            remediation = "; ".join(str(x) for x in remediation)
        practice_rows.append(f"<tr><td>{_safe(practice)}</td><td>{_status_cell(item.get('status'))}</td><td>{_safe(evidence)}</td><td>{_safe(remediation)}</td></tr>")
    practices_html = "".join(practice_rows) or "<tr><td colspan='4'>No separate coding-practice matrix was returned by the analysis layer.</td></tr>"
    actions = [str(x) for x in _as_list(ai.get("priority_actions")) if x]
    if not actions:
        actions = [str(x) for x in _as_list(ai.get("remediation")) if x]
    for finding in findings:
        remediation = finding.get("ai_fix_snippet")
        steps = _as_list(finding.get("ai_fix_steps"))
        if remediation:
            actions.append(str(remediation))
        elif steps:
            actions.append(str(steps[0]))
    actions = list(dict.fromkeys(actions))[:12]
    roadmap_rows = "".join(f"<tr><td><span class='priority'>P{i+1}</span></td><td>{_safe(action)}</td><td>Update the affected code/control and rerun the source scan; manually validate any residual finding.</td></tr>" for i, action in enumerate(actions))
    if not roadmap_rows:
        roadmap_rows = "<tr><td colspan='3'>No remediation actions were returned for this scan.</td></tr>"
    pipeline = [x for x in _as_list(data.get("pipeline")) if isinstance(x, dict)]
    pipeline_rows = "".join(f"<tr><td>{_safe(item.get('step') or 'Pipeline step')}</td><td>{_status_cell(item.get('status'))}</td><td>{_safe(_json(item.get('details')) if item.get('details') else '')}</td></tr>" for item in pipeline)
    if not pipeline_rows:
        pipeline_rows = "<tr><td colspan='3'>Pipeline metadata was not recorded.</td></tr>"
    executive = ai.get("executive_summary") or f"The source scan recorded {len(findings)} finding(s). Security score: {score if score is not None else 'N/A'}/10; risk score: {risk if risk is not None else 'N/A'}/10."
    summary_stats = {
        "findings": stats.get("findings", len(findings)),
        "critical": critical,
        "high": high,
        "medium": medium,
        "source_files": stats.get("files", data.get("source_file_count", "Not reported")),
        "CVEs": stats.get("cves", 0),
        "design_flaws": stats.get("design_flaws", 0),
        "public_exploits": stats.get("public_exploits", 0),
    }
    summary_table = "".join(f"<tr><th>{_safe(k.replace('_',' ').title())}</th><td>{_safe(v)}</td></tr>" for k, v in summary_stats.items())
    ai_narrative = ai.get("overall_assessment") or ai.get("methodology_notes") or "The report uses the AI summary, findings and evidence captured by this scan. If the provider shown is heuristic, the result is a local baseline rather than a remote LLM response."
    content = f"""
<header class='cover'><div class='brand'>API-STAT • API SECURITY WORKBENCH</div><h1>{_safe(title)}</h1><div class='subtitle'>Source-code security review with prioritized code evidence, vulnerability context, dependency signals and remediation guidance.</div><div class='hero-meta'><div class='hero-box'><small>Report ID</small><b>{_safe(report_id)}</b></div><div class='hero-box'><small>Assessment</small><b>Source Code Security Assessment</b></div><div class='hero-box'><small>Source / Target</small><b>{_safe(target)}</b></div><div class='hero-box'><small>Generated</small><b>{_safe(created)}</b></div></div></header>
{_nav([('document-control','Document Control'),('executive-summary','Executive Summary'),('scope-methodology','Scope & Methodology'),('risk-analysis','Findings & Risk'),('secure-practices','Coding Review'),('remediation','Remediation Roadmap'),('appendices','Pipeline & Evidence')])}
<section class='section' id='document-control'><div class='kicker'>TITLE PAGE & DOCUMENT CONTROL</div><h2>Assessment Identification</h2><div class='doc-grid'><div><p class='lead'>This report is assembled from the finding records and AI-assessment output stored for this source scan. Code location and rule references are retained to help developers reproduce and remediate each issue.</p><table class='doc-table'><tr><th>Report ID</th><td>{_safe(report_id)}</td></tr><tr><th>Assessment Type</th><td>Source Code Security Assessment</td></tr><tr><th>Source / Scope</th><td>{_safe(target)}</td></tr><tr><th>Source Name</th><td>{_safe(source_name)}</td></tr><tr><th>Assessment Status</th><td>{_safe(status)}</td></tr><tr><th>Source Kind</th><td>{_safe(data.get('source_kind') or 'Not reported')}</td></tr><tr><th>Generated</th><td>{_safe(created)}</td></tr><tr><th>AI Provider / Model</th><td>{_safe(provider)} / {_safe(model)}</td></tr></table></div><div><h4>Finding Breakdown</h4><div class='metrics' style='grid-template-columns:repeat(2,minmax(0,1fr))'>{_metric('Critical',critical,'Score 8.0–10','bad')}{_metric('High',high,'Score 6.0–7.9','bad')}{_metric('Medium',medium,'Score 4.0–5.9','warn')}{_metric('Total Findings',len(findings),'Captured in this scan')}</div><p class='muted' style='margin-top:14px'>Automated findings and AI explanations are review candidates. A qualified developer or security reviewer should validate exploitability and remediation before closure.</p></div></div></section>
<section class='section' id='executive-summary'><div class='kicker'>1 • EXECUTIVE SUMMARY</div><h2>Management Overview</h2><p class='lead'>{_safe(executive)}</p><div class='metrics' style='margin-top:18px'>{_metric('Security Score',f'{score}/10' if score is not None else 'N/A','Higher is better',_score_class(score))}{_metric('Risk Score',f'{risk}/10' if risk is not None else 'N/A','Higher indicates more risk',_score_class(risk,False))}{_metric('Findings',len(findings),'Prioritized code-review items')}{_metric('Files Reviewed',summary_stats['source_files'],'Files processed')}</div></section>
<section class='section' id='scope-methodology'><div class='kicker'>2 • SCOPE & ASSESSMENT METHODOLOGY</div><h2>Source Scope and Analysis Pipeline</h2><p class='lead'><b>Scope:</b> {_safe(target)}</p><p>The scan uses the source evidence available to API-STAT at execution time. Depending on enabled tools and acquired files, this can include static rules, API endpoint/design review, dependency and CVE matching, exploit references and AI-assisted finding explanation. A missing finding or disabled tool is not evidence that the relevant vulnerability class is absent.</p><div class='table-wrap'><table class='data-table'><thead><tr><th>Pipeline Step</th><th>Status</th><th>Execution Details</th></tr></thead><tbody>{pipeline_rows}</tbody></table></div></section>
<section class='section' id='risk-analysis'><div class='kicker'>3 • TECHNICAL FINDINGS & RISK ANALYSIS</div><h2>Security Domain Exposure</h2>{categories_html}<h3 style='margin-top:24px'>Prioritized Source Findings</h3>{finding_html}</section>
<section class='section' id='secure-practices'><div class='kicker'>SECURE CODING REVIEW</div><h2>AI-Assisted API Coding Practices</h2><p class='lead'>Practice status, evidence and recommendations are taken from this run's analysis output where available.</p><div class='table-wrap'><table class='data-table'><thead><tr><th>Practice / Control</th><th>Status</th><th>Evidence</th><th>Recommended Action</th></tr></thead><tbody>{practices_html}</tbody></table></div><h4 style='margin-top:18px'>AI Analysis</h4><p>{_safe(ai_narrative)}</p><p class='muted'>Confidence: {_safe(_confidence(ai.get('confidence')))} · Provider: {_safe(provider)} · Model: {_safe(model)}</p></section>
<section class='section' id='remediation'><div class='kicker'>4 • REMEDIATION ROADMAP & PRIORITIZATION</div><h2>Recommended Developer Actions</h2><p class='lead'>The roadmap is composed from this scan's AI priority actions and finding-level fixes. Validate each change in the application's test environment before deployment.</p><div class='table-wrap'><table class='data-table'><thead><tr><th>Priority</th><th>Recommended Action</th><th>Verification</th></tr></thead><tbody>{roadmap_rows}</tbody></table></div></section>
<section class='section' id='appendices'><div class='kicker'>5 • APPENDICES</div><h2>Scan Statistics & Technical Evidence</h2><div class='doc-grid'><div><h4>Appendix A — Scan Statistics</h4><div class='table-wrap'><table class='doc-table'>{summary_table}</table></div></div><div><h4>Appendix B — Stored Assessment Metadata</h4><details open><summary>Pipeline payload</summary><pre>{_safe(_json(_redact_evidence(pipeline)))}</pre></details></div></div><h4 style='margin-top:18px'>Appendix C — Finding Evidence Index</h4><p class='muted'>Each finding card above contains its recorded rule/category, file or endpoint location, available source evidence, AI explanation and returned remediation fields.</p><details><summary>Show full redacted scan summary</summary><pre>{_safe(_json(_redact_evidence({k:v for k,v in data.items() if k not in {'findings'}})))}</pre></details></section>
<div class='footer'>Generated by API-STAT • Treat this report as security-sensitive internal documentation. Automated results must be reviewed before they are used as compliance certification.</div>
"""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_page(title, content), encoding="utf-8")
    return str(path)
