"""Public agent API (kept stable for routes.py and other callers).

The chat itself now runs through ``app.pipeline`` (vector-routed capabilities,
RAG, streaming reasoning). This module keeps the earlier helper functions.
"""
import json, re
from typing import Dict, List
from .llm import call_llm, provider_name, model_name, _json_from_text
from . import knowledge as kbmod


def retrieve_policy(query: str, limit: int = 4) -> List[Dict]:
    """Standards/OWASP passages for a query, ranked by TF-IDF cosine similarity (was: hard-coded keyword overlap)."""
    hits = kbmod.search_kb(query or '', k=limit, min_score=0.05, cats={'owasp', 'standard'})
    return [{'title': h.payload['title'], 'keywords': h.payload['keywords'], 'text': h.payload['summary'], 'score': h.score} for h in hits]


def agent_reply(message: str, context: Dict | None = None) -> Dict:
    """Synchronous (non-streaming) answer. Runs the same pipeline as the streaming chat."""
    from .pipeline import run_pipeline
    from .capabilities import Ctx
    ctx = Ctx(message=message or '', scan=context or {})
    text, done, meta = '', {}, {}
    for event, data in run_pipeline(ctx):
        if event == 'token':
            text += data['text']
        elif event == 'done':
            done = data
        elif event == 'meta':
            meta = data
    return {'answer': text, 'actions': done.get('actions', []), 'severity': done.get('severity', 'INFO'),
            'policy_refs': done.get('policy_refs', []), 'confidence': done.get('grounding', 0.5),
            'retrieval_count': len(done.get('policy_refs', [])), 'model': meta.get('model') or model_name(),
            'provider': meta.get('provider') or provider_name()}


def analyze_visual_evidence(path: str) -> Dict:
    import base64, mimetypes, os
    if not path or not os.path.exists(path):
        return {'available': False, 'summary': 'No image evidence supplied.'}
    if provider_name() != 'openai' or not os.getenv('OPENAI_API_KEY'):
        return {'available': True, 'summary': 'Image evidence stored for the scan. Configure an OpenAI multimodal model to enable visual AI analysis.', 'provider': provider_name()}
    try:
        from openai import OpenAI
        data=base64.b64encode(open(path,'rb').read()).decode('ascii')
        mime=mimetypes.guess_type(path)[0] or 'image/png'
        client=OpenAI(api_key=os.environ['OPENAI_API_KEY'])
        r=client.chat.completions.create(
            model=os.getenv('OPENAI_VISION_MODEL', os.getenv('OPENAI_MODEL','gpt-4.1-mini')),
            temperature=0.1,
            response_format={'type':'json_object'},
            messages=[
                {'role':'system','content':'You are an API security visual analyst. Inspect only security-relevant information visible in the supplied image. Do not invent hidden system behavior. Return strict JSON with keys visual_findings (array), security_signals (array), recommended_checks (array), summary.'},
                {'role':'user','content':[{'type':'text','text':'Analyze this API security scan evidence image. It may contain an architecture diagram, endpoint screen, code screenshot, or security console.'},{'type':'image_url','image_url':{'url':f'data:{mime};base64,{data}'}}]}
            ]
        )
        out=_json_from_text(r.choices[0].message.content) or {}
        out['available']=True; out['provider']='openai'; out['model']=os.getenv('OPENAI_VISION_MODEL', os.getenv('OPENAI_MODEL','gpt-4.1-mini'))
        return out
    except Exception as exc:
        return {'available': True, 'summary': f'Visual AI analysis unavailable; image retained as scan evidence ({type(exc).__name__}).', 'error': str(exc)[:240], 'provider':'openai'}
