import io, json, os, re, shutil, socket, subprocess, tarfile, tempfile, zipfile, ipaddress, sys
from pathlib import Path
from urllib.parse import urlparse
import requests

MAX_SOURCE_BYTES=int(os.getenv('MAX_SOURCE_BYTES',str(50*1024*1024)))
MAX_FILE_BYTES=int(os.getenv('MAX_FILE_BYTES',str(5*1024*1024)))
MAX_FILES=int(os.getenv('MAX_FILES','5000'))
STATIC_TIMEOUT=int(os.getenv('STATIC_TOOL_TIMEOUT','35'))

TEXT_EXTENSIONS={'.py','.js','.jsx','.ts','.tsx','.java','.kt','.go','.rs','.php','.rb','.cs','.c','.cpp','.h','.hpp','.swift','.m','.mm','.scala','.sh','.bash','.zsh','.ps1','.sql','.yaml','.yml','.json','.xml','.toml','.ini','.cfg','.conf','.env','.properties','.txt','.md','.html','.htm','.css','.scss','.vue','.svelte','.graphql','.gql','.proto','.tf','.tfvars','.gradle','.kts','.dart','.ex','.exs','.erl','.hrl','.r','.lua','.pl','.asm'}
CODE_EXTENSIONS={e for e in TEXT_EXTENSIONS if e not in {'.json','.xml','.yaml','.yml','.toml','.ini','.cfg','.conf','.env','.properties','.txt','.md','.html','.htm','.css','.scss','.graphql','.gql','.proto','.tf','.tfvars','.gradle','.kts'}}
MANIFEST_NAMES={'requirements.txt','pyproject.toml','poetry.lock','pipfile','pipfile.lock','package.json','package-lock.json','yarn.lock','pnpm-lock.yaml','go.mod','go.sum','pom.xml','build.gradle','build.gradle.kts','composer.json','gemfile','gemfile.lock','cargo.toml','cargo.lock'}
SKIP_DIRS={'.git','.hg','.svn','node_modules','venv','.venv','env','dist','build','target','__pycache__','.pytest_cache','.mypy_cache','.tox','.idea','.vscode'}
PATTERNS=[
('Hardcoded Secret',re.compile(r'(?i)(api[_-]?key|secret|password|token|private[_-]?key|client_secret)\s*[:=]\s*[\'\"][^\'\"]{8,}[\'\"]'),8.5,'Secrets may be committed directly in source code.'),
('Command Injection',re.compile(r'(?i)\b(os\.system|subprocess\.(?:run|Popen|call)|child_process\.(?:exec|execSync)|Runtime\.getRuntime\(\)\.exec)\s*\([^\n]*(?:request|input|param|query|body|argv)'),9.0,'User-controlled input appears to reach operating-system command execution.'),
('Code Injection',re.compile(r'(?i)\b(eval|exec)\s*\([^\n]*(?:request|input|param|query|body|argv)'),9.0,'Dynamic code execution appears to use untrusted input.'),
('Unsafe Deserialization',re.compile(r'(?i)\b(pickle\.loads?|yaml\.load\s*\(|ObjectInputStream|unserialize\s*\()'),8.0,'Untrusted deserialization can enable code execution or object injection.'),
('Weak Crypto',re.compile(r'(?i)\b(md5|sha1|des|rc4)\s*\('),6.5,'A legacy cryptographic primitive was detected.'),
('Debug Mode',re.compile(r'(?i)\b(debug\s*=\s*True|app\.run\([^\n]*debug\s*=\s*True)'),7.0,'Debug mode can expose stack traces and internal application details.'),
('Wildcard CORS',re.compile(r'(?i)(Access-Control-Allow-Origin|cors|CORS).{0,160}[\'\"]\*[\'\"]'),6.0,'Wildcard CORS may expose API data to untrusted origins.'),
('TLS Verification Disabled',re.compile(r'(?i)(verify\s*=\s*False|rejectUnauthorized\s*[:=]\s*false|CURLOPT_SSL_VERIFYPEER\s*[,=]\s*0)'),8.0,'TLS certificate verification appears to be disabled.'),
('Path Traversal Risk',re.compile(r'(?i)(send_file|open|readFile|fs\.readFile|FileInputStream)\s*\([^\n]*(?:request|input|param|query|filename)'),8.0,'A filesystem operation appears to consume request-controlled path data.'),
('SQL Injection Risk',re.compile(r'(?i)(execute|query|cursor\.execute|raw\s*\().{0,180}(?:\+\s*|f[\'\"]|format\(|%\s*)'),8.5,'SQL query construction appears to use string concatenation or interpolation.'),
('Missing Security Header',re.compile(r'(?i)(Content-Security-Policy|Strict-Transport-Security|X-Content-Type-Options).{0,80}(?:missing|None|false|disable)'),5.5,'A security header may be missing or disabled.')]


def _safe_relpath(path,root):
    try:return str(path.resolve().relative_to(root.resolve())).replace('\\','/')
    except:return str(path.name)

def _is_text_candidate(path):
    n=path.name.lower()
    return n in MANIFEST_NAMES or n.startswith('.env') or n in {'dockerfile','makefile','openapi','swagger'} or path.suffix.lower() in TEXT_EXTENSIONS

def _read_text(path):
    try:
        if path.stat().st_size>MAX_FILE_BYTES:return ''
        raw=path.read_bytes()[:MAX_FILE_BYTES]
        if b'\x00' in raw[:4096]:return ''
        return raw.decode('utf-8',errors='ignore')
    except OSError:return ''

def _validate_remote_url(url):
    p=urlparse(url)
    if p.scheme not in {'http','https'} or not p.netloc:raise ValueError('Only http(s) URLs are supported.')
    host=p.hostname
    if not host:raise ValueError('URL host is missing.')
    try:
        for info in socket.getaddrinfo(host,None):
            addr=ipaddress.ip_address(info[4][0])
            if addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved or addr.is_multicast:
                raise ValueError('Private/local network URLs are blocked for SSRF safety.')
    except socket.gaierror as exc:raise ValueError('Could not resolve URL host.') from exc

def extract_archive(path,dest):
    dest.mkdir(parents=True,exist_ok=True)
    if path.suffix.lower()=='.zip' or zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            count=0; total=0
            for info in z.infolist():
                name=Path(info.filename)
                if info.is_dir() or '..' in name.parts or name.is_absolute():continue
                if count>=MAX_FILES:break
                out=dest/name; out.parent.mkdir(parents=True,exist_ok=True)
                data=z.read(info)
                if len(data)<=MAX_FILE_BYTES:
                    total+=len(data)
                    if total<=MAX_SOURCE_BYTES:out.write_bytes(data);count+=1
        return
    with tarfile.open(path) as t:
        count=0
        for m in t.getmembers():
            name=Path(m.name)
            if '..' in name.parts or name.is_absolute() or not m.isfile() or count>=MAX_FILES:continue
            if m.size>MAX_FILE_BYTES:continue
            out=dest/name;out.parent.mkdir(parents=True,exist_ok=True)
            with t.extractfile(m) as src: out.write_bytes(src.read())
            count+=1

def acquire_source(uploaded_files=None,source_url=None,work_dir=None):
    root=Path(work_dir or tempfile.mkdtemp(prefix='apistat-source-'));root.mkdir(parents=True,exist_ok=True)
    if source_url:
        _validate_remote_url(source_url); p=urlparse(source_url); lower=source_url.lower()
        if 'github.com/' in lower and not any(lower.endswith(e) for e in ('.py','.js','.jsx','.ts','.tsx','.java','.kt','.go','.rs','.php','.rb','.cs','.c','.cpp','.h','.hpp','.swift','.m','.mm','.scala','.sh','.bash','.zsh','.ps1','.sql','.vue','.svelte','.dart','.ex','.exs','.erl','.hrl','.r','.lua','.pl','.asm')):
            if not shutil.which('git'):raise RuntimeError('Git is not installed on the server; use a raw source-code URL instead.')
            target=root/'repo'
            r=subprocess.run(['git','clone','--depth','1','--filter=blob:none',source_url,str(target)],capture_output=True,text=True,timeout=90)
            if r.returncode!=0:raise RuntimeError((r.stderr or 'Git clone failed')[-1200:])
            return target,{'kind':'git-source','name':p.path.strip('/'),'source_url':source_url}
        if Path(p.path).suffix.lower() not in CODE_EXTENSIONS:
            raise ValueError('Source URL must point to source code or a GitHub source repository. Archives, JSON, YAML, Swagger/OpenAPI files and webpages are not accepted.')
        r=requests.get(source_url,timeout=25,headers={'User-Agent':'API-STAT/3.0'});r.raise_for_status()
        data=r.content
        if len(data)>MAX_SOURCE_BYTES:raise ValueError('Remote source exceeds configured size limit.')
        target=root/(Path(p.path).name or 'source.txt');target.write_bytes(data)
        return root,{'kind':'source-code-url','name':target.name,'source_url':source_url}
    if not uploaded_files:raise ValueError('Provide source-code files or a source-code URL.')
    if len(uploaded_files)>MAX_FILES:raise ValueError(f'Too many files. Limit is {MAX_FILES}.')
    total=0;names=[]
    for item in uploaded_files:
        filename=Path(getattr(item,'filename','')).name
        if not filename or Path(filename).suffix.lower() not in CODE_EXTENSIONS:
            raise ValueError(f'{filename or "Selected file"} is not a supported source-code file. Upload code only; archives/config/data files are rejected.')
        data=item.read();total+=len(data)
        if total>MAX_SOURCE_BYTES:raise ValueError(f'Source exceeds {MAX_SOURCE_BYTES//(1024*1024)} MB limit.')
        target=root/filename;target.write_bytes(data);names.append(filename)
    return root,{'kind':'source-code','name':', '.join(names[:5]),'source_url':None}

def discover_files(root):
    out=[]
    for base,dirs,names in os.walk(root):
        dirs[:]=[d for d in dirs if d not in SKIP_DIRS]
        for name in names:
            p=Path(base)/name
            try:
                if p.stat().st_size<=MAX_FILE_BYTES:out.append(p)
            except OSError:pass
            if len(out)>=MAX_FILES:return out
    return out



def redact_sensitive_text(text: str) -> str:
    if not text:
        return text
    patterns = [
        (r"(?i)(\bapi[_-]?key\b\s*[:=]\s*[\"'])([^\"']{8,})([\"'])", r"\1[REDACTED]\3"),
        (r"(?i)(\bauthorization\b\s*[:=]\s*[\"']bearer\s+)([^\"']+)([\"'])", r"\1[REDACTED]\3"),
        (r"(?i)\b(sk|pk|rk)_[A-Za-z0-9_\-]{12,}\b", "[REDACTED_API_KEY]"),
        (r"(?i)\b(AKIA[0-9A-Z]{12,})\b", "[REDACTED_AWS_KEY]"),
        (r"(?i)\bgh[pousr]_[A-Za-z0-9_]{20,}\b", "[REDACTED_GITHUB_TOKEN]"),
        (r"(?i)\bAIza[0-9A-Za-z_\-]{20,}\b", "[REDACTED_GOOGLE_KEY]"),
    ]
    for pattern,repl in patterns:
        text=re.sub(pattern,repl,text)
    return text

def _findings_from_patterns(root,files):
    out=[]
    for p in files:
        if not _is_text_candidate(p):continue
        text=_read_text(p)
        if not text:continue
        lines=text.splitlines();rel=_safe_relpath(p,root)
        for line_no,line in enumerate(lines,1):
            for rid,pat,severity,msg in PATTERNS:
                if pat.search(line):
                    out.append({'source':'static','tool':'api-stat-fast','rule_id':rid,'file_path':rel,'line_number':line_no,'code_snippet':redact_sensitive_text(line[:1800]),'raw_message':msg,'base_severity':severity,'title':rid})
    return out

def _tool_timeout():
    try:
        return max(5, min(int(os.getenv("STATIC_TOOL_TIMEOUT", "35")), 90))
    except ValueError:
        return 35

def _run_external_tool(cmd, timeout):
    """Run a security tool safely on Windows/Linux without hanging the web request."""
    env=os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    creationflags=0
    if os.name == "nt":
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        return subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="replace", env=env,
            creationflags=creationflags
        )
    except subprocess.TimeoutExpired:
        return None
    except (OSError, ValueError):
        return None

def _run_bandit(root):
    if os.getenv("ENABLE_BANDIT", "true").lower() != "true":
        return [], "disabled"
    files=[p for p in discover_files(root) if p.suffix.lower()==".py"]
    if not files:
        return [], "no-python-files"
    # Never recurse through venv/node_modules/build folders. Scan discovered files only.
    targets=[str(p) for p in files[:MAX_FILES]]
    cmd=[sys.executable, "-m", "bandit", "-f", "json", "-q", *targets]
    r=_run_external_tool(cmd, _tool_timeout())
    if r is None:
        return [], "timeout-or-unavailable"
    if not r.stdout.strip():
        if r.returncode not in (0,1):
            return [], f"tool-error:{(r.stderr or '').strip()[-300:]}"
        return [], "ok"
    try:
        data=json.loads(r.stdout or "{}")
    except json.JSONDecodeError:
        return [], "invalid-json-output"
    out=[]
    for item in data.get("results",[]):
        sev={"LOW":3.5,"MEDIUM":6.5,"HIGH":8.5}.get(str(item.get("issue_severity","")).upper(),5.0)
        out.append({
            "source":"static","tool":"bandit","rule_id":item.get("test_id"),
            "file_path":str(item.get("filename","")).replace("\\","/"),
            "line_number":item.get("line_number"),"code_snippet":item.get("code", ""),
            "raw_message":item.get("issue_text", ""),"base_severity":sev,
            "title":item.get("issue_text", "Bandit finding")[:180]
        })
    return out,"ok"

def _run_semgrep(root):
    if os.getenv("ENABLE_SEMGREP", "false").lower() != "true":
        return [], "disabled"
    # Semgrep can become expensive on large Windows workspaces; explicitly exclude build/cache trees.
    cmd=["semgrep", "scan", "--config", os.getenv("SEMGREP_CONFIG", "p/ci"),
         "--json", "--quiet", "--exclude", "venv", "--exclude", ".venv",
         "--exclude", "node_modules", "--exclude", "build", "--exclude", "dist", str(root)]
    r=_run_external_tool(cmd, _tool_timeout())
    if r is None:
        return [], "timeout-or-unavailable"
    if not r.stdout.strip():
        return [], "ok" if r.returncode in (0,1) else "tool-error"
    try:
        data=json.loads(r.stdout or "{}")
    except json.JSONDecodeError:
        return [], "invalid-json-output"
    out=[]
    for item in data.get("results",[]):
        sev={"INFO":2.0,"WARNING":5.5,"ERROR":8.0}.get(str(item.get("extra",{}).get("severity","")).upper(),6.0)
        start=item.get("start",{});extra=item.get("extra",{})
        out.append({
            "source":"static","tool":"semgrep","rule_id":item.get("check_id"),
            "file_path":item.get("path",""),"line_number":start.get("line"),
            "code_snippet":extra.get("lines", ""),"raw_message":extra.get("message", ""),
            "base_severity":sev,"title":extra.get("message", "Semgrep finding")[:180]
        })
    return out,"ok"


def run_fast_static_scan(root,progress_cb=None):
    files=discover_files(root);out=_findings_from_patterns(root,files)
    if progress_cb:progress_cb(24)
    b,status_b=_run_bandit(root);out.extend(b)
    if progress_cb:progress_cb(33)
    s,status_s=_run_semgrep(root);out.extend(s)
    if progress_cb:progress_cb(39)
    # de-duplicate same path/line/rule/message
    uniq=[];seen=set()
    for f in out:
        key=(f.get('file_path'),f.get('line_number'),f.get('rule_id'),f.get('raw_message'))
        if key in seen:continue
        seen.add(key);uniq.append(f)
    return uniq,{'files':len(files),'bandit':status_b,'semgrep':status_s}

def find_dependency_context(root):
    context={}
    for p in discover_files(root):
        txt=_read_text(p)
        if not txt:continue
        for lib in re.findall(r'(?i)(?:import|from|require\(|require\s+|use\s+)([A-Za-z0-9_@./-]{2,80})',txt):
            context.setdefault(lib.lower(),[]).append(f'{_safe_relpath(p,root)}: {txt[:1200]}')
    return {k:'\n'.join(v[:2]) for k,v in context.items()}

def detect_openapi(root):
    specs=[]
    for p in discover_files(root):
        if p.suffix.lower() not in {'.json','.yaml','.yml'} and p.name.lower() not in {'openapi','swagger'}:continue
        text=_read_text(p)
        if not text:continue
        data=None
        try:data=json.loads(text)
        except Exception:
            try:
                import yaml;data=yaml.safe_load(text)
            except Exception:continue
        if isinstance(data,dict) and (data.get('openapi') or data.get('swagger')):
            specs.append((p,data))
    return specs

def extract_endpoints(root):
    out=[];specs=detect_openapi(root)
    for p,spec in specs:
        for path,item in (spec.get('paths') or {}).items():
            if not isinstance(item,dict):continue
            for method,op in item.items():
                if method.lower() not in {'get','post','put','patch','delete','head','options','trace'} or not isinstance(op,dict):continue
                out.append({'path':path,'method':method.upper(),'summary':op.get('summary') or op.get('description') or '','operation_id':op.get('operationId'),'spec_file':_safe_relpath(p,root)})
    return out[:int(os.getenv('MAX_OPENAPI_ENDPOINTS','40'))]

def endpoint_context(root,endpoints):
    texts=[]
    for p in discover_files(root):
        if _is_text_candidate(p):
            txt=_read_text(p)
            if txt:texts.append((_safe_relpath(p,root),txt))
    context={}
    for ep in endpoints:
        tokens=[ep['path'].strip('/'),ep.get('operation_id') or '',ep.get('summary') or '']
        matches=[]
        for path,txt in texts:
            if any(t and t.lower() in txt.lower() for t in tokens):matches.append(f'{path}:\n{txt[:2500]}')
        context[ep['path']]='\n\n'.join(matches[:3])
    return context

def _looks_like_api_key_source(text: str) -> bool:
    """Return True when source contains an API credential/key-like assignment."""
    patterns = [
        r"(?i)\b(api[_-]?key|apikey|client[_-]?secret|access[_-]?token|secret[_-]?key|bearer[_-]?token)\b\s*[:=]\s*[\"'][^\"']{8,}[\"']",
        r"(?i)\b(authorization)\b\s*[:=]\s*[\"']bearer\s+[A-Za-z0-9._\-]{12,}[\"']",
        r"(?i)\b(sk|pk|rk)_[A-Za-z0-9_\-]{12,}\b",
        r"(?i)\b(AKIA[0-9A-Z]{12,})\b",
        r"(?i)\bgh[pousr]_[A-Za-z0-9_]{20,}\b",
        r"(?i)\bAIza[0-9A-Za-z_\-]{20,}\b",
    ]
    return any(re.search(pattern, text) for pattern in patterns)


def source_contains_api_key(root):
    """Require source-code input to contain at least one API-key/token-like value."""
    for p in discover_files(root):
        if p.suffix.lower() not in CODE_EXTENSIONS:
            continue
        text = _read_text(p)
        if text and _looks_like_api_key_source(text):
            return True
    return False


def _api_headers_checks(headers):
    h={k.lower():v for k,v in headers.items()}
    checks=[]
    def add(name,status,detail): checks.append({'name':name,'status':status,'detail':detail})
    add('HTTPS', 'PASS' if h.get('_effective_https')=='true' else 'WARN', 'Endpoint is served over HTTPS.' if h.get('_effective_https')=='true' else 'Endpoint is not using HTTPS.')
    add('HSTS', 'PASS' if 'strict-transport-security' in h else 'WARN', 'Strict-Transport-Security is present.' if 'strict-transport-security' in h else 'HSTS header is missing.')
    add('Content-Type safety', 'PASS' if 'x-content-type-options' in h and 'nosniff' in str(h.get('x-content-type-options','')).lower() else 'WARN', 'X-Content-Type-Options is set to nosniff.' if 'x-content-type-options' in h else 'X-Content-Type-Options is missing.')
    add('CORS', 'WARN' if h.get('access-control-allow-origin')=='*' else 'PASS', 'Wildcard CORS is exposed.' if h.get('access-control-allow-origin')=='*' else 'No wildcard CORS observed on this response.')
    add('CSP', 'PASS' if 'content-security-policy' in h else 'INFO', 'Content-Security-Policy is present.' if 'content-security-policy' in h else 'No CSP header observed on this response.')
    add('Cache control', 'PASS' if 'cache-control' in h else 'INFO', 'Cache-Control is present.' if 'cache-control' in h else 'Cache-Control header was not observed.')
    return checks

def basic_api_config_check(url, timeout=10):
    _validate_remote_url(url)
    started=__import__('time').perf_counter(); r=requests.get(url,headers={'User-Agent':'API-STAT-Config-Check/3.2','Accept':'*/*'},timeout=max(3,min(int(timeout),20)),allow_redirects=True)
    elapsed=round((__import__('time').perf_counter()-started)*1000,1)
    hdr=dict(r.headers); hdr['_effective_https']='true' if r.url.lower().startswith('https://') else 'false'
    checks=_api_headers_checks(hdr); lower={k.lower():v for k,v in r.headers.items()}
    checks.insert(0,{'name':'Reachability','status':'PASS','detail':f'Endpoint responded with HTTP {r.status_code} in {elapsed} ms.'})
    try:
        o=requests.options(url,headers={'User-Agent':'API-STAT-Config-Check/3.2','Origin':'https://api-stat.local','Access-Control-Request-Method':'GET'},timeout=max(3,min(int(timeout),15)),allow_redirects=True)
        ol={k.lower():v for k,v in o.headers.items()}
        checks.append({'name':'OPTIONS / CORS policy','status':'WARN' if ol.get('access-control-allow-origin')=='*' else 'PASS','detail':f'OPTIONS returned HTTP {o.status_code}; wildcard CORS observed.' if ol.get('access-control-allow-origin')=='*' else f'OPTIONS returned HTTP {o.status_code}; no wildcard CORS observed.'})
        allow=ol.get('allow') or ol.get('access-control-allow-methods')
        if allow: checks.append({'name':'Allowed methods disclosure','status':'INFO','detail':f'API advertises methods: {allow}'})
    except requests.RequestException as exc:
        checks.append({'name':'OPTIONS visibility','status':'INFO','detail':f'OPTIONS check could not be completed: {exc}'})
    score=10.0; score-=2.5 if not r.url.lower().startswith('https://') else 0; score-=1.2 if 'strict-transport-security' not in lower else 0; score-=0.8 if 'x-content-type-options' not in lower else 0; score-=1.5 if lower.get('access-control-allow-origin')=='*' else 0
    score=max(0,min(10,score))
    return {'completed':True,'ok':True,'type':'basic-config','url':url,'effective_url':r.url,'status_code':r.status_code,'response_time_ms':elapsed,'security_score':round(score,1),'checks':checks,'headers':dict(r.headers)}


# ---------------------------------------------------------------------------
# API Config Check terminal: purpose-built, bounded HTTP configuration checks
# and passive API inventory discovery. These helpers do not execute shell
# commands and never send state-changing HTTP methods.
# ---------------------------------------------------------------------------

import html.parser as _html_parser
import ssl as _ssl
import datetime as _datetime
import xml.etree.ElementTree as _ET
from urllib.parse import urljoin as _urljoin, urlsplit as _urlsplit, urlunsplit as _urlunsplit

API_CONFIG_COMMANDS = {
    'site-config', 'header-config', 'tls-config', 'cors-config', 'method-config',
    'api-docs', 'sitemap-map', 'js-route-map', 'api-discover', 'full-report'
}
API_CONFIG_USER_AGENT = 'API-STAT-Config-Check/4.1'
API_CONFIG_MAX_BODY = 1_000_000
API_CONFIG_MAX_JS_ASSETS = 18
API_CONFIG_MAX_ENDPOINTS = 30
API_CONFIG_MAX_REDIRECTS = 4


class _ScriptSourceParser(_html_parser.HTMLParser):
    """Collect script src values without executing any page script."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.sources = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() != 'script':
            return
        values = dict(attrs)
        src = values.get('src')
        if src:
            self.sources.append(src.strip())


def _config_url_parts(url):
    try:
        p = _urlsplit(str(url).strip())
        # Accessing .port validates malformed/non-numeric ports.
        port = p.port
    except (TypeError, ValueError) as exc:
        raise ValueError('Enter a valid absolute HTTP(S) URL.') from exc
    if p.scheme.lower() not in {'http', 'https'} or not p.hostname:
        raise ValueError('Only absolute HTTP(S) URLs are supported.')
    if p.username is not None or p.password is not None:
        raise ValueError('URLs containing embedded credentials are not allowed.')
    if port is not None and not (1 <= port <= 65535):
        raise ValueError('The URL port is outside the valid range.')
    if not p.hostname or any(ch.isspace() for ch in p.hostname):
        raise ValueError('The URL hostname is invalid.')
    return p


def _config_resolve_public(host):
    """Reject a hostname if any resolved address is not globally routable."""
    try:
        records = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise ValueError('The target hostname could not be resolved.') from exc
    if not records:
        raise ValueError('The target hostname did not resolve to an address.')
    addresses = []
    seen = set()
    for family, socktype, proto, canonname, sockaddr in records:
        try:
            addr = ipaddress.ip_address(sockaddr[0].split('%', 1)[0])
        except ValueError as exc:
            raise ValueError('The target hostname resolved to an invalid address.') from exc
        if not addr.is_global:
            raise ValueError('Private, local, reserved and non-public target addresses are blocked.')
        key = (family, sockaddr[0])
        if key not in seen:
            seen.add(key)
            addresses.append((family, sockaddr))
    return addresses


def _config_validate_url(url, allowed_host=None, allowed_ports=None):
    p = _config_url_parts(url)
    host = p.hostname.rstrip('.').lower()
    if allowed_host and host != allowed_host.rstrip('.').lower():
        raise ValueError('Cross-host redirects and out-of-scope endpoints are blocked. Enter the approved host URL directly.')
    effective_port = p.port or (443 if p.scheme.lower() == 'https' else 80)
    if allowed_ports is not None and effective_port not in allowed_ports:
        raise ValueError('Out-of-scope port blocked by the API Config Check policy.')
    _config_resolve_public(host)
    # Existing validator also guards against common local/reserved address forms.
    _validate_remote_url(str(url))
    return p


def _config_origin(url):
    p = _urlsplit(url)
    default_port = 443 if p.scheme.lower() == 'https' else 80
    host = (p.hostname or '').lower().rstrip('.')
    port = p.port or default_port
    netloc = f'[{host}]' if ':' in host else host
    if port != default_port:
        netloc = f'{netloc}:{port}'
    return _urlunsplit((p.scheme.lower(), netloc, '/', '', ''))


def _config_public_headers(headers):
    """Keep useful evidence while preventing cookie/auth header values leaking."""
    safe = {}
    for key, value in headers.items():
        name = str(key)
        raw = str(value)[:2000]
        lname = name.lower()
        if lname in {'set-cookie', 'authorization', 'proxy-authorization', 'www-authenticate'}:
            if lname == 'set-cookie':
                flags = []
                for part in raw.split(';')[1:]:
                    part = part.strip()
                    if part.lower() in {'secure', 'httponly'} or part.lower().startswith('samesite=') or part.lower().startswith('path=') or part.lower().startswith('domain=') or part.lower().startswith('max-age='):
                        flags.append(part)
                safe[name] = '[COOKIE VALUE REDACTED]' + ('; ' + '; '.join(flags) if flags else '')
            else:
                safe[name] = '[REDACTED]'
        else:
            safe[name] = raw
    return safe


def _config_fetch(url, timeout=6, method='GET', headers=None, allowed_host=None, allowed_ports=None, max_body=API_CONFIG_MAX_BODY):
    """Make one bounded request; validate every redirect before following it."""
    current = str(url)
    initial = _config_url_parts(current)
    scope_host = (allowed_host or initial.hostname or '').lower().rstrip('.')
    scope_ports = allowed_ports
    timeout = max(2, min(int(timeout), 10))
    request_headers = {'User-Agent': API_CONFIG_USER_AGENT, 'Accept': '*/*'}
    if headers:
        request_headers.update({str(k): str(v)[:1000] for k, v in headers.items()})
    redirects = []
    started = __import__('time').perf_counter()
    session = requests.Session()
    # Do not let deployment proxy environment variables silently reroute scanner traffic.
    session.trust_env = False
    try:
        for hop in range(API_CONFIG_MAX_REDIRECTS + 1):
            _config_validate_url(current, scope_host, scope_ports)
            try:
                with session.request(method.upper(), current, headers=request_headers, timeout=(timeout, timeout),
                                     allow_redirects=False, stream=True, verify=True) as response:
                    location = response.headers.get('Location')
                    if response.status_code in {301, 302, 303, 307, 308} and location:
                        if hop >= API_CONFIG_MAX_REDIRECTS:
                            raise ValueError('Redirect limit exceeded.')
                        nxt = _urljoin(current, location)
                        nxt_parts = _config_url_parts(nxt)
                        if (nxt_parts.hostname or '').lower().rstrip('.') != scope_host:
                            raise ValueError('Cross-host redirect blocked. Enter the approved final hostname directly.')
                        _config_validate_url(nxt, scope_host, scope_ports)
                        redirects.append({'status_code': response.status_code, 'from': _redact_config_url(current), 'to': _redact_config_url(nxt)})
                        # RFC: 303 changes method to GET; 301/302 for HEAD stays HEAD.
                        if response.status_code == 303 and method.upper() != 'HEAD':
                            method = 'GET'
                        current = nxt
                        continue
                    content = b''
                    if method.upper() not in {'HEAD'}:
                        try:
                            for chunk in response.iter_content(chunk_size=16384):
                                if not chunk:
                                    continue
                                room = max_body - len(content)
                                if room <= 0:
                                    break
                                content += chunk[:room]
                                if len(content) >= max_body:
                                    break
                        except requests.RequestException:
                            # A truncated body is still useful evidence; record the size cap.
                            pass
                    encoding = response.encoding or 'utf-8'
                    try:
                        body = content.decode(encoding, errors='replace')
                    except LookupError:
                        body = content.decode('utf-8', errors='replace')
                    return {
                        'status_code': int(response.status_code),
                        'url': current,
                        'response_time_ms': round((__import__('time').perf_counter() - started) * 1000, 1),
                        'headers': _config_public_headers(response.headers),
                        'raw_headers': dict(response.headers),
                        'content_type': response.headers.get('Content-Type', ''),
                        'body': body,
                        'body_truncated': len(content) >= max_body,
                        'body_size_captured': len(content),
                        'redirect_chain': redirects,
                    }
            except requests.RequestException as exc:
                raise ValueError(f'HTTP request failed: {type(exc).__name__}: {str(exc)[:240]}') from exc
        raise ValueError('Redirect processing failed.')
    finally:
        session.close()


def _redact_config_url(url):
    try:
        p = _urlsplit(str(url))
        return _urlunsplit((p.scheme, p.netloc, p.path, '[query redacted]' if p.query else '', ''))
    except Exception:
        return '[URL redacted]'


def _config_add_check(checks, name, status, detail, evidence=None, severity=None):
    row = {'name': name, 'status': status, 'detail': str(detail)[:1000]}
    if evidence is not None:
        row['evidence'] = str(evidence)[:1000]
    if severity:
        row['severity'] = severity
    checks.append(row)


def _config_header_checks(headers, is_https):
    h = {str(k).lower(): str(v) for k, v in (headers or {}).items()}
    checks = []
    _config_add_check(checks, 'HTTPS', 'PASS' if is_https else 'WARN',
                      'Target uses HTTPS.' if is_https else 'Target uses HTTP; transport confidentiality is not provided.', severity='INFO' if is_https else 'HIGH')
    hsts = h.get('strict-transport-security')
    _config_add_check(checks, 'HSTS', 'PASS' if hsts else 'WARN',
                      f'HSTS observed: {hsts[:180]}' if hsts else 'Strict-Transport-Security was not observed on this response.', severity='INFO' if hsts else 'LOW')
    csp = h.get('content-security-policy')
    _config_add_check(checks, 'Content Security Policy', 'PASS' if csp else 'INFO',
                      'Content-Security-Policy was observed.' if csp else 'CSP was not observed; evaluate based on whether the target serves browser-rendered content.', severity='INFO' if csp else 'LOW')
    nosniff = h.get('x-content-type-options', '').lower() == 'nosniff'
    _config_add_check(checks, 'MIME sniffing protection', 'PASS' if nosniff else 'WARN',
                      'X-Content-Type-Options: nosniff is present.' if nosniff else 'X-Content-Type-Options: nosniff was not observed.', severity='INFO' if nosniff else 'LOW')
    frame = h.get('x-frame-options') or csp
    frame_ok = bool(h.get('x-frame-options') or ('frame-ancestors' in csp.lower()))
    _config_add_check(checks, 'Framing protection', 'PASS' if frame_ok else 'INFO',
                      'A frame protection policy was observed.' if frame_ok else 'No X-Frame-Options or CSP frame-ancestors directive was observed.', severity='INFO' if frame_ok else 'LOW')
    _config_add_check(checks, 'Referrer Policy', 'PASS' if h.get('referrer-policy') else 'INFO',
                      'Referrer-Policy was observed.' if h.get('referrer-policy') else 'Referrer-Policy was not observed.', severity='INFO')
    cache = h.get('cache-control', '').lower()
    sensitive_cache = any(x in cache for x in ('no-store', 'private'))
    _config_add_check(checks, 'Cache policy', 'INFO' if not cache else ('PASS' if sensitive_cache else 'INFO'),
                      f'Cache-Control: {cache}' if cache else 'No Cache-Control directive was observed. For authenticated or sensitive API responses, verify that an appropriate private/no-store policy is applied.', severity='INFO')
    cors = h.get('access-control-allow-origin', '')
    _config_add_check(checks, 'CORS response', 'WARN' if cors.strip() == '*' else ('INFO' if not cors else 'PASS'),
                      'Wildcard Access-Control-Allow-Origin was observed; verify whether the resource is intended to be public.' if cors.strip() == '*' else ('CORS headers were observed; validate against the intended origin policy.' if cors else 'No Access-Control-Allow-Origin header was observed on this response; this is not proof of a CORS vulnerability.'), severity='MEDIUM' if cors.strip() == '*' else 'INFO')
    server = h.get('server') or h.get('x-powered-by')
    _config_add_check(checks, 'Server information disclosure', 'INFO' if server else 'PASS',
                      f'Server technology header observed: {server[:160]}' if server else 'No Server or X-Powered-By header was observed.', severity='LOW' if server else 'INFO')
    return checks


def _config_parse_spec(body, content_type=''):
    """Return API route entries only when the response looks like a spec."""
    if not body or len(body) > API_CONFIG_MAX_BODY:
        return None
    obj = None
    try:
        obj = json.loads(body)
    except (ValueError, TypeError):
        try:
            import yaml
            obj = yaml.safe_load(body)
        except Exception:
            return None
    if not isinstance(obj, dict) or not isinstance(obj.get('paths'), dict):
        return None
    if not (obj.get('openapi') or obj.get('swagger') or 'info' in obj):
        return None
    paths = []
    allowed_methods = {'get', 'head', 'post', 'put', 'patch', 'delete', 'options', 'trace'}
    for path, operations in list(obj.get('paths', {}).items())[:500]:
        if not isinstance(path, str) or not isinstance(operations, dict):
            continue
        methods = [k.upper() for k in operations if str(k).lower() in allowed_methods]
        paths.append({'path': path[:300], 'methods': methods, 'discovery_source': 'OpenAPI/Swagger specification'})
    return {'title': str((obj.get('info') or {}).get('title') or 'API specification')[:200],
            'version': str(obj.get('openapi') or obj.get('swagger') or 'unknown')[:50], 'paths': paths}


_CONFIG_DOC_PATHS = [
    '/openapi.json', '/openapi.yaml', '/swagger.json', '/swagger.yaml',
    '/api-docs', '/v3/api-docs', '/v2/api-docs', '/swagger/v1/swagger.json',
    '/api/openapi.json', '/api/swagger.json', '/docs/openapi.json',
]
_CONFIG_COMMON_PATHS = [
    '/api', '/api/v1', '/api/v2', '/v1', '/v2', '/v3', '/graphql', '/rest',
    '/api/health', '/health', '/api/status', '/status', '/api/version',
    '/api/users', '/api/products', '/api/courses', '/api/notices',
    '/api/auth', '/api/login', '/oauth', '/oauth/token', '/api/graphql',
]
_ROUTE_MARKER = re.compile(r'(?i)(?:^|/)(?:api(?:/|$)|rest(?:/|$)|graphql(?:/|$)|oauth(?:/|$)|v\d+(?:/|$)|openapi|swagger)')


def _config_docs(root_url, timeout, fetch):
    base = _config_origin(root_url)
    attempted, specifications, candidates = [], [], []
    for path in _CONFIG_DOC_PATHS:
        url = _urljoin(base, path.lstrip('/'))
        try:
            item = fetch(url, timeout=timeout, max_body=API_CONFIG_MAX_BODY)
            parsed = _config_parse_spec(item['body'], item.get('content_type', ''))
            attempted.append({'path': path, 'status_code': item['status_code'], 'content_type': item.get('content_type', ''), 'spec_found': bool(parsed)})
            if parsed:
                spec = {'url': _redact_config_url(item['url']), **parsed}
                specifications.append(spec)
                for route in parsed['paths']:
                    candidates.append({**route, 'url': _urljoin(base, route['path'].lstrip('/')), 'spec_url': _redact_config_url(item['url'])})
            elif item['status_code'] == 200 and ('swagger' in item['body'][:8000].lower() or 'openapi' in item['body'][:8000].lower()):
                attempted[-1]['possible_documentation_ui'] = True
        except (ValueError, requests.RequestException) as exc:
            attempted.append({'path': path, 'error': str(exc)[:220]})
    return {'attempted': attempted, 'specifications': specifications, 'endpoints': candidates}


def _config_sitemap(root_url, timeout, fetch):
    base = _config_origin(root_url)
    robots_url = _urljoin(base, 'robots.txt')
    sitemap_urls = [_urljoin(base, 'sitemap.xml')]
    pages, evidence = [], []
    try:
        robots = fetch(robots_url, timeout=timeout, max_body=250_000)
        evidence.append({'resource': '/robots.txt', 'status_code': robots['status_code']})
        if 200 <= robots['status_code'] < 300:
            for line in robots['body'].splitlines():
                match = re.match(r'(?i)^\s*sitemap:\s*(\S+)', line)
                if match:
                    candidate = match.group(1).strip()
                    try:
                        cp = _config_url_parts(candidate)
                        if cp.hostname and cp.hostname.lower().rstrip('.') == _urlsplit(base).hostname.lower().rstrip('.'):
                            sitemap_urls.append(candidate)
                    except ValueError:
                        pass
    except (ValueError, requests.RequestException) as exc:
        evidence.append({'resource': '/robots.txt', 'error': str(exc)[:200]})
    seen_maps = set()
    for sitemap_url in sitemap_urls[:4]:
        sitemap_url = _urlunsplit((*_urlsplit(sitemap_url)[:3], '', ''))
        if sitemap_url in seen_maps:
            continue
        seen_maps.add(sitemap_url)
        try:
            item = fetch(sitemap_url, timeout=timeout, max_body=750_000)
            evidence.append({'resource': _redact_config_url(sitemap_url), 'status_code': item['status_code'], 'content_type': item.get('content_type', '')})
            if not (200 <= item['status_code'] < 300):
                continue
            try:
                root = _ET.fromstring(item['body'])
            except _ET.ParseError:
                continue
            for node in root.iter():
                if node.tag.rsplit('}', 1)[-1].lower() != 'loc' or not node.text:
                    continue
                loc = node.text.strip()
                try:
                    lp = _config_url_parts(loc)
                    if lp.hostname and lp.hostname.lower().rstrip('.') == _urlsplit(base).hostname.lower().rstrip('.'):
                        pages.append(_redact_config_url(loc))
                except ValueError:
                    continue
                if len(pages) >= 500:
                    break
        except (ValueError, requests.RequestException) as exc:
            evidence.append({'resource': _redact_config_url(sitemap_url), 'error': str(exc)[:200]})
    pages = list(dict.fromkeys(pages))
    return {'resources': evidence, 'pages': pages[:500], 'page_count': len(pages)}


def _config_js_routes(root_url, timeout, fetch):
    base = _config_origin(root_url)
    try:
        page = fetch(root_url, timeout=timeout, max_body=API_CONFIG_MAX_BODY)
    except (ValueError, requests.RequestException) as exc:
        return {'assets': [], 'routes': [], 'errors': [str(exc)[:220]]}
    parser = _ScriptSourceParser()
    try:
        parser.feed(page['body'])
    except Exception:
        pass
    script_urls = []
    for src in parser.sources:
        if src.startswith(('data:', 'javascript:', '#')):
            continue
        full = _urljoin(page['url'], src)
        try:
            p = _config_url_parts(full)
            if p.hostname.lower().rstrip('.') != _urlsplit(base).hostname.lower().rstrip('.'):
                continue
            if not (p.path.lower().endswith('.js') or 'javascript' in p.path.lower()):
                continue
            cleaned = _urlunsplit((p.scheme, p.netloc, p.path, p.query, ''))
            if cleaned not in script_urls:
                script_urls.append(cleaned)
        except ValueError:
            continue
        if len(script_urls) >= API_CONFIG_MAX_JS_ASSETS:
            break
    assets, route_map, errors = [], {}, []
    for asset_url in script_urls:
        try:
            item = fetch(asset_url, timeout=timeout, max_body=500_000)
            assets.append({'url': _redact_config_url(asset_url), 'status_code': item['status_code'], 'bytes_captured': item['body_size_captured'], 'truncated': item['body_truncated']})
            if not (200 <= item['status_code'] < 300):
                continue
            # Only quoted route-like strings are extracted; JavaScript is never run.
            for match in re.finditer(r"[\"'`]([^\"'`\\s]{1,220})[\"'`]", item['body']):
                value = match.group(1).replace('\\/', '/')
                if not value.startswith('/') or value.startswith('//') or not _ROUTE_MARKER.search(value):
                    continue
                value = value.split('#', 1)[0]
                if value in {'/', '/api'}:
                    continue
                route_map.setdefault(value, {'path': value, 'url': _urljoin(base, value.lstrip('/')), 'discovery_source': 'public JavaScript asset', 'source_asset': _redact_config_url(asset_url)})
                if len(route_map) >= 200:
                    break
        except (ValueError, requests.RequestException) as exc:
            errors.append(f'{_redact_config_url(asset_url)}: {str(exc)[:160]}')
    return {'assets': assets, 'routes': list(route_map.values())[:200], 'errors': errors, 'assets_examined': len(assets)}


def _config_tls(url, timeout):
    p = _config_validate_url(url)
    if p.scheme.lower() != 'https':
        return {'checks': [{'name': 'TLS', 'status': 'FAIL', 'severity': 'HIGH', 'detail': 'Target URL uses HTTP; TLS cannot be assessed at this URL.'}], 'certificate': None}
    host = p.hostname
    port = p.port or 443
    addresses = _config_resolve_public(host)
    context = _ssl.create_default_context()
    context.check_hostname = True
    context.verify_mode = _ssl.CERT_REQUIRED
    last_error = None
    for family, sockaddr in addresses[:8]:
        try:
            # Connect to a previously validated public address while retaining SNI/hostname checks.
            raw = socket.socket(family, socket.SOCK_STREAM)
            raw.settimeout(max(2, min(int(timeout), 8)))
            try:
                raw.connect((sockaddr[0], port))
                with context.wrap_socket(raw, server_hostname=host) as wrapped:
                    cert = wrapped.getpeercert()
                    not_after = cert.get('notAfter')
                    expires = None
                    days_left = None
                    if not_after:
                        dt = _datetime.datetime.strptime(not_after, '%b %d %H:%M:%S %Y %Z').replace(tzinfo=_datetime.timezone.utc)
                        expires = dt.isoformat()
                        days_left = int((dt - _datetime.datetime.now(_datetime.timezone.utc)).total_seconds() // 86400)
                    checks = []
                    _config_add_check(checks, 'TLS handshake', 'PASS', f'Validated TLS handshake using {wrapped.version() or "unknown protocol"}; cipher {((wrapped.cipher() or ["unknown"])[0])}.')
                    status = 'PASS' if days_left is not None and days_left > 14 else ('WARN' if days_left is not None and days_left >= 0 else 'FAIL')
                    detail = f'Certificate expiry: {expires}; days remaining: {days_left}.' if days_left is not None else 'Certificate validated, but expiry details were unavailable.'
                    _config_add_check(checks, 'Certificate expiry', status if days_left is not None else 'INFO', detail, severity='HIGH' if status == 'FAIL' else ('MEDIUM' if status == 'WARN' else 'INFO'))
                    _config_add_check(checks, 'Hostname validation', 'PASS', 'Certificate verification succeeded for the requested hostname.')
                    return {'checks': checks, 'certificate': {'subject': str(cert.get('subject', ''))[:400], 'issuer': str(cert.get('issuer', ''))[:400], 'not_after': expires, 'days_remaining': days_left, 'tls_version': wrapped.version(), 'cipher': (wrapped.cipher() or [None])[0]}}
            finally:
                try:
                    raw.close()
                except Exception:
                    pass
        except (OSError, _ssl.SSLError, ValueError) as exc:
            last_error = exc
    return {'checks': [{'name': 'TLS validation', 'status': 'FAIL', 'severity': 'HIGH', 'detail': f'TLS validation did not complete: {type(last_error).__name__ if last_error else "ConnectionError"}: {str(last_error)[:220] if last_error else "no public address connected"}'}], 'certificate': None}


def _config_base_result(command, url, data=None):
    data = data or {}
    checks = data.get('checks') or []
    statuses = [str(c.get('status', 'INFO')).upper() for c in checks]
    deductions = sum(1.5 if s == 'FAIL' else 0.8 if s == 'WARN' else 0 for s in statuses)
    score = round(max(0.0, min(10.0, 10.0 - deductions)), 1)
    return {
        'completed': True, 'ok': not any(s == 'FAIL' for s in statuses),
        'type': 'api-config-check', 'command': command, 'url': _redact_config_url(url),
        'effective_url': data.get('effective_url') or _redact_config_url(url),
        'status_code': data.get('status_code'), 'response_time_ms': data.get('response_time_ms'),
        'security_score': score, 'checks': checks, 'headers': data.get('headers') or {},
        'endpoints': data.get('endpoints') or [], 'findings': data.get('findings') or [],
        'summary': data.get('summary') or '', 'discovery': data.get('discovery') or {},
        'redirect_chain': data.get('redirect_chain') or [], 'body_truncated': data.get('body_truncated', False),
    }


def run_api_config_command(command, url, timeout=6):
    """Dispatch one of the ten API Config Check commands and return evidence JSON."""
    command = str(command or '').strip().lower()
    if command not in API_CONFIG_COMMANDS:
        raise ValueError('Unsupported API Config Check command. Use help to list the ten supported commands.')
    url = str(url or '').strip()
    _config_validate_url(url)
    timeout = max(2, min(int(timeout), 8))
    origin = _config_origin(url)
    original_parts = _urlsplit(url)
    root_host = (original_parts.hostname or '').lower().rstrip('.')
    original_port = original_parts.port
    allowed_ports = {original_port} if original_port else {80, 443}
    cache = {}
    started = __import__('time').perf_counter()
    budget_seconds = 42 if command == 'full-report' else (28 if command == 'api-discover' else 22)
    deadline = started + budget_seconds

    def fetch(target, timeout=timeout, method='GET', headers=None, max_body=API_CONFIG_MAX_BODY):
        header_key = tuple(sorted((str(k).lower(), str(v)) for k, v in (headers or {}).items()))
        key = (method.upper(), target, header_key, max_body)
        if method.upper() == 'GET' and key in cache:
            return cache[key]
        remaining = deadline - __import__('time').perf_counter()
        if remaining <= 0.75:
            raise ValueError('Time budget reached; remaining discovery checks were skipped. Run the focused command for more detail.')
        result = _config_fetch(target, timeout=min(timeout, max(2, int(remaining))), method=method, headers=headers, allowed_host=root_host, allowed_ports=allowed_ports, max_body=max_body)
        if method.upper() == 'GET':
            cache[key] = result
        return result

    data = {'checks': [], 'headers': {}, 'endpoints': [], 'findings': [], 'discovery': {}}

    def get_home():
        response = fetch(url, timeout=timeout, max_body=API_CONFIG_MAX_BODY)
        data.update({'status_code': response['status_code'], 'effective_url': response['url'],
                     'response_time_ms': response['response_time_ms'], 'headers': response['headers'],
                     'redirect_chain': response['redirect_chain'], 'body_truncated': response['body_truncated']})
        return response

    if command in {'site-config', 'header-config', 'full-report'}:
        response = get_home()
        is_https = _urlsplit(response['url']).scheme.lower() == 'https'
        if command in {'site-config', 'full-report'}:
            status = 'PASS' if 200 <= response['status_code'] < 400 else 'WARN'
            _config_add_check(data['checks'], 'Reachability', status,
                              f'HTTP {response["status_code"]} observed in {response["response_time_ms"]} ms.', severity='INFO' if status == 'PASS' else 'MEDIUM')
            _config_add_check(data['checks'], 'Content type', 'INFO', f'Observed Content-Type: {response.get("content_type") or "not supplied"}.')
            data['summary'] = 'HTTP baseline collected; review each observed control and any informational item.'
        data['checks'].extend(_config_header_checks(response['raw_headers'], is_https))
        if command == 'header-config':
            data['summary'] = 'Header policy observations collected from the live response. Missing headers are context-dependent.'

    if command in {'tls-config', 'full-report'}:
        tls = _config_tls(url, timeout)
        data['checks'].extend(tls['checks'])
        data['discovery']['tls'] = tls['certificate']

    if command in {'cors-config', 'full-report'}:
        origin_header = 'https://apistat-origin.invalid'
        cors_get = fetch(url, timeout=timeout, headers={'Origin': origin_header}, max_body=64_000)
        cors_headers = {k.lower(): str(v) for k, v in cors_get['raw_headers'].items()}
        allow_origin = cors_headers.get('access-control-allow-origin', '')
        allow_credentials = cors_headers.get('access-control-allow-credentials', '').lower() == 'true'
        if allow_origin == '*':
            status, detail, severity = 'WARN', 'Wildcard origin was returned for the controlled Origin request. Determine whether the resource is intended to be public; wildcard CORS alone is not proof of data exposure.', 'MEDIUM'
        elif allow_origin == origin_header and allow_credentials:
            status, detail, severity = 'WARN', 'The server reflects the controlled Origin and permits credentials. Verify the allowlist logic and whether untrusted origins can be reflected.', 'MEDIUM'
        elif allow_origin == origin_header:
            status, detail, severity = 'INFO', 'The controlled Origin was allowed without credential permission being observed.', 'INFO'
        elif allow_origin:
            status, detail, severity = 'INFO', f'The server returned a different Access-Control-Allow-Origin value: {allow_origin[:180]}.', 'INFO'
        else:
            status, detail, severity = 'INFO', 'No Access-Control-Allow-Origin header was observed for this controlled Origin.', 'INFO'
        _config_add_check(data['checks'], 'CORS controlled-origin GET', status, detail, evidence=allow_origin or 'Header absent', severity=severity)
        try:
            options = fetch(url, timeout=timeout, method='OPTIONS', headers={'Origin': origin_header, 'Access-Control-Request-Method': 'GET', 'Access-Control-Request-Headers': 'authorization,content-type'}, max_body=16_000)
            oh = {k.lower(): str(v) for k, v in options['raw_headers'].items()}
            acao = oh.get('access-control-allow-origin', '')
            _config_add_check(data['checks'], 'CORS preflight', 'WARN' if acao == '*' and oh.get('access-control-allow-credentials', '').lower() == 'true' else 'INFO',
                              f'OPTIONS returned HTTP {options["status_code"]}; allow-origin={acao or "not observed"}; allow-methods={oh.get("access-control-allow-methods", "not observed")}.', severity='MEDIUM' if acao == '*' and oh.get('access-control-allow-credentials', '').lower() == 'true' else 'INFO')
        except (ValueError, requests.RequestException) as exc:
            _config_add_check(data['checks'], 'CORS preflight', 'INFO', f'OPTIONS did not complete: {str(exc)[:200]}')
        data['summary'] = 'CORS headers were tested with a controlled, non-credentialed Origin request.'

    if command in {'method-config', 'full-report'}:
        allowed = {}
        for method in ('HEAD', 'OPTIONS'):
            try:
                r = fetch(url, timeout=timeout, method=method, max_body=0)
                h = {k.lower(): str(v) for k, v in r['raw_headers'].items()}
                allowed[method] = {'status_code': r['status_code'], 'allow': h.get('allow'), 'access_control_allow_methods': h.get('access-control-allow-methods')}
                _config_add_check(data['checks'], f'{method} method visibility', 'INFO',
                                  f'{method} returned HTTP {r["status_code"]}; Allow={h.get("allow", "not disclosed")}; Access-Control-Allow-Methods={h.get("access-control-allow-methods", "not disclosed")}.'
                                  )
            except (ValueError, requests.RequestException) as exc:
                _config_add_check(data['checks'], f'{method} method visibility', 'INFO', f'{method} could not be completed: {str(exc)[:200]}')
        data['discovery']['method_responses'] = allowed
        data['summary'] = 'Inspected HEAD and OPTIONS only. No state-changing HTTP methods were executed.'

    if command in {'api-docs', 'api-discover', 'full-report'}:
        docs = _config_docs(url, min(timeout, 3), fetch)
        data['discovery']['api_docs'] = docs
        data['endpoints'].extend(docs['endpoints'])
        _config_add_check(data['checks'], 'API documentation discovery', 'PASS' if docs['specifications'] else 'INFO',
                          f'Found {len(docs["specifications"])} parseable API specification(s) exposing {sum(len(x["paths"]) for x in docs["specifications"])} documented route(s); checked {len(docs["attempted"])} standard locations.')
        if command == 'api-docs':
            data['summary'] = 'Searched conventional same-host OpenAPI/Swagger locations; only parseable specifications count as confirmed documentation.'

    if command in {'sitemap-map', 'api-discover', 'full-report'}:
        sitemap = _config_sitemap(url, min(timeout, 3), fetch)
        data['discovery']['sitemap'] = sitemap
        _config_add_check(data['checks'], 'Sitemap discovery', 'INFO',
                          f'Collected {sitemap["page_count"]} same-host URL(s) from accessible sitemap resources. Sitemap entries are page discovery leads, not proof of API endpoints.')
        if command == 'sitemap-map':
            data['summary'] = 'Collected same-host public sitemap URLs and robots sitemap references.'

    if command in {'js-route-map', 'api-discover', 'full-report'}:
        jsroutes = _config_js_routes(url, min(timeout, 3), fetch)
        data['discovery']['javascript'] = jsroutes
        data['endpoints'].extend(jsroutes['routes'])
        _config_add_check(data['checks'], 'JavaScript route discovery', 'PASS' if jsroutes['routes'] else 'INFO',
                          f'Examined {jsroutes["assets_examined"]} same-host JavaScript asset(s); extracted {len(jsroutes["routes"])} candidate API route(s). Strings are discovery leads and may be stale or unused.')
        if command == 'js-route-map':
            data['summary'] = 'Extracted route-like strings from bounded, same-host JavaScript assets without executing scripts.'

    if command in {'api-discover', 'full-report'}:
        candidates = {}
        for endpoint in data['endpoints']:
            candidate_url = endpoint.get('url')
            if candidate_url:
                candidates.setdefault(candidate_url, endpoint)
        for page in (data.get('discovery', {}).get('sitemap', {}).get('pages') or []):
            p = _urlsplit(page)
            if _ROUTE_MARKER.search(p.path):
                candidates.setdefault(_urlunsplit((p.scheme, p.netloc, p.path, '', '')), {'url': _urlunsplit((p.scheme, p.netloc, p.path, '', '')), 'path': p.path, 'discovery_source': 'sitemap route-like URL'})
        for path in _CONFIG_COMMON_PATHS:
            candidate_url = _urljoin(origin, path.lstrip('/'))
            candidates.setdefault(candidate_url, {'url': candidate_url, 'path': path, 'discovery_source': 'bounded common-path list'})
        tested = []
        for candidate_url, meta in list(candidates.items())[:API_CONFIG_MAX_ENDPOINTS]:
            try:
                response = fetch(candidate_url, timeout=2, max_body=16_000)
                status = response['status_code']
                content_type = response.get('content_type', '')
                body = response.get('body', '')
                looks_api = ('json' in content_type.lower() or 'graphql' in content_type.lower() or 'xml' in content_type.lower() or body.lstrip().startswith(('{', '[')))
                tested.append({**meta, 'url': _redact_config_url(candidate_url), 'status_code': status,
                               'content_type': content_type[:160], 'response_time_ms': response['response_time_ms'],
                               'response_bytes_captured': response['body_size_captured'],
                               'looks_like_api_response': bool(looks_api), 'body_truncated': response['body_truncated']})
            except (ValueError, requests.RequestException) as exc:
                tested.append({**meta, 'url': _redact_config_url(candidate_url), 'error': str(exc)[:200]})
        data['endpoints'] = tested
        responding = sum(1 for x in tested if isinstance(x.get('status_code'), int) and x['status_code'] not in {404, 410})
        _config_add_check(data['checks'], 'Candidate endpoint validation', 'INFO',
                          f'Checked {len(tested)} candidate endpoint(s); {responding} returned a status other than 404/410. These are candidates, not confirmed vulnerabilities or necessarily live API routes.')
        data['summary'] = f'Endpoint discovery checked {len(tested)} candidate(s). {responding} responded with statuses other than 404/410; manually verify route semantics and access controls.'

    if command == 'tls-config':
        data['summary'] = 'TLS handshake and certificate observations collected using hostname verification.'
    if command == 'site-config':
        data['summary'] = data.get('summary') or 'Baseline reachability and security header observations collected.'

    # Findings are generated from concrete WARN/FAIL checks; INFO items are not called vulnerabilities.
    for check in data['checks']:
        if check.get('status') in {'WARN', 'FAIL'}:
            data['findings'].append({'title': check['name'], 'severity': check.get('severity', 'LOW' if check['status'] == 'WARN' else 'HIGH'),
                                     'evidence': check.get('evidence') or check['detail'], 'status': check['status'],
                                     'remediation': _config_remediation(check['name'])})
    data['duration_ms'] = round((__import__('time').perf_counter() - started) * 1000, 1)
    return _config_base_result(command, url, data)


def _config_remediation(name):
    normalized = str(name).lower()
    advice = {
        'https': 'Serve the endpoint over HTTPS and redirect HTTP to HTTPS after verifying host and proxy configuration.',
        'hsts': 'For HTTPS websites, set an appropriate Strict-Transport-Security policy after confirming all covered hosts support HTTPS.',
        'content security policy': 'For browser-rendered pages, define a restrictive Content-Security-Policy and test it before enforcing.',
        'mime sniffing protection': 'Set X-Content-Type-Options: nosniff where appropriate.',
        'framing protection': 'Set CSP frame-ancestors and/or X-Frame-Options according to legitimate embedding requirements.',
        'cors': 'Use an explicit trusted-origin allowlist; do not reflect arbitrary Origin headers, and avoid credentials with wildcard origins.',
        'cors controlled-origin get': 'Validate Origin against an explicit allowlist and return credential-related CORS headers only for trusted origins.',
        'certificate expiry': 'Renew certificates before expiry and alert on certificate validity thresholds.',
        'tls validation': 'Install a publicly trusted certificate matching the hostname and ensure supported TLS configuration.',
        'server information disclosure': 'Avoid unnecessarily detailed Server/X-Powered-By headers where feasible.',
        'cache policy': 'For sensitive authenticated responses, set suitable Cache-Control directives such as private or no-store based on application needs.',
    }
    for key, value in advice.items():
        if key in normalized:
            return value
    return 'Review the observed response and verify its security impact, then apply the least disruptive configuration fix consistent with application requirements.'


def _bola_probe(url, method, req_headers, timeout):
    """OWASP API1:2023 Broken Object Level Authorization - swap a numeric ID in the path and compare access."""
    if method not in {'GET', 'HEAD'}:
        return [{'name': 'BOLA / IDOR probe', 'status': 'INFO', 'detail': 'Skipped: only run for idempotent GET/HEAD requests to avoid side effects on a live system.'}]
    try:
        p = urlparse(url)
        matches = list(re.finditer(r'\d+', p.path))
        if not matches:
            return [{'name': 'BOLA / IDOR probe', 'status': 'INFO', 'detail': 'Skipped: no numeric resource ID was found in the URL path to substitute.'}]
        seg = matches[-1]
        alt_id = str(int(seg.group()) + 1)
        alt_path = p.path[:seg.start()] + alt_id + p.path[seg.end():]
        alt_url = p._replace(path=alt_path).geturl()
        _validate_remote_url(alt_url)
        r2 = requests.request(method, alt_url, headers=req_headers, timeout=max(3, min(int(timeout), 20)))
        if r2.status_code == 200:
            return [{'name': 'BOLA / IDOR probe', 'status': 'WARN', 'detail': f'Changing the resource ID in the path ({seg.group()} -> {alt_id}) still returned HTTP 200. Confirm object-level authorization is enforced for this resource.'}]
        if r2.status_code in (401, 403, 404):
            return [{'name': 'BOLA / IDOR probe', 'status': 'PASS', 'detail': f'Changing the resource ID returned HTTP {r2.status_code}, consistent with object-level access control being enforced.'}]
        return [{'name': 'BOLA / IDOR probe', 'status': 'INFO', 'detail': f'Modified-ID request returned HTTP {r2.status_code}; review manually.'}]
    except requests.RequestException as exc:
        return [{'name': 'BOLA / IDOR probe', 'status': 'INFO', 'detail': f'Could not complete probe: {exc}'}]
    except Exception as exc:
        return [{'name': 'BOLA / IDOR probe', 'status': 'INFO', 'detail': f'Probe skipped: {exc}'}]


def _broken_auth_probe(url, method, req_headers, timeout):
    """OWASP API2:2023 Broken Authentication - resend the same request with credentials stripped."""
    cred_keys = [k for k in req_headers if k.lower() in {'authorization', 'x-api-key', 'api-key'}]
    if not cred_keys:
        return [{'name': 'Broken authentication probe', 'status': 'INFO', 'detail': 'No credential header was supplied, so an auth-bypass comparison could not be run. Supply a test credential to enable this probe.'}]
    try:
        stripped = {k: v for k, v in req_headers.items() if k.lower() not in {'authorization', 'x-api-key', 'api-key'}}
        r2 = requests.request(method, url, headers=stripped, timeout=max(3, min(int(timeout), 20)))
        if 200 <= r2.status_code < 300:
            return [{'name': 'Broken authentication probe', 'status': 'FAIL', 'detail': f'The same request without any credential still returned HTTP {r2.status_code}. The endpoint may not be enforcing authentication.'}]
        if r2.status_code in (401, 403):
            return [{'name': 'Broken authentication probe', 'status': 'PASS', 'detail': f'The request without a credential was correctly rejected with HTTP {r2.status_code}.'}]
        return [{'name': 'Broken authentication probe', 'status': 'INFO', 'detail': f'Unauthenticated request returned HTTP {r2.status_code}; review manually.'}]
    except requests.RequestException as exc:
        return [{'name': 'Broken authentication probe', 'status': 'INFO', 'detail': f'Could not complete probe: {exc}'}]


def _rate_limit_probe(url, method, req_headers, timeout, burst=6):
    """OWASP API4:2023 Unrestricted Resource Consumption - fire a short burst and look for HTTP 429."""
    if method not in {'GET', 'HEAD'}:
        return [{'name': 'Rate-limit burst probe', 'status': 'INFO', 'detail': 'Skipped burst probe for a non-idempotent method to avoid side effects on a live system. Test rate limiting for write endpoints against a staging environment.'}]
    codes = []
    try:
        for _ in range(burst):
            rr = requests.request(method, url, headers=req_headers, timeout=max(3, min(int(timeout), 10)))
            codes.append(rr.status_code)
            if rr.status_code == 429:
                break
        if 429 in codes:
            return [{'name': 'Rate-limit burst probe', 'status': 'PASS', 'detail': f'HTTP 429 was observed after {codes.index(429) + 1} of {len(codes)} rapid requests.'}]
        return [{'name': 'Rate-limit burst probe', 'status': 'WARN', 'detail': f'{len(codes)} rapid requests all returned {sorted(set(codes))} with no HTTP 429 in this short burst. No rate limiting was observed; verify gateway-level throttling.'}]
    except requests.RequestException as exc:
        return [{'name': 'Rate-limit burst probe', 'status': 'INFO', 'detail': f'Could not complete burst probe: {exc}'}]


def _mass_assignment_probe(url, method, req_headers, body, timeout):
    """OWASP API3:2023 Broken Object Property Level Authorization - add privileged fields and see if they stick."""
    if method not in {'POST', 'PUT', 'PATCH'} or not isinstance(body, dict):
        return [{'name': 'Mass-assignment probe', 'status': 'INFO', 'detail': 'Skipped: requires a POST/PUT/PATCH request with a JSON object body. This probe re-sends your request once with extra fields added, so only enable it against endpoints you are safe to write to.'}]
    try:
        probe_body = dict(body)
        for k in ('role', 'isAdmin', 'is_admin'):
            probe_body.setdefault(k, 'admin' if k == 'role' else True)
        rr = requests.request(method, url, headers=req_headers, json=probe_body, timeout=max(3, min(int(timeout), 20)))
        text = (rr.text or '').lower()
        reflected = ('isadmin' in text or 'is_admin' in text) and 'true' in text
        if reflected:
            return [{'name': 'Mass-assignment probe', 'status': 'WARN', 'detail': 'Extra privileged fields (role / isAdmin) added to the request body appear to be echoed back or accepted. Confirm the server explicitly allow-lists writable fields.'}]
        return [{'name': 'Mass-assignment probe', 'status': 'PASS' if rr.status_code < 400 else 'INFO', 'detail': f'Extra privileged fields were sent; the response (HTTP {rr.status_code}) did not echo them back. Still verify server-side allow-listing in code.'}]
    except requests.RequestException as exc:
        return [{'name': 'Mass-assignment probe', 'status': 'INFO', 'detail': f'Could not complete probe: {exc}'}]


def _injection_probe(url, method, req_headers, timeout):
    """OWASP API8:2023 Security Misconfiguration / injection smoke test using safe, non-destructive payloads."""
    if method not in {'GET', 'HEAD'}:
        return [{'name': 'Injection probe', 'status': 'INFO', 'detail': 'Skipped for a non-idempotent method to avoid side effects.'}]
    probes = ["' OR '1'='1", "<script>alert(1)</script>", "../../etc/passwd"]
    findings = []
    try:
        p = urlparse(url)
        sep = '&' if p.query else '?'
        for probe in probes:
            test_url = url + sep + 'apistat_probe=' + requests.utils.quote(probe, safe='')
            rr = requests.request(method, test_url, headers=req_headers, timeout=max(3, min(int(timeout), 10)))
            text = rr.text or ''
            if rr.status_code >= 500:
                findings.append(f'payload triggered HTTP 500 ({probe[:20]}...)')
            elif '<script>alert(1)</script>' in text:
                findings.append('payload reflected unescaped in the response (possible XSS)')
        if findings:
            return [{'name': 'Injection probe', 'status': 'WARN', 'detail': '; '.join(findings)[:400]}]
        return [{'name': 'Injection probe', 'status': 'PASS', 'detail': 'Basic SQLi/XSS/path-traversal probe strings appended as a query parameter produced no server errors or unescaped reflection.'}]
    except requests.RequestException as exc:
        return [{'name': 'Injection probe', 'status': 'INFO', 'detail': f'Could not complete probe: {exc}'}]


def run_deep_scan_battery(url, method, req_headers, body, timeout):
    """OWASP API Security Top 10 (2023) style probe battery for the live API tester."""
    checks = []
    checks += _bola_probe(url, method, req_headers, timeout)
    checks += _broken_auth_probe(url, method, req_headers, timeout)
    checks += _rate_limit_probe(url, method, req_headers, timeout)
    checks += _mass_assignment_probe(url, method, req_headers, body, timeout)
    checks += _injection_probe(url, method, req_headers, timeout)
    return checks


def live_api_test(url, method='GET', headers=None, body=None, timeout=15, attempts=3, deep_scan=False):
    _validate_remote_url(url)
    method=(method or 'GET').upper().strip(); allowed={'GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'}
    if method not in allowed: raise ValueError(f'Method must be one of: {", ".join(sorted(allowed))}.')
    headers={} if headers is None else headers
    if not isinstance(headers,dict): raise ValueError('headers must be a JSON object.')
    if body is not None and not isinstance(body,(str,dict,list)): raise ValueError('body must be text, JSON object, JSON array, or null.')
    req_headers={'User-Agent':'API-STAT-Live-Test/3.2','Accept':'application/json, text/plain, */*'}; req_headers.update({str(k):str(v) for k,v in headers.items()})
    kwargs={'headers':req_headers,'timeout':max(3,min(int(timeout),30)),'allow_redirects':True}
    if body is not None and method not in {'GET','HEAD','OPTIONS'}:
        if isinstance(body,(dict,list)): kwargs['json']=body; req_headers.setdefault('Content-Type','application/json')
        else: kwargs['data']=body
    max_attempts=max(1,min(int(attempts),3)); last_error=None
    for attempt in range(1,max_attempts+1):
        started=__import__('time').perf_counter()
        try:
            r=requests.request(method,url,**kwargs); elapsed=round((__import__('time').perf_counter()-started)*1000,1); break
        except requests.RequestException as exc:
            last_error=str(exc); elapsed=round((__import__('time').perf_counter()-started)*1000,1)
            if attempt>=max_attempts:
                return {'completed':True,'ok':False,'reachable':False,'test_status':'NO_RESPONSE','url':url,'method':method,'attempts':attempt,'response_time_ms':elapsed,'error':last_error,'checks':[{'name':'Connectivity','status':'WARN','detail':'No HTTP response was obtained after retries.'}], 'diagnostics':['Check DNS, TLS, firewall, VPN, IP allowlisting and endpoint availability from the deployed server.'],'remediation':['Verify the API is reachable from the deployment environment.','Confirm DNS and TLS certificate validity.','Check network firewall and IP allowlisting.']}
    response_headers=dict(r.headers); response_lower={k.lower():v for k,v in response_headers.items()}
    checks=[{'name':'Reachability','status':'PASS','detail':f'HTTP {r.status_code} received on attempt {attempt} in {elapsed} ms.'}]
    checks += _api_headers_checks({**response_headers,'_effective_https':'true' if r.url.lower().startswith('https://') else 'false'})
    if r.status_code in (401,403): auth_status='PASS'; auth_detail=f'HTTP {r.status_code} denied the supplied request, providing an authentication/authorization signal.'
    elif 200<=r.status_code<300: auth_status='INFO'; auth_detail='Request succeeded. Verify that this success is expected for the supplied credentials and endpoint.'
    else: auth_status='INFO'; auth_detail=f'HTTP {r.status_code} was returned; authorization posture needs endpoint-specific review.'
    checks.append({'name':'Authentication / authorization signal','status':auth_status,'detail':auth_detail})
    checks.append({'name':'Rate limiting','status':'PASS' if r.status_code==429 else 'INFO','detail':'Endpoint returned HTTP 429.' if r.status_code==429 else 'A single live request cannot prove rate limiting; verify gateway policy or use a controlled load test.'})
    deep_checks=[]
    if deep_scan:
        try:
            deep_checks=run_deep_scan_battery(url,method,req_headers,body,timeout)
        except Exception as exc:
            deep_checks=[{'name':'Deep scan battery','status':'INFO','detail':f'Deep scan probes could not complete: {exc}'}]
        checks=checks+deep_checks
    ctype=response_headers.get('Content-Type',''); body_text=r.text or ''; preview=redact_sensitive_text(body_text[:6000])
    score=10.0; score-=2.5 if not r.url.lower().startswith('https://') else 0; score-=1.2 if 'strict-transport-security' not in response_lower else 0; score-=0.8 if 'x-content-type-options' not in response_lower else 0; score-=1.5 if response_lower.get('access-control-allow-origin')=='*' else 0
    for c in deep_checks:
        if c.get('status')=='FAIL': score-=2.0
        elif c.get('status')=='WARN': score-=1.0
    score=max(0,min(10,score))
    return {'completed':True,'ok':True,'reachable':True,'test_status':'COMPLETE','url':url,'effective_url':r.url,'method':method,'attempts':attempt,'status_code':r.status_code,'response_time_ms':elapsed,'security_score':round(score,1),'deep_scan':bool(deep_scan),'request':{'method':method,'headers':{k:('[REDACTED]' if k.lower() in {'authorization','x-api-key','api-key','cookie','set-cookie'} else v) for k,v in req_headers.items()},'body_sent':body is not None},'response':{'headers':response_headers,'content_type':ctype,'is_json':'json' in ctype.lower(),'body_preview':preview,'body_size':len(body_text.encode('utf-8',errors='ignore'))},'checks':checks}

