"""Small, dependency-free sparse-vector engine (TF-IDF + cosine similarity).

API-STAT uses it in two places:

* **Capability routing** - every agent capability owns a keyword vector; the
  user's message (plus any attached report) is vectorised into the same space
  and compared with cosine similarity to decide which capabilities to run.
* **RAG retrieval** - the security knowledge base and policy documents are
  indexed here, so answers are grounded in the closest matching passages.

It is intentionally lexical (sparse) rather than neural: it is deterministic,
explainable (every hit reports the terms that produced the score), needs no
model download and runs in microseconds on a corpus of this size.
"""
from __future__ import annotations

import math
import re
import threading
from collections import Counter
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional, Tuple

_STOP = frozenset(
    """a an and are as at be but by can could do does for from had has have how i if in into is it its
    me my of on or our should so than that the their them then there these they this to us was we were
    what when where which who whom why will with would you your about also just like need want please
    tell give show let get make use using used can't cannot mean means meaning""".split()
)

# Analyst shorthand -> canonical vocabulary so "IDOR" finds BOLA content, etc.
SYNONYMS: Dict[str, str] = {
    "idor": "bola",
    "authn": "authentication",
    "authz": "authorization",
    "authenticate": "authentication",
    "authorise": "authorization",
    "authorisation": "authorization",
    "oauth2": "oauth",
    "oidc": "openid",
    "pentest": "penetration",
    "pentesting": "penetration",
    "vuln": "vulnerability",
    "vulns": "vulnerability",
    "sqli": "sql_injection",
    "xss": "cross_site_scripting",
    "csrf": "cross_site_request_forgery",
    "ssrf": "server_side_request_forgery",
    "rce": "remote_code_execution",
    "dos": "denial_service",
    "ddos": "denial_service",
    "throttle": "rate_limit",
    "throttling": "rate_limit",
    "ratelimit": "rate_limit",
    "swagger": "openapi",
    "attribute": "property",
    "attributes": "property",
    "field": "property",
    "fields": "property",
    "route": "endpoint",
    "routes": "endpoint",
    "uri": "endpoint",
    "url": "endpoint",
    "verb": "method",
    "verbs": "method",
    "creds": "credential",
    "pwd": "password",
    "passwd": "password",
    "mfa": "multi_factor",
    "2fa": "multi_factor",
    "pii": "personal_data",
    "gql": "graphql",
    "rbac": "role_based_access",
    "abac": "attribute_based_access",
}

_TOKEN_RE = re.compile(
    r"cve-\d{4}-\d{4,7}|cwe-\d{1,5}|api(?:10|[1-9])(?::2023)?|[a-z][a-z0-9]*|\d+",
    re.I,
)

_SUFFIXES: Tuple[Tuple[str, str], ...] = (
    ("ization", "ize"),
    ("isation", "ize"),
    ("ations", "ate"),
    ("ation", "ate"),
    ("ities", "ity"),
    ("ness", ""),
    ("ings", ""),
    ("ing", ""),
    ("ied", "y"),
    ("ies", "y"),
    ("sses", "ss"),
    ("ed", ""),
    ("es", ""),
    ("s", ""),
)


def stem(word: str) -> str:
    """Very light stemmer - applied identically to documents and queries."""
    if len(word) <= 3 or any(ch.isdigit() for ch in word) or "_" in word:
        return word
    if word.endswith(("ss", "us", "is")):
        return word
    for suf, rep in _SUFFIXES:
        if word.endswith(suf) and len(word) - len(suf) >= 3:
            word = word[: -len(suf)] + rep
            break
    if word.endswith("e") and len(word) > 4:
        word = word[:-1]
    return word


def tokenize(text: str, with_bigrams: bool = True) -> Tuple[List[str], Dict[str, str]]:
    """Return (terms, surface_map). ``surface_map`` maps a stemmed term back to a readable word."""
    raw = [t.lower() for t in _TOKEN_RE.findall(text or "")]
    unigrams: List[str] = []
    surface: Dict[str, str] = {}
    for tok in raw:
        if tok in _STOP or (len(tok) < 2 and not tok.isdigit()):
            continue
        if tok.isdigit() and len(tok) < 3:
            continue
        canon = SYNONYMS.get(tok, tok)
        st = stem(canon)
        unigrams.append(st)
        surface.setdefault(st, tok if canon == tok else canon.replace("_", " "))
    terms = list(unigrams)
    if with_bigrams:
        for a, b in zip(unigrams, unigrams[1:]):
            if a != b:
                bg = f"{a}_{b}"
                terms.append(bg)
                surface.setdefault(bg, f"{surface.get(a, a)} {surface.get(b, b)}")
    return terms, surface


def cosine(a: Dict[str, float], b: Dict[str, float]) -> float:
    if len(a) > len(b):
        a, b = b, a
    return sum(w * b.get(t, 0.0) for t, w in a.items())


def _normalise(vec: Dict[str, float]) -> Dict[str, float]:
    norm = math.sqrt(sum(v * v for v in vec.values()))
    return {k: v / norm for k, v in vec.items()} if norm else {}


@dataclass
class Hit:
    id: str
    score: float
    payload: dict
    matched: List[str] = field(default_factory=list)


class TfidfIndex:
    """TF-IDF index over documents made of weighted fields."""

    def __init__(self, field_weights: Optional[Dict[str, float]] = None):
        self.field_weights = field_weights or {"keywords": 3.0, "title": 2.0, "body": 1.0}
        self._docs: List[Tuple[str, Dict[str, str], dict]] = []
        self._vectors: Dict[str, Dict[str, float]] = {}
        self._idf: Dict[str, float] = {}
        self._payloads: Dict[str, dict] = {}
        self._built = False
        self._lock = threading.Lock()

    # -- building -----------------------------------------------------
    def add(self, doc_id: str, fields: Dict[str, str], payload: Optional[dict] = None) -> None:
        self._docs.append((doc_id, fields, payload or {}))
        self._built = False

    def build(self) -> "TfidfIndex":
        with self._lock:
            counts: Dict[str, Counter] = {}
            df: Counter = Counter()
            for doc_id, fields, payload in self._docs:
                c: Counter = Counter()
                for fname, text in fields.items():
                    weight = self.field_weights.get(fname, 1.0)
                    terms, _ = tokenize(text)
                    for t in terms:
                        c[t] += weight
                counts[doc_id] = c
                df.update(c.keys())
                self._payloads[doc_id] = payload
            n = max(1, len(self._docs))
            self._idf = {t: math.log((1 + n) / (1 + d)) + 1.0 for t, d in df.items()}
            self._vectors = {
                doc_id: _normalise({t: (1 + math.log(f)) * self._idf[t] for t, f in c.items() if f > 0})
                for doc_id, c in counts.items()
            }
            self._built = True
        return self

    # -- querying -----------------------------------------------------
    def vectorize(self, text: str, damp: Optional[Dict[str, float]] = None) -> Tuple[Dict[str, float], Dict[str, str]]:
        if not self._built:
            self.build()
        terms, surface = tokenize(text)
        c = Counter(terms)
        default_idf = math.log(1 + len(self._docs)) + 1.0
        vec = {t: (1 + math.log(f)) * self._idf.get(t, default_idf * 0.5) for t, f in c.items()}
        # Terms the corpus has never seen cannot match anything; drop them so they don't dilute the norm.
        vec = {t: w for t, w in vec.items() if t in self._idf}
        if damp:
            vec = {t: w * damp.get(t, 1.0) for t, w in vec.items()}
        return _normalise(vec), surface

    def query(
        self,
        text: str,
        k: int = 5,
        min_score: float = 0.0,
        accept: Optional[Callable[[dict], bool]] = None,
        damp: Optional[Dict[str, float]] = None,
    ) -> List[Hit]:
        qvec, surface = self.vectorize(text, damp)
        if not qvec:
            return []
        hits: List[Hit] = []
        for doc_id, dvec in self._vectors.items():
            payload = self._payloads.get(doc_id, {})
            if accept and not accept(payload):
                continue
            score = cosine(qvec, dvec)
            if score <= 0 or score < min_score:
                continue
            contrib = sorted(
                ((qvec[t] * dvec[t], t) for t in qvec if t in dvec), reverse=True
            )
            matched: List[str] = []
            for _, t in contrib:
                label = surface.get(t, t.replace("_", " "))
                if label not in matched:
                    matched.append(label)
                if len(matched) >= 6:
                    break
            hits.append(Hit(doc_id, round(score, 4), payload, matched))
        hits.sort(key=lambda h: h.score, reverse=True)
        return hits[:k]

    def __len__(self) -> int:
        return len(self._docs)


def top_terms(text: str, index: Optional[TfidfIndex] = None, n: int = 10) -> List[Tuple[str, float]]:
    """Highest-weighted unigram terms of ``text`` (used to show the query vector in the UI)."""
    if index is not None:
        vec, surface = index.vectorize(text)
    else:
        terms, surface = tokenize(text)
        c = Counter(terms)
        vec = _normalise({t: 1 + math.log(f) for t, f in c.items()})
    ranked = sorted(((w, t) for t, w in vec.items() if "_" not in t), reverse=True)
    out: List[Tuple[str, float]] = []
    for w, t in ranked:
        out.append((surface.get(t, t), round(w, 3)))
        if len(out) >= n:
            break
    return out
