import json, os, re

CATEGORIES=['Cryptographic Failure','Broken Authentication','Security Misconfiguration','Design Flaw']


def _json_from_text(text):
    text=(text or '').strip().replace('```json','').replace('```','').strip()
    try: return json.loads(text)
    except Exception:
        m=re.search(r'\{.*\}',text,re.S)
        if m:
            try:return json.loads(m.group(0))
            except Exception:pass
    return None

def provider_name():
    if os.getenv('OPENAI_API_KEY'): return 'openai'
    if os.getenv('GEMINI_API_KEY'): return 'gemini'
    if os.getenv('OLLAMA_BASE_URL'): return 'ollama'
    return 'heuristic'

def model_name():
    return {
        'openai':os.getenv('OPENAI_MODEL','gpt-4.1-mini'),
        'gemini':os.getenv('GEMINI_MODEL','gemini-2.5-flash'),
        'ollama':os.getenv('OLLAMA_MODEL','llama3.2'),
        'heuristic':'local-heuristic-fallback'
    }[provider_name()]

def call_llm(prompt,system='You are a senior application security engineer. Return strict JSON only.',temperature=0.1):
    p=provider_name()
    if p=='openai':
        from openai import OpenAI
        client=OpenAI(api_key=os.environ['OPENAI_API_KEY'])
        r=client.chat.completions.create(model=os.getenv('OPENAI_MODEL','gpt-4.1-mini'),temperature=temperature,response_format={'type':'json_object'},messages=[{'role':'system','content':system},{'role':'user','content':prompt}])
        return _json_from_text(r.choices[0].message.content) or {}
    if p=='gemini':
        import google.generativeai as genai
        genai.configure(api_key=os.environ['GEMINI_API_KEY'])
        model=genai.GenerativeModel(os.getenv('GEMINI_MODEL','gemini-2.5-flash'),system_instruction=system)
        r=model.generate_content(prompt)
        return _json_from_text(getattr(r,'text','')) or {}
    if p=='ollama':
        import requests
        base=os.getenv('OLLAMA_BASE_URL','http://localhost:11434/api/generate')
        if base.endswith('/'): base=base[:-1]
        if not base.endswith('/api/generate'): base+='/api/generate'
        r=requests.post(base,json={'model':os.getenv('OLLAMA_MODEL','llama3.2'),'prompt':system+'\n'+prompt,'stream':False,'format':'json'},timeout=90)
        r.raise_for_status(); return _json_from_text(r.json().get('response','')) or {}
    return {}

def _heuristic_category(f):
    s=' '.join(str(f.get(k) or '') for k in ('rule_id','raw_message','summary','details','title')).lower()
    if any(x in s for x in ('md5','sha1','sha-1','des','rc4','weak crypto','hardcoded secret','secret','private key')): return 'Cryptographic Failure'
    if any(x in s for x in ('auth','jwt','session','login','permission','identity','access control')): return 'Broken Authentication'
    if any(x in s for x in ('debug','cors','tls','certificate','header','default config','verify=false','misconfiguration','configuration')): return 'Security Misconfiguration'
    return 'Design Flaw'

def enrich_findings_batch(findings):
    if not findings: return 0
    if provider_name()=='heuristic':
        for f in findings:
            f['category']=_heuristic_category(f)
            f['ai_relevance_confidence']=0.75
            f['ai_justification']='Heuristic fallback classified the finding from its evidence and security semantics; configure an LLM for context-aware categorization.'
            f['ai_explanation']=f.get('raw_message') or f.get('summary') or 'Security issue detected by automated analysis.'
            f['ai_fix_steps']=json.dumps(['Validate the finding in its execution context.','Apply the least-privilege or secure-configuration fix appropriate to the code path.'])
            f['title']=f.get('title') or f.get('rule_id') or f.get('cve_id') or 'Security finding'
        return 0
    payload=[]
    for i,f in enumerate(findings):
        payload.append({'index':i,'rule_id':f.get('rule_id'),'cve_id':f.get('cve_id'),'message':f.get('raw_message') or f.get('summary'),'details':f.get('details'),'file':f.get('file_path'),'line':f.get('line_number'),'snippet':(f.get('code_snippet') or '')[:1200],'dependency_context':f.get('dependency_context')})
    prompt='''Classify each security finding into EXACTLY one of these categories: Cryptographic Failure, Broken Authentication, Security Misconfiguration, Design Flaw. Use the supplied code/evidence, not a memorized rule-to-category table. For CVEs, classify according to what the vulnerability actually impacts. Return JSON: {"findings":[{"index":0,"category":"...","confidence":0.0,"justification":"one sentence","title":"short title","explanation":"plain-English explanation","remediation_steps":["..."],"fix_snippet":"optional secure code example"}]}. Do not invent details.''' + '\nFINDINGS:\n' + json.dumps(payload)[:18000]
    try: out=call_llm(prompt,system='You are an AppSec triage engine. Category must be one of the four exact values. Confidence is 0..1.')
    except Exception: out={}
    rows=out.get('findings',[]) if isinstance(out,dict) else []
    by_index={int(r.get('index')):r for r in rows if str(r.get('index','')).isdigit()}
    for i,f in enumerate(findings):
        r=by_index.get(i)
        if not r:
            f['category']=_heuristic_category(f); f['ai_relevance_confidence']=0.45
            f['ai_justification']='The model did not return a structured result; fallback classification was used.'
            continue
        f['category']=r.get('category') if r.get('category') in CATEGORIES else _heuristic_category(f)
        try:f['ai_relevance_confidence']=max(0,min(1,float(r.get('confidence',0.5))))
        except Exception:f['ai_relevance_confidence']=0.5
        f['ai_justification']=r.get('justification') or ''
        f['ai_explanation']=r.get('explanation') or f.get('ai_explanation') or f.get('summary')
        f['ai_fix_steps']=json.dumps(r.get('remediation_steps') or [])
        f['ai_fix_snippet']=r.get('fix_snippet') or ''
        f['title']=r.get('title') or f.get('title') or f.get('rule_id') or f.get('cve_id') or 'Security finding'
    return 1

def enrich_cves_batch(findings,code_context):
    if not findings:return 0
    if provider_name()=='heuristic':
        for f in findings:
            impact=str(f.get('summary') or f.get('details') or '').lower()
            if any(x in impact for x in ('cryptograph','cipher','hash','certificate','tls')): f['category']='Cryptographic Failure'
            elif any(x in impact for x in ('auth','privilege','session','permission','access')): f['category']='Broken Authentication'
            elif any(x in impact for x in ('configuration','header','cors','default')): f['category']='Security Misconfiguration'
            else:f['category']='Security Misconfiguration'
            f['ai_relevance_confidence']=0.65 if code_context else 0.45
            f['ai_justification']='Heuristic dependency-context relevance assessment.'
        return 0
    items=[]
    for i,f in enumerate(findings):
        items.append({'index':i,'cve_id':f.get('cve_id'),'dependency':f.get('dependency_context'),'summary':f.get('summary'),'details':f.get('details'),'usage_context':code_context.get((f.get('library') or '').lower(),'')[:1800]})
    prompt='''Assess each dependency vulnerability for relevance to the scanned code. Return JSON {"items":[{"index":0,"relevance":"HIGH|MEDIUM|LOW|NOT_APPLICABLE","confidence":0.0,"reason":"one sentence","category":"one of four exact categories"}]}. Judge whether the vulnerable functionality appears meaningfully used; do not claim NOT_APPLICABLE merely because usage context is incomplete.''' + '\nITEMS:\n'+json.dumps(items)[:18000]
    try:out=call_llm(prompt,system='You are a dependency vulnerability analyst. Be conservative and evidence-driven.')
    except Exception:out={}
    rows=out.get('items',[]) if isinstance(out,dict) else []
    by={int(r.get('index')):r for r in rows if str(r.get('index','')).isdigit()}
    allowed=set(CATEGORIES)
    for i,f in enumerate(findings):
        r=by.get(i)
        if r:
            f['relevance']=r.get('relevance','MEDIUM'); f['ai_relevance_confidence']=max(0,min(1,float(r.get('confidence',0.5)))); f['ai_justification']=r.get('reason','');
            if r.get('category') in allowed:f['category']=r['category']
        else:f['relevance']='MEDIUM'; f['ai_relevance_confidence']=0.5
    return 1

def analyze_design_flaws(endpoints,code_context):
    if not endpoints:return []
    if provider_name()=='heuristic':
        out=[]
        for ep in endpoints:
            src=code_context.get(ep['path'],'')
            secured=bool(re.search(r'auth|authorize|permission|role|owner|current_user|jwt|oauth|session',src,re.I))
            if not secured:
                out.append({'source':'ai_design','tool':'llm','category':'Design Flaw','rule_id':'BOLA/BFLA-AI','endpoint':ep['path'],'http_method':ep['method'],'title':f'Possible broken object/function authorization: {ep["method"]} {ep["path"]}','raw_message':'No convincing ownership/role check was found in the nearby code context.','base_severity':8.0,'ai_relevance_confidence':0.75,'ai_justification':'Endpoint appears to handle an object/function without a visible authorization decision.','ai_explanation':'The endpoint may expose object-level or function-level access without verifying that the caller is allowed to access the target resource or operation.','ai_fix_steps':json.dumps(['Resolve the authenticated principal.','Load the target object server-side.','Check ownership/role/permission before returning or mutating data.'])})
        return out
    prompt='''Review API endpoints for BOLA/BFLA. For each endpoint, determine whether the code verifies that the caller owns the requested object and/or has permission for the function/operation. Return only endpoints with credible evidence of a missing or weak check. JSON {"findings":[{"index":0,"confidence":0.0,"title":"...","explanation":"...","justification":"...","remediation_steps":["..."],"fix_snippet":"..."}]}. Do not flag merely because the route does not show the complete auth middleware.''' + '\nENDPOINTS:\n'+json.dumps(endpoints)[:6000]+'\nCODE CONTEXT:\n'+json.dumps(code_context)[:18000]
    try:out=call_llm(prompt,system='You are a business-logic API security specialist focused on BOLA and BFLA.')
    except Exception:out={}
    rows=out.get('findings',[]) if isinstance(out,dict) else []
    findings=[]
    for r in rows:
        try:i=int(r.get('index'))
        except Exception:continue
        if not (0<=i<len(endpoints)):continue
        ep=endpoints[i]
        findings.append({'source':'ai_design','tool':'llm','category':'Design Flaw','rule_id':'BOLA/BFLA-AI','endpoint':ep['path'],'http_method':ep['method'],'title':r.get('title') or f'Potential authorization flaw: {ep["method"]} {ep["path"]}','raw_message':'AI found insufficient evidence of an ownership or function-level authorization check.','base_severity':8.0,'ai_relevance_confidence':max(0,min(1,float(r.get('confidence',0.5)))),'ai_justification':r.get('justification',''),'ai_explanation':r.get('explanation',''),'ai_fix_steps':json.dumps(r.get('remediation_steps') or []),'ai_fix_snippet':r.get('fix_snippet') or ''})
    return findings

def explain_scan(summary, findings=None, pipeline=None):
    """Build source-scan summary from this run's risk and finding evidence."""
    findings = findings if isinstance(findings, list) else []
    pipeline = pipeline if isinstance(pipeline, list) else []
    ordered = sorted(findings, key=lambda item: float(item.get('finding_score') or item.get('base_severity') or 0), reverse=True)
    compact_findings = []
    for f in ordered[:50]:
        compact_findings.append({
            'title': f.get('title') or f.get('rule_id') or f.get('cve_id') or 'Security finding',
            'category': f.get('category'), 'rule_id': f.get('rule_id'),
            'cve_id': f.get('cve_id'), 'file_path': f.get('file_path'),
            'line_number': f.get('line_number'), 'endpoint': f.get('endpoint'),
            'finding_score': f.get('finding_score'), 'cvss_score': f.get('cvss_score'),
            'exploit_available': bool(f.get('exploit_available')),
            'evidence': str(f.get('ai_explanation') or f.get('raw_message') or '')[:1200],
            'existing_remediation': str(f.get('ai_fix_snippet') or '')[:1200],
            'existing_steps': f.get('ai_fix_steps') or [],
        })

    if provider_name() == 'heuristic':
        count = len(findings)
        critical = sum(1 for f in findings if float(f.get('finding_score') or 0) >= 8)
        high = sum(1 for f in findings if 6 <= float(f.get('finding_score') or 0) < 8)
        priority_actions = []
        for f in ordered[:5]:
            title = f.get('title') or f.get('rule_id') or f.get('cve_id')
            steps = f.get('ai_fix_steps') or []
            if isinstance(steps, str):
                try: steps = json.loads(steps)
                except Exception: steps = [steps]
            action = (steps[0] if isinstance(steps, list) and steps else None) or f.get('ai_fix_snippet') or title
            if action: priority_actions.append(str(action))
        if not priority_actions:
            priority_actions = ['Review the scan scope and confirm which analysis tools completed.', 'Manually validate any high-impact API authentication and authorization paths.']
        detected_categories = {str(f.get('category') or '').lower() for f in findings}
        practices = [
            {'practice': 'Secrets handling', 'status': 'WARN' if any(x in str(f.get('title') or '').lower() for f in findings for x in ('secret', 'password', 'api key', 'token', 'credential')) else 'INFO', 'evidence': 'Status is based on the source findings returned by this scan; no finding is not proof that secrets are absent.', 'remediation': 'Move runtime credentials to a secret manager or environment-backed configuration and rotate any exposed credential.'},
            {'practice': 'Authentication', 'status': 'WARN' if 'broken authentication' in detected_categories else 'INFO', 'evidence': 'See the Authentication findings and endpoint evidence in this report.', 'remediation': 'Enforce authentication consistently on protected API routes.'},
            {'practice': 'Authorization / BOLA-BFLA', 'status': 'WARN' if 'design flaw' in detected_categories else 'INFO', 'evidence': 'API endpoint design analysis produced the finding set recorded for this run.', 'remediation': 'Check object ownership and function/role permissions on every protected operation.'},
            {'practice': 'Input validation', 'status': 'WARN' if any(x in str(f.get('title') or '').lower() for f in findings for x in ('injection', 'input validation', 'command execution')) else 'INFO', 'evidence': 'Review findings associated with user-controlled input and sensitive operations.', 'remediation': 'Validate type, range, length and allowed values before use.'},
            {'practice': 'Cryptography', 'status': 'WARN' if 'cryptographic failure' in detected_categories else 'INFO', 'evidence': 'Status is based on findings classified by the scanner.', 'remediation': 'Use modern cryptographic primitives and keep certificate verification enabled.'},
            {'practice': 'Configuration', 'status': 'WARN' if 'security misconfiguration' in detected_categories else 'INFO', 'evidence': 'Status is based on configuration-related findings returned by the scanner.', 'remediation': 'Disable debug behavior in production and restrict CORS to trusted origins.'},
        ]
        return {
            'executive_summary': f"The source scan recorded {count} finding(s), including {critical} critical and {high} high-scoring item(s). Security score: {summary.get('security_score', 'N/A')}/10; risk score: {summary.get('risk_score', 'N/A')}/10.",
            'priority_actions': list(dict.fromkeys(priority_actions))[:5],
            'overall_assessment': 'Local heuristic mode provides a deterministic, evidence-based baseline. Configure OpenAI, Gemini or Ollama in the environment to enable contextual LLM analysis. Validate automated candidates manually.',
            'secure_api_coding_practices': practices,
            'methodology_notes': f"This report summarizes {count} stored finding(s) and the scan pipeline results. Disabled or incomplete tools limit coverage.",
            'confidence': 0.62,
            'provider': 'heuristic',
        }

    payload = {
        'risk_summary': summary,
        'findings': compact_findings,
        'pipeline': pipeline,
        'instructions': 'Use only the evidence included. Do not invent CVEs, source locations, test results or vulnerabilities. Clearly distinguish tool evidence from hypotheses. Remediation must correspond to the supplied findings. If evidence is insufficient, say so.'
    }
    prompt = "Create a developer-facing API secure-coding report from the actual source scan. Return strict JSON with keys: executive_summary, priority_actions (array, max 5), overall_assessment, secure_api_coding_practices (array of objects {practice,status,evidence,remediation}), authentication_posture, authorization_posture, input_validation_posture, secrets_crypto_posture, security_configuration_posture, methodology_notes, confidence (0-1). Base every conclusion on the supplied findings and pipeline metadata. No confirmed exploit claims without evidence. Use INFO rather than PASS where a control was not tested. DATA: " + json.dumps(payload, default=str)[:24000]
    try:
        out = call_llm(prompt, system='You are a senior application-security lead writing a precise evidence-grounded source-code assessment report.')
        if isinstance(out, dict) and out:
            default_actions = [str(f.get('ai_fix_steps')[0] if isinstance(f.get('ai_fix_steps'), list) and f.get('ai_fix_steps') else (f.get('title') or f.get('rule_id') or f.get('cve_id') or 'Review finding')) for f in ordered[:5]]
            if not isinstance(out.get('priority_actions'), list) or not out.get('priority_actions'):
                out['priority_actions'] = default_actions or ['Review scan coverage and manually validate authentication and authorization controls.']
            if not isinstance(out.get('secure_api_coding_practices'), list):
                out['secure_api_coding_practices'] = []
            out.setdefault('executive_summary', f"The source scan recorded {len(findings)} finding(s). Security score: {summary.get('security_score', 'N/A')}/10; risk score: {summary.get('risk_score', 'N/A')}/10.")
            out.setdefault('overall_assessment', 'AI-assisted interpretation of the available source-scan evidence. Validate findings before remediation.')
            out.setdefault('methodology_notes', f"This report summarizes {len(findings)} finding(s) and the recorded scan pipeline.")
            out.setdefault('confidence', 0.75)
            out['provider'] = provider_name()
            return out
    except Exception:
        pass
    return {
        'executive_summary': f"The scan recorded {len(findings)} finding(s). Security score: {summary.get('security_score', 'N/A')}/10; risk score: {summary.get('risk_score', 'N/A')}/10. LLM analysis could not complete, so review the individual finding evidence.",
        'priority_actions': [str(f.get('title') or f.get('rule_id') or 'Review finding') for f in ordered[:5]],
        'overall_assessment': 'The configured LLM provider did not return a report. The score and findings below are from the local scanner; manually validate all candidates.',
        'secure_api_coding_practices': [], 'methodology_notes': 'LLM analysis was unavailable for this run.',
        'confidence': 0.4, 'provider': 'heuristic-fallback',
    }

def _live_fallback_analysis(result, provider='heuristic'):
    checks = result.get('checks', []) if isinstance(result, dict) else []
    warnings = [c for c in checks if isinstance(c, dict) and str(c.get('status', '')).upper() in {'WARN', 'WARNING', 'FAIL', 'FAILED', 'ERROR'}]
    fixes = {
        'https': 'Serve the endpoint over HTTPS, redirect HTTP to HTTPS, and verify the certificate chain.',
        'hsts': 'Add a Strict-Transport-Security header on HTTPS responses after validating the deployment scope.',
        'content-type': 'Set X-Content-Type-Options: nosniff on relevant responses.',
        'cors': 'Replace wildcard CORS access with an explicit allowlist of trusted origins, methods and headers.',
        'authentication': 'Verify authentication is required for protected operations and check authorization separately for every endpoint.',
        'authorization': 'Enforce object ownership and function/role permissions server-side for protected operations.',
        'rate limit': 'Set request limits at the gateway or service layer and verify them with an approved, controlled test.',
        'cache': 'Apply suitable Cache-Control directives when responses may contain sensitive data.',
        'csp': 'Define an appropriate Content-Security-Policy when the endpoint serves browser-interpreted content.',
    }
    remediation = []
    for check in warnings:
        name = str(check.get('name') or '').lower()
        fix = next((value for key, value in fixes.items() if key in name), None)
        if fix:
            remediation.append(fix)
    if not remediation:
        remediation = ['Validate observed response controls against the endpoint design.', 'Retest after remediation and compare the resulting response evidence.']
    status = 'completed' if result.get('ok') else 'did not receive a response'
    status_code = f" with HTTP {result.get('status_code')}" if result.get('status_code') is not None else ''
    latency = result.get('response_time_ms', 'N/A')
    prefix = 'Local fallback used because the configured model did not return a usable result. ' if provider == 'heuristic-fallback' else ''
    return {
        'executive_summary': f"{prefix}Live API assessment {status}{status_code} in {latency} ms. {len(warnings)} control(s) need attention.",
        'overall_assessment': 'Interpretation is based on the returned HTTP evidence. Control warnings are not proof of exploitability; verify in the API context.',
        'attack_surface_observations': [f"{c.get('name')}: {c.get('detail')}" for c in checks if isinstance(c, dict) and str(c.get('status', '')).upper() == 'INFO'][:8],
        'security_controls': [{'control': c.get('name'), 'status': c.get('status'), 'evidence': c.get('detail'), 'why': c.get('detail')} for c in checks if isinstance(c, dict)],
        'remediation': list(dict.fromkeys(remediation))[:10],
        'confidence': 0.70 if provider == 'heuristic' else 0.45,
        'provider': provider,
    }


def analyze_live_api(result):
    """Interpret a completed live assessment, falling back to result-specific guidance if needed."""
    if provider_name() == 'heuristic':
        return _live_fallback_analysis(result, 'heuristic')
    try:
        prompt = "Analyze this completed live API security test. Return strict JSON with executive_summary, overall_assessment, attack_surface_observations (array), security_controls (array of {control,status,evidence}), remediation (array), confidence (0-1). Do not invent vulnerabilities; distinguish observed evidence from recommendations. A missing header can be a configuration issue, but is not automatically an exploitable vulnerability."
        out = call_llm(prompt + '\nRESULT:\n' + json.dumps(result, default=str)[:18000], system='You are a senior API security engineer reviewing a live HTTP assessment.')
        if isinstance(out, dict) and out:
            fallback = _live_fallback_analysis(result, provider_name())
            out.setdefault('executive_summary', fallback['executive_summary'])
            out.setdefault('overall_assessment', fallback['overall_assessment'])
            if not isinstance(out.get('attack_surface_observations'), list):
                out['attack_surface_observations'] = fallback['attack_surface_observations']
            if not isinstance(out.get('security_controls'), list):
                out['security_controls'] = fallback['security_controls']
            if not isinstance(out.get('remediation'), list) or not out.get('remediation'):
                out['remediation'] = fallback['remediation']
            out.setdefault('confidence', 0.75)
            out['provider'] = provider_name()
            return out
    except Exception:
        pass
    return _live_fallback_analysis(result, 'heuristic-fallback')

def analyze_api_calculator(data):
    """AI interpretation of a parameter-based API risk model."""
    if provider_name()=='heuristic':
        score=float(data.get('risk_score',0)); level='LOW' if score<3.5 else 'MEDIUM' if score<6.5 else 'HIGH' if score<8.5 else 'CRITICAL'
        return {'risk_level':level,'executive_summary':f'Calculated API risk is {score:.1f}/10 based on the supplied exposure, authentication, data sensitivity, transport and control parameters.','priority_controls':data.get('weak_controls',[]),'remediation':['Use strong authentication and least privilege.','Enforce HTTPS and secure headers.','Apply rate limiting and input validation.','Review authorization at every object/function boundary.'],'confidence':0.72}
    prompt="""Interpret the parameter-based API risk calculation. Return strict JSON with risk_level LOW|MEDIUM|HIGH|CRITICAL, executive_summary, priority_controls array, remediation array, confidence 0-1. Explain why the parameters increase or decrease risk. Do not claim a confirmed exploit."""
    try:return call_llm(prompt+'\nINPUT:\n'+json.dumps(data)[:12000],system='You are an API threat modeling specialist.')
    except Exception:return {'risk_level':'MEDIUM','executive_summary':'The calculator completed using the supplied parameters.','priority_controls':data.get('weak_controls',[]),'remediation':['Review authentication, authorization, transport security and rate limiting.'],'confidence':0.45}


def stream_text(prompt, system='You are a senior API security engineer.', temperature=0.2):
    """Yield the model's answer as it is generated (plain text/Markdown, not JSON).

    Raises on provider errors; callers fall back to the local engine. Yields nothing
    when no provider is configured.
    """
    p = provider_name()
    if p == 'openai':
        from openai import OpenAI
        client = OpenAI(api_key=os.environ['OPENAI_API_KEY'], timeout=60)
        stream = client.chat.completions.create(
            model=os.getenv('OPENAI_MODEL', 'gpt-4.1-mini'), temperature=temperature, stream=True,
            messages=[{'role': 'system', 'content': system}, {'role': 'user', 'content': prompt}])
        for chunk in stream:
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    elif p == 'gemini':
        import google.generativeai as genai
        genai.configure(api_key=os.environ['GEMINI_API_KEY'])
        model = genai.GenerativeModel(os.getenv('GEMINI_MODEL', 'gemini-2.5-flash'), system_instruction=system)
        for chunk in model.generate_content(prompt, stream=True):
            try:
                text = chunk.text
            except Exception:
                text = ''
            if text:
                yield text
    elif p == 'ollama':
        import requests
        base = os.getenv('OLLAMA_BASE_URL', 'http://localhost:11434/api/generate').rstrip('/')
        if not base.endswith('/api/generate'):
            base += '/api/generate'
        with requests.post(base, json={'model': os.getenv('OLLAMA_MODEL', 'llama3.2'), 'prompt': system + '\n\n' + prompt, 'stream': True},
                           stream=True, timeout=90) as r:
            r.raise_for_status()
            for line in r.iter_lines():
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except ValueError:
                    continue
                if obj.get('response'):
                    yield obj['response']
                if obj.get('done'):
                    break
