import os
import threading
import time
import webbrowser

from dotenv import load_dotenv
from flask import Flask, jsonify, redirect, request, send_from_directory
from flask_login import LoginManager

load_dotenv()

from app.models import db, User, PolicyDocument
from app.auth import auth_bp
from app.routes import scan_bp


app = Flask(
    __name__,
    static_folder="frontend/static",
    static_url_path="/static",
)

app.config.update(
    SECRET_KEY=os.getenv("SECRET_KEY", "dev-secret-change-me"),
    MONGODB_URI=os.getenv("MONGODB_URI", "").strip(),
    MONGODB_DB=os.getenv("MONGODB_DB", "apistat").strip() or "apistat",
)

db.init_app(app)

login_manager = LoginManager(app)
login_manager.login_view = None


@login_manager.user_loader
def load_user(user_id):
    try:
        return User.query.get(int(user_id))
    except Exception:
        return None


app.register_blueprint(auth_bp)
app.register_blueprint(scan_bp)


with app.app_context():
    # MongoDB collections are created automatically; this call establishes indexes.
    # When MONGODB_URI is unset the app can still start, but database-backed routes
    # will return a clear configuration error until Atlas is configured in .env.
    db.create_all()


# ----------------------------------------------------------------------
# Frontend routes
# ----------------------------------------------------------------------

FRONTEND_ROUTES = {
    "/": "index.html",
    "/dashboard": "index.html",
    "/calculator": "index.html",
    "/config": "index.html",
    "/tester": "index.html",
    "/developer": "index.html",
    "/chatbot": "index.html",
    "/history": "index.html",
    "/policy": "index.html",
}


for route, filename in FRONTEND_ROUTES.items():
    def make_handler(file_name):
        def handler():
            return send_from_directory("frontend", file_name)
        return handler

    endpoint = "frontend_" + route.strip("/").replace("/", "_")
    if endpoint == "frontend_":
        endpoint = "frontend_home"
    app.add_url_rule(route, endpoint, make_handler(filename), methods=["GET"])


@app.get("/scan/<int:scan_id>")
def scan_detail_page(scan_id):
    return send_from_directory("frontend", "index.html")


@app.errorhandler(RuntimeError)
def handle_runtime_configuration_error(error):
    message = str(error)
    if "MongoDB is not configured" in message:
        return jsonify({
            "error": "MongoDB Atlas is not configured. Set MONGODB_URI in the project's .env file and restart API-STAT.",
            "status": 503,
        }), 503
    return jsonify({"error": "API-STAT could not complete this request.", "status": 500}), 500


@app.errorhandler(500)
def handle_internal_error(error):
    # Never expose Flask's raw traceback to browser users. Return a stable API error or friendly page.
    try:
        db.session.rollback()
    except Exception:
        pass
    accept=request.headers.get('Accept','')
    if request.path.startswith('/api/') or request.path.startswith('/developer/'):
        return jsonify({'error':'API-STAT could not complete this request. No assessment data was lost. Try again or inspect the History & Logs page.','status':500}),500
    if 'text/html' in accept:
        return redirect('/dashboard')
    return jsonify({'error':'Internal server error','status':500}),500

@app.errorhandler(404)
def handle_not_found(error):
    # Never show Flask's ugly Not Found page for browser navigation.
    # Keep API/asset errors as JSON so developer clients still get a real 404.
    accept = request.headers.get("Accept", "")
    path = request.path

    if (
        request.method == "GET"
        and "text/html" in accept
        and not path.startswith("/api/")
        and not path.startswith("/developer/")
        and not path.startswith("/scan/")
        and not path.startswith("/static/")
        and not path.startswith("/health")
    ):
        return redirect("/dashboard")

    if path.startswith("/api/") or path.startswith("/developer/"):
        return jsonify(
            {
                "error": "Endpoint not found",
                "path": path,
                "status": 404,
            }
        ), 404

    return jsonify(
        {
            "error": "Page not found",
            "path": path,
            "status": 404,
        }
    ), 404


# ----------------------------------------------------------------------
# Chrome launcher
# ----------------------------------------------------------------------

def open_chrome():
    time.sleep(1.2)

    port = os.getenv("PORT", "5000")
    url = f"http://127.0.0.1:{port}/dashboard"

    chrome_paths = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(
            r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
        ),
    ]

    for path in chrome_paths:
        if os.path.exists(path):
            try:
                webbrowser.register(
                    "api_stat_chrome",
                    None,
                    webbrowser.BackgroundBrowser(path),
                )
                webbrowser.get("api_stat_chrome").open_new(url)
                return
            except Exception:
                pass

    try:
        webbrowser.open_new(url)
    except Exception:
        pass


if __name__ == "__main__":
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "5000"))
    debug = os.getenv("FLASK_DEBUG", "false").lower() == "true"

    if not debug or os.environ.get("WERKZEUG_RUN_MAIN") == "true":
        threading.Thread(target=open_chrome, daemon=True).start()

    print("=" * 62)
    print("API-STAT")
    print(f"Running: http://127.0.0.1:{port}/dashboard")
    print("Database: MongoDB Atlas (database name: " + os.getenv("MONGODB_DB", "apistat") + ")")
    if not os.getenv("MONGODB_URI", "").strip():
        print("WARNING: Set MONGODB_URI in .env before using login or database features.")
    print("Chrome will open automatically.")
    print("Press CTRL+C to stop.")
    print("=" * 62)

    app.run(
        host=host,
        port=port,
        debug=debug,
        threaded=True,
    )
