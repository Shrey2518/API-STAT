"""One-time importer for legacy API-STAT SQLite records into MongoDB Atlas.

Usage:
    python migrate_sqlite_to_mongodb.py --source instance/apistat.db

The script never deletes or modifies the SQLite source file. It uses replace/upsert
by numeric IDs so it can be safely re-run during a migration rehearsal.
"""
from __future__ import annotations

import argparse
import os
import sqlite3
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from pymongo import ASCENDING, DESCENDING, MongoClient

load_dotenv()

TABLE_TO_COLLECTION = {
    "user": "users",
    "scan": "scans",
    "finding": "findings",
    "action_log": "action_logs",
    "policy_document": "policy_documents",
}
DATETIME_COLUMNS = {"created_at", "completed_at"}


def parse_datetime(value):
    if not value or isinstance(value, datetime):
        return value
    text = str(value).strip()
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        return value


def main():
    parser = argparse.ArgumentParser(description="Migrate the legacy API-STAT SQLite database to MongoDB.")
    parser.add_argument("--source", default="instance/apistat.db", help="Path to the legacy SQLite database")
    parser.add_argument("--dry-run", action="store_true", help="Print record counts without writing to MongoDB")
    args = parser.parse_args()

    source = Path(args.source).expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"SQLite source file not found: {source}")
    uri = os.getenv("MONGODB_URI", "").strip()
    database_name = os.getenv("MONGODB_DB", "apistat").strip() or "apistat"
    if not uri and not args.dry_run:
        raise SystemExit("MONGODB_URI is empty. Add your MongoDB Atlas connection string to .env first.")

    con = sqlite3.connect(str(source))
    con.row_factory = sqlite3.Row
    try:
        available = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        rows_by_table = {}
        for table, collection_name in TABLE_TO_COLLECTION.items():
            if table not in available:
                rows_by_table[table] = []
                continue
            rows_by_table[table] = [dict(row) for row in con.execute(f'SELECT * FROM "{table}"')]
    finally:
        con.close()

    for table, rows in rows_by_table.items():
        print(f"{table:18} -> {TABLE_TO_COLLECTION[table]:24} {len(rows):>6} records")
    if args.dry_run:
        print("Dry run only; no records written.")
        return

    client = MongoClient(uri, serverSelectionTimeoutMS=8000, connectTimeoutMS=8000, appname="API-STAT-Migration")
    database = client[database_name]
    try:
        database.command("ping")
        # Build a scan-to-user map for legacy findings. It ensures user-level access
        # controls remain possible after migration.
        scan_users = {row["id"]: row["user_id"] for row in rows_by_table["scan"] if row.get("id") is not None}
        for table, collection_name in TABLE_TO_COLLECTION.items():
            collection = database[collection_name]
            rows = rows_by_table[table]
            if not rows:
                continue
            operations = []
            for source_row in rows:
                row = dict(source_row)
                row_id = row.pop("id", None)
                if row_id is None:
                    continue
                row_id = int(row_id)
                row["id"] = row_id
                for key in DATETIME_COLUMNS:
                    if key in row:
                        row[key] = parse_datetime(row[key])
                if table == "scan":
                    row.setdefault("scan_type", "source_code")
                elif table == "finding":
                    row["user_id"] = scan_users.get(row.get("scan_id"))
                elif table == "policy_document":
                    row.setdefault("file_storage_reference", row.get("path"))
                    row.setdefault("file_hash", None)
                document = {**row, "_id": row_id}
                operations.append(document)
            for document in operations:
                collection.replace_one({"_id": document["_id"]}, document, upsert=True)
            if operations:
                database["_counters"].update_one(
                    {"_id": collection_name},
                    {"$max": {"sequence": max(item["_id"] for item in operations)}},
                    upsert=True,
                )
            print(f"Imported {len(operations)} records into {collection_name}.")

        # Match the indexes created by the active backend.
        database["users"].create_index([("email", ASCENDING)], unique=True, name="uq_users_email")
        database["scans"].create_index([("user_id", ASCENDING), ("created_at", DESCENDING)], name="ix_scans_user_created")
        database["findings"].create_index([("scan_id", ASCENDING), ("finding_score", DESCENDING)], name="ix_findings_scan_score")
        database["action_logs"].create_index([("user_id", ASCENDING), ("created_at", DESCENDING)], name="ix_logs_user_created")
        database["policy_documents"].create_index([("user_id", ASCENDING), ("created_at", DESCENDING)], name="ix_policy_user_created")
        print(f"Migration completed into database '{database_name}'. SQLite source was left unchanged.")
    finally:
        client.close()


if __name__ == "__main__":
    main()
