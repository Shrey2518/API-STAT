/* API-STAT Security Chatbot UI
 * - "+" attaches reports (PDF, DOCX, JSON, SARIF, HTML, TXT ...) or OpenAPI specs
 * - streams the answer over fetch (POST, SSE framing) and shows the real reasoning pipeline
 * - capability panel is driven by /api/agent/capabilities (keyword vectors live on the server)
 * Depends on globals from app.js: $, esc, state.
 */
const CHAT_STARTERS = [
  "What is BOLA and how do I test for it?",
  "Which properties of an API object are risky to expose?",
  "Explain 401 vs 403 vs 404",
  "What is mass assignment?",
  "What is the difference between an endpoint and an operation?",
];

function chatState() {
  if (!state.chat) {
    let disabled = [];
    try { disabled = JSON.parse(localStorage.getItem("apistat.chat.disabled") || "[]"); } catch { disabled = []; }
    state.chat = { messages: [], history: [], files: [], disabled, busy: false, abort: null, caps: null, lastRoute: null };
  }
  return state.chat;
}

/* ---------- safe Markdown (escape first, then format) ---------- */
function mdToHtml(src) {
  const blocks = [];
  let t = String(src ?? "").replace(/```[\w-]*\n([\s\S]*?)(?:```|$)/g, (_, code) => {
    blocks.push(`<pre class="code-preview chat-code"><code>${esc(code.replace(/\n$/, ""))}</code></pre>`);
    return `\u0000${blocks.length - 1}\u0000`;
  });
  const inline = (s) => esc(s)
    .replace(/`([^`\n]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>")
    .replace(/(^|[\s(])_([^_\n]+)_(?=[\s).,;:]|$)/g, "$1<em>$2</em>");
  const out = [];
  let list = null;
  const closeList = () => { if (list) { out.push(`</${list}>`); list = null; } };
  for (const raw of t.split("\n")) {
    const line = raw.replace(/\s+$/, "");
    let m;
    if (/^\u0000\d+\u0000$/.test(line.trim())) { closeList(); out.push(line.trim()); continue; }
    if ((m = line.match(/^\s*(#{1,4})\s+(.*)$/))) { closeList(); const lv = Math.min(4, m[1].length + 1); out.push(`<h${lv} class="chat-h">${inline(m[2])}</h${lv}>`); continue; }
    if ((m = line.match(/^\s*(?:[-*•])\s+(.*)$/))) { if (list !== "ul") { closeList(); out.push("<ul>"); list = "ul"; } out.push(`<li>${inline(m[1])}</li>`); continue; }
    if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) { if (list !== "ol") { closeList(); out.push("<ol>"); list = "ol"; } out.push(`<li>${inline(m[1])}</li>`); continue; }
    if ((m = line.match(/^>\s?(.*)$/))) { closeList(); out.push(`<blockquote>${inline(m[1])}</blockquote>`); continue; }
    if (!line.trim()) { closeList(); continue; }
    closeList(); out.push(`<p>${inline(line)}</p>`);
  }
  closeList();
  return out.join("").replace(/\u0000(\d+)\u0000/g, (_, i) => blocks[+i]);
}

const fmtBytes = (n) => n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";
const sevChip = (s) => `<span class="sev sev-${String(s || "unrated").toLowerCase()}">${esc(s || "UNRATED")}</span>`;

/* ---------- structured result cards ---------- */
function renderCard(card) {
  if (!card) return "";
  switch (card.type) {
    case "report": return card.reports.map(reportCard).join("");
    case "openapi": return openapiCard(card);
    case "jwt": return card.tokens.map((a, i) => `<div class="rc"><div class="rc-head"><b>JWT #${i + 1}</b><span class="chip">${esc(a.algorithm || "?")}</span><span class="chip">${esc(a.status)}</span></div>${a.issues.length ? `<ul class="rc-list">${a.issues.map((x) => `<li>${sevChip(x.severity)} ${esc(x.title)}</li>`).join("")}</ul>` : '<div class="muted">No obvious weaknesses in the token itself.</div>'}</div>`).join("");
    case "headers": case "probe": return checksCard(card);
    case "cve": return `<div class="rc"><div class="rc-head"><b>CVE lookup</b></div><ul class="rc-list">${card.items.map((c) => `<li><b>${esc(c.id)}</b> ${c.cvss ? sevChip(c.severity) + " CVSS " + esc(c.cvss) : ""} ${c.kev ? '<span class="sev sev-critical">KEV</span>' : ""} <span class="muted">${esc(c.error || (c.summary || "").slice(0, 140))}</span></li>`).join("")}</ul></div>`;
    case "owasp": return `<div class="rc"><div class="rc-head"><b>OWASP API Top 10 match</b></div><div class="chip-row">${card.items.map((i) => `<span class="chip" title="${esc(i.title)}">${esc(i.label)} · ${(i.score * 100).toFixed(0)}%</span>`).join("")}</div></div>`;
    default: return "";
  }
}

function gauge(score, partial) {
  const cls = score >= 75 ? "good" : score >= 50 ? "warn" : "bad";
  return `<div class="gauge" title="Documentation completeness${partial ? " (document-level only)" : ""}"><div class="gauge-bar ${cls}" style="width:${Math.max(3, score)}%"></div><span>${score}/100</span></div>`;
}

function sevCounts(map) {
  return ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"].filter((s) => map[s]).map((s) => `${sevChip(s)}<b class="cnt">${map[s]}</b>`).join(" ") || '<span class="muted">no rated findings</span>';
}

function reportCard(r) {
  const rows = (r.findings || []).slice(0, 12).map((f) => `<tr><td>${esc(f.id)}</td><td>${sevChip(f.severity)}</td><td>${esc(f.title)}</td><td>${f.cvss ?? "–"}</td><td class="mono">${esc((f.endpoints || [])[0] || "")}</td></tr>`).join("");
  const covered = Object.entries(r.owasp_covered || {}).map(([k, v]) => `<span class="chip ok">${esc(k)} ×${v}</span>`).join("");
  const missing = (r.owasp_not_mentioned || []).map((k) => `<span class="chip dim">${esc(k)}</span>`).join("");
  return `<div class="rc">
    <div class="rc-head"><b>${esc(r.name)}</b><span class="muted">${r.total} finding(s)${r.pages ? " · " + r.pages + " pages" : ""}</span></div>
    ${gauge(r.quality.score, r.quality.partial)}
    <div class="rc-row">${sevCounts(r.by_severity)}${r.unrated ? `<span class="muted">${r.unrated} unrated</span>` : ""}</div>
    ${rows ? `<div class="rc-scroll"><table class="rc-table"><thead><tr><th>ID</th><th>Severity</th><th>Title</th><th>CVSS</th><th>Endpoint</th></tr></thead><tbody>${rows}</tbody></table></div>` : ""}
    ${r.issues?.length ? `<details><summary>${r.issues.length} consistency / quality issue(s)</summary><ul class="rc-list">${r.issues.slice(0, 12).map((i) => `<li><b>${esc(i.finding)}</b> ${esc(i.detail)}</li>`).join("")}</ul></details>` : ""}
    <details><summary>Report completeness checks</summary><ul class="rc-list">${r.checks.map((c) => `<li><span class="st st-${c.status.toLowerCase()}">${c.status}</span> ${esc(c.label)}</li>`).join("")}</ul></details>
    ${covered || missing ? `<div class="rc-row"><span class="muted">OWASP coverage</span> ${covered}${missing}</div>` : ""}
    ${r.secrets?.length ? `<div class="rc-warn">Possible live credentials in the report: ${esc(r.secrets.join(", "))}</div>` : ""}
  </div>`;
}

function openapiCard(c) {
  const rows = c.findings.slice(0, 12).map((f) => `<li>${sevChip(f.severity)} <span class="chip">${esc(f.owasp)}</span> ${esc(f.title)} <span class="muted mono">${esc(f.where.slice(0, 48))}</span></li>`).join("");
  const cat = c.catalogue.map((s) => `<tr><td>${esc(s.name)}</td><td>${s.property_count}</td><td>${s.sensitive.length ? esc(s.sensitive.join(", ")) : "–"}</td><td>${s.privileged.length ? esc(s.privileged.join(", ")) : "–"}</td></tr>`).join("");
  const f = c.focus;
  return `<div class="rc">
    <div class="rc-head"><b>${esc(c.title)}</b><span class="muted">${c.operations} operations · ${c.paths} paths · ${c.schemas} objects</span></div>
    <div class="rc-row"><span class="muted">${c.secured}/${c.operations} operations declare authentication</span> ${sevCounts(c.counts)}</div>
    ${f ? `<div class="rc-scroll"><table class="rc-table"><caption>Object <b>${esc(f.name)}</b> - properties</caption><thead><tr><th>Property</th><th>Type</th><th>Flags</th></tr></thead><tbody>${f.properties.slice(0, 25).map((p) => `<tr><td class="mono">${esc(p.name)}</td><td>${esc(p.type)}${p.format ? " (" + esc(p.format) + ")" : ""}</td><td>${[p.readOnly && "read-only", p.writeOnly && "write-only", f.sensitive.includes(p.name) && "sensitive", f.privileged.includes(p.name) && "privileged"].filter(Boolean).map((x) => `<span class="chip ${x === "sensitive" || x === "privileged" ? "warn" : ""}">${x}</span>`).join(" ")}</td></tr>`).join("")}</tbody></table></div>` : ""}
    ${rows ? `<details open><summary>${c.findings.length} review candidate(s)</summary><ul class="rc-list">${rows}</ul></details>` : ""}
    ${cat ? `<details><summary>Object catalogue</summary><div class="rc-scroll"><table class="rc-table"><thead><tr><th>Object</th><th>Props</th><th>Sensitive</th><th>Privileged</th></tr></thead><tbody>${cat}</tbody></table></div></details>` : ""}
  </div>`;
}

function checksCard(c) {
  const list = c.checks.filter((x) => x.status !== "PASS");
  const passed = c.checks.length - list.length;
  return `<div class="rc"><div class="rc-head"><b>${c.type === "probe" ? "Live probe" : "Header review"}</b>${c.url ? `<span class="muted mono">${esc(c.url.slice(0, 60))}</span>` : ""}<span class="muted">${passed} passed</span></div>${c.error ? `<div class="rc-warn">${esc(c.error)}</div>` : `<ul class="rc-list">${list.map((x) => `<li><span class="st st-${x.status.toLowerCase()}">${x.status}</span> <b>${esc(x.name)}</b> ${esc(x.detail)}</li>`).join("") || '<li class="muted">No issues observed.</li>'}</ul>`}</div>`;
}

/* ---------- pipeline & capability panels ---------- */
const STEP_LABELS = { idle: "READY", running: "WORKING", done: "DONE", skipped: "SKIP", error: "ERROR" };

function resetPipeline() {
  document.querySelectorAll("#agent-step-list .agent-step").forEach((el) => { el.className = "agent-step"; el.querySelector("em").textContent = "READY"; el.querySelector("small").dataset.base ??= el.querySelector("small").textContent; el.querySelector("small").textContent = el.querySelector("small").dataset.base; });
  $("pipe-terms").innerHTML = '<span class="muted">Waiting for a question…</span>';
  $("pipe-route").innerHTML = "";
  $("pipe-sources").innerHTML = "";
  document.querySelectorAll(".capability-card").forEach((c) => { c.classList.remove("active", "running"); const b = c.querySelector(".cap-score"); if (b) b.textContent = ""; const r = c.querySelector(".cap-result"); if (r) r.textContent = ""; });
}

function setStage(d) {
  const el = document.querySelector(`#agent-step-list .agent-step[data-stage="${d.id}"]`); if (!el) return;
  el.className = "agent-step " + (d.status === "running" ? "running" : d.status === "done" ? "done" : d.status);
  el.querySelector("em").textContent = d.status === "done" && d.ms >= 1 ? (d.ms >= 1000 ? (d.ms / 1000).toFixed(1) + "s" : Math.round(d.ms) + "ms") : STEP_LABELS[d.status] || d.status.toUpperCase();
  if (d.detail) el.querySelector("small").textContent = d.detail;
}

function showRoute(d) {
  $("pipe-terms").innerHTML = d.terms.length ? d.terms.map((t) => `<span title="weight ${t.weight}">${esc(t.term)}</span>`).join("") : '<span class="muted">no content terms</span>';
  $("pipe-route").innerHTML = d.rows.filter((r) => r.score > 0.04 || r.selected).slice(0, 8).map((r) => `
    <div class="route-row ${r.selected ? "sel" : ""} ${r.disabled ? "off" : ""}">
      <div class="route-top"><span>${esc(r.name)}</span><em>${r.disabled ? "OFF" : r.selected ? "RUN" : ""} ${(r.score * 100).toFixed(0)}%</em></div>
      <div class="route-bar"><i style="width:${Math.min(100, r.score * 100)}%"></i></div>
      <small>${r.reason ? esc(r.reason) : ""}${r.reason && r.matched.length ? " · " : ""}${r.matched.length ? esc(r.matched.slice(0, 3).join(", ")) : ""}</small>
    </div>`).join("");
  d.rows.forEach((r) => {
    const card = document.querySelector(`.capability-card[data-cap="${r.id}"]`); if (!card) return;
    card.classList.toggle("active", r.selected);
    card.querySelector(".cap-score").textContent = r.selected ? (r.score * 100).toFixed(0) + "%" : "";
  });
}

function capCardState(d) {
  const card = document.querySelector(`.capability-card[data-cap="${d.id}"]`); if (!card) return;
  card.classList.toggle("running", d.status === "running");
  if (d.status !== "running") { const s = card.querySelector(".cap-result"); if (s) s.textContent = d.summary ? d.summary.slice(0, 90) : ""; }
}

function renderCapabilityPanel() {
  const cs = chatState(); const box = $("cap-list"); if (!box || !cs.caps) return;
  box.innerHTML = cs.caps.capabilities.map((c) => `
    <div class="capability-card ${cs.disabled.includes(c.id) ? "disabled" : ""}" data-cap="${c.id}">
      <div class="cap-top"><b>${esc(c.name)}</b><span class="cap-score"></span>
        <label class="switch" title="Enable / disable this capability"><input type="checkbox" ${cs.disabled.includes(c.id) ? "" : "checked"} data-toggle="${c.id}"><i></i></label></div>
      <div class="keyword-row">${c.chips.map((k) => `<span>${esc(k)}</span>`).join("")}${c.kind === "network" ? '<span class="net">NETWORK</span>' : ""}</div>
      <small>${esc(c.description)}</small><small class="cap-result"></small>
    </div>`).join("");
  box.querySelectorAll("[data-toggle]").forEach((inp) => inp.addEventListener("change", () => {
    const id = inp.dataset.toggle; const set = new Set(cs.disabled);
    inp.checked ? set.delete(id) : set.add(id);
    cs.disabled = [...set];
    try { localStorage.setItem("apistat.chat.disabled", JSON.stringify(cs.disabled)); } catch { /* storage may be unavailable */ }
    inp.closest(".capability-card").classList.toggle("disabled", !inp.checked);
  }));
}

/* ---------- messages ---------- */
function addMessage(role, html, extraClass = "") {
  const log = $("agent-chat-log");
  const div = document.createElement("div");
  div.className = `chat-msg ${role} ${extraClass}`;
  div.innerHTML = html;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
  return div;
}

function welcomeHtml() {
  return `<b>API-STAT AGENT</b>
  <div class="chat-body"><p>I explain API <strong>objects, properties, functions</strong> and security concepts, and I can reason over evidence you give me:</p>
  <ul><li>Press <b>+</b> to attach a pentest report (PDF, DOCX, JSON, SARIF, HTML, TXT) or an OpenAPI spec</li>
  <li>Paste a JWT, raw response headers or a CVE ID</li><li>Type a URL with "check" to run a light GET/OPTIONS probe</li></ul></div>
  <div class="starter-row">${CHAT_STARTERS.map((q) => `<button type="button" class="starter" data-q="${esc(q)}">${esc(q)}</button>`).join("")}</div>`;
}

function renderAttachmentChips() {
  const cs = chatState(); const box = $("agent-attachments"); if (!box) return;
  box.innerHTML = cs.files.map((f, i) => `<span class="attach-chip ${f.carried ? "carried" : ""}" title="${f.carried ? "Kept for follow-up questions" : "Will be sent with your next message"}">
    <span class="ac-ic">${/\.pdf$/i.test(f.file.name) ? "PDF" : /\.docx$/i.test(f.file.name) ? "DOC" : /\.(json|sarif|ya?ml)$/i.test(f.file.name) ? "{ }" : "TXT"}</span>
    <span class="ac-name">${esc(f.file.name)}</span><small>${fmtBytes(f.file.size)}${f.carried ? " · attached" : ""}</small>
    <button type="button" aria-label="Remove ${esc(f.file.name)}" data-rm="${i}">×</button></span>`).join("");
  box.querySelectorAll("[data-rm]").forEach((b) => b.addEventListener("click", () => { cs.files.splice(+b.dataset.rm, 1); renderAttachmentChips(); }));
}

function chatError(msg) {
  const el = $("chat-error"); if (!el) return;
  el.textContent = msg; el.hidden = !msg;
  if (msg) setTimeout(() => { if (el.textContent === msg) el.hidden = true; }, 6000);
}

function addFiles(list) {
  const cs = chatState(); const caps = cs.caps || { accept: [], max_upload_mb: 10, max_files: 3 };
  for (const file of [...list]) {
    const ext = "." + (file.name.split(".").pop() || "").toLowerCase();
    if (caps.accept.length && !caps.accept.includes(ext)) { chatError(`${file.name}: '${ext}' is not supported (${caps.accept.join(" ")}).`); continue; }
    if (file.size > caps.max_upload_mb * 1048576) { chatError(`${file.name} is larger than ${caps.max_upload_mb} MB.`); continue; }
    if (cs.files.length >= caps.max_files) { chatError(`At most ${caps.max_files} files can be attached.`); break; }
    if (cs.files.some((f) => f.file.name === file.name && f.file.size === file.size)) continue;
    cs.files.push({ file, carried: false });
  }
  renderAttachmentChips();
}

/* ---------- send / stream ---------- */
async function sendChat(text) {
  const cs = chatState(); if (cs.busy) return;
  const msg = (text ?? "").trim();
  if (!msg && !cs.files.some((f) => !f.carried)) return;
  const input = $("agent-chat-input"); input.value = ""; input.style.height = "";
  const sending = cs.files.slice();
  const shown = msg || "Assess the attached report.";

  const userDiv = addMessage("user", `<b>YOU</b><p>${esc(shown)}</p>${sending.length ? `<div class="attach-inline">${sending.map((f) => `<span class="chip">${esc(f.file.name)}</span>`).join("")}</div>` : ""}`);
  const asst = addMessage("assistant", `<b>API-STAT AGENT</b><div class="chat-body"><span class="typing"><i></i><i></i><i></i></span></div><div class="cards"></div><div class="chat-actions"></div><div class="chat-meta">Working…</div>`);
  const body = asst.querySelector(".chat-body"), cardsBox = asst.querySelector(".cards"), meta = asst.querySelector(".chat-meta"), actionsBox = asst.querySelector(".chat-actions");

  resetPipeline();
  cs.busy = true; $("agent-send").textContent = "Stop"; $("agent-send").classList.add("stop"); $("agent-status").textContent = "THINKING";
  const fd = new FormData();
  fd.append("message", msg);
  fd.append("context", JSON.stringify(state.agentContext || {}));
  fd.append("history", JSON.stringify(cs.history.slice(-8)));
  fd.append("disabled", JSON.stringify(cs.disabled));
  fd.append("carried", JSON.stringify(sending.filter((f) => f.carried).map((f) => f.file.name)));
  sending.forEach((f) => fd.append("files", f.file, f.file.name));
  cs.abort = new AbortController();

  let raw = "", provider = "", scheduled = false, done = null;
  const paint = () => { scheduled = false; body.innerHTML = mdToHtml(raw); $("agent-chat-log").scrollTop = $("agent-chat-log").scrollHeight; };
  const cards = [];

  const handle = (event, d) => {
    if (event === "stage") setStage(d);
    else if (event === "route") showRoute(d);
    else if (event === "cap") { capCardState(d); if (d.status === "done" && d.card) cards.push(d.card); }
    else if (event === "sources") $("pipe-sources").innerHTML = d.items.length ? "<h4>RETRIEVED SOURCES</h4>" + d.items.map((s) => `<span class="src ${s.type}">${esc(s.title)}</span>`).join("") : "";
    else if (event === "meta") { provider = d.mode === "llm" ? `${d.provider.toUpperCase()} · ${d.model}` : "LOCAL ENGINE" + (d.fallback ? " (LLM unavailable)" : ""); meta.textContent = provider; }
    else if (event === "token") { raw += d.text; if (!scheduled) { scheduled = true; requestAnimationFrame(paint); } }
    else if (event === "error") { raw += (raw ? "\n\n" : "") + "**Error:** " + d.error; paint(); }
    else if (event === "done") done = d;
  };

  try {
    const resp = await fetch("/api/agent/chat", { method: "POST", body: fd, signal: cs.abort.signal, credentials: "same-origin" });
    if (!resp.ok) {
      let err = `Request failed (${resp.status}).`;
      try { err = (await resp.json()).error || err; } catch { /* non-JSON error body */ }
      throw new Error(err);
    }
    const reader = resp.body.getReader(); const dec = new TextDecoder(); let buf = "";
    for (;;) {
      const { value, done: fin } = await reader.read(); if (fin) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n\n")) >= 0) {
        const block = buf.slice(0, i); buf = buf.slice(i + 2);
        const ev = (block.match(/^event: (.*)$/m) || [])[1], data = (block.match(/^data: (.*)$/m) || [])[1];
        if (ev && data) { try { handle(ev, JSON.parse(data)); } catch { /* ignore a malformed frame */ } }
      }
    }
    paint();
    // carried-over attachments stay available for follow-ups
    sending.forEach((f) => { f.carried = true; });
    renderAttachmentChips();
    if (done) {
      cardsBox.innerHTML = cards.map(renderCard).join("");
      const conf = Math.round((done.grounding || 0) * 100);
      meta.innerHTML = `${esc(provider)} · ${sevChip(done.severity)} · grounding ${conf}% · ${(done.ms / 1000).toFixed(1)}s` +
        (done.policy_refs?.length ? `<div class="refs">Sources: ${done.policy_refs.map(esc).join(" · ")}</div>` : "");
      if (done.actions?.length) actionsBox.innerHTML = `<div class="ah">SUGGESTED NEXT STEPS</div><ul class="agent-action-list">${done.actions.slice(0, 4).map((a) => `<li>${esc(a)}</li>`).join("")}</ul>`;
      if (done.followups?.length) { const fu = document.createElement("div"); fu.className = "starter-row"; fu.innerHTML = done.followups.map((q) => `<button type="button" class="starter" data-q="${esc(q)}">${esc(q)}</button>`).join(""); asst.appendChild(fu); }
    } else if (!raw) { body.innerHTML = "<p>The agent finished without a response.</p>"; meta.textContent = ""; }
    cs.history.push({ role: "user", content: shown }, { role: "assistant", content: raw.slice(0, 1500) });
  } catch (e) {
    if (e.name === "AbortError") { meta.textContent = "Stopped."; if (!raw) body.innerHTML = "<p class='muted'>Stopped.</p>"; }
    else { body.innerHTML = `<p class="rc-warn">${esc(e.message || "Something went wrong.")}</p>`; meta.textContent = ""; sending.forEach((f) => { /* keep files so the user can retry */ }); }
  } finally {
    cs.busy = false; cs.abort = null; $("agent-send").textContent = "Send"; $("agent-send").classList.remove("stop"); $("agent-status").textContent = "READY";
    $("agent-chat-log").scrollTop = $("agent-chat-log").scrollHeight;
  }
}

/* ---------- page ---------- */
function renderChatbot() {
  const cs = chatState();
  const target = $("page-chatbot");
  target.innerHTML = `
    <div class="page-header"><div><div class="page-kicker">05 · AI SECURITY CHATBOT</div><h1 class="page-title">Security Chatbot</h1>
      <p class="page-subtitle">Ask about API objects, properties, functions and controls, or press <b>+</b> to attach a report for assessment. Each question is vectorised, routed to capabilities, grounded in the knowledge base and reasoned over live.</p></div>
      <div class="chatbot-context-badge"><span class="agent-live-dot"></span><span id="chat-provider">…</span></div></div>
    <div class="chatbot-workspace">
      <section class="agent-chat panel chatbot-main" id="chat-dropzone">
        <div class="agent-head"><div><div class="page-kicker">SECURITY COPILOT</div><h2>Evidence-Aware Assistant</h2></div>
          <div class="head-actions"><button type="button" class="btn-ghost" id="chat-clear">Clear</button><span class="agent-status" id="agent-status">READY</span></div></div>
        <div id="agent-chat-log" class="agent-chat-log chatbot-log" role="log" aria-label="Conversation"></div>
        <div id="chat-error" class="chat-error" hidden></div>
        <div id="agent-attachments" class="attach-row"></div>
        <form id="agent-chat-form" class="chat-composer" autocomplete="off">
          <button type="button" class="chat-plus" id="chat-plus" aria-label="Attach a report or OpenAPI spec" title="Attach a report (PDF, DOCX, JSON, SARIF, HTML, TXT) or OpenAPI spec">+</button>
          <input type="file" id="agent-file" multiple hidden>
          <textarea id="agent-chat-input" rows="1" placeholder="Ask about an API object or function…" aria-label="Message"></textarea>
          <button class="btn btn-primary" id="agent-send" type="submit">Send</button>
        </form>
        <div class="drop-hint" id="drop-hint">Drop files to attach</div>
      </section>
      <section class="agent-flow panel chatbot-side">
        <div class="agent-head"><div><div class="page-kicker">AGENT ACTIVITY</div><h2>Reasoning Pipeline</h2></div><span class="agent-live-dot"></span></div>
        <div class="agent-context-strip"><span>TARGET</span><b id="agent-target">${esc(state.agentContext?.target || "No assessment loaded")}</b></div>
        <div class="pipe-block"><h4>QUERY VECTOR (top weighted terms)</h4><div id="pipe-terms" class="keyword-row"><span class="muted">Waiting for a question…</span></div></div>
        <div class="pipe-block"><h4>CAPABILITY ROUTING · cosine similarity + signals</h4><div id="pipe-route"></div></div>
        <div class="agent-step-list" id="agent-step-list">
          ${[["intake", "Evidence intake", "message, history, attachments"], ["vectorize", "Vectorize", "query → keyword vector"], ["route", "Capability routing", "similarity + signals"], ["execute", "Run capabilities", "tools produce evidence"], ["retrieve", "Retrieve (RAG)", "knowledge + policy passages"], ["reason", "Reason", "LLM synthesis or local engine"], ["respond", "Respond", "severity, actions, follow-ups"]]
            .map(([id, t, s], i) => `<div class="agent-step" data-stage="${id}"><span>${String(i + 1).padStart(2, "0")}</span><div><b>${t}</b><small>${s}</small></div><em>READY</em></div>`).join("")}
        </div>
        <div class="pipe-block" id="pipe-sources"></div>
      </section>
      <section class="agent-capabilities panel chatbot-tools">
        <div class="agent-head"><div><div class="page-kicker">CAPABILITIES</div><h2>Security Tools</h2></div></div>
        <div id="cap-list"><div class="muted" style="padding:16px">Loading capabilities…</div></div>
      </section>
    </div>`;

  const log = $("agent-chat-log");
  const restore = () => {
    log.innerHTML = "";
    addMessage("assistant", welcomeHtml());
    cs.messages.forEach((m) => log.appendChild(m));
    log.scrollTop = log.scrollHeight;
  };
  restore();
  // keep the conversation DOM across route changes
  const persist = () => { cs.messages = [...log.children].slice(1); };
  new MutationObserver(persist).observe(log, { childList: true, subtree: false });

  log.addEventListener("click", (e) => { const b = e.target.closest(".starter"); if (b) sendChat(b.dataset.q); });
  const form = $("agent-chat-form"), input = $("agent-chat-input"), fileInput = $("agent-file");
  form.addEventListener("submit", (e) => { e.preventDefault(); if (cs.busy) { cs.abort?.abort(); return; } sendChat(input.value); });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (!cs.busy) sendChat(input.value); } });
  input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 140) + "px"; });
  $("chat-plus").addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", () => { addFiles(fileInput.files); fileInput.value = ""; });
  $("chat-clear").addEventListener("click", () => {
    if (cs.busy) cs.abort?.abort();
    cs.messages = []; cs.history = []; cs.files = []; restore(); renderAttachmentChips(); resetPipeline();
  });
  const dz = $("chat-dropzone"); let depth = 0;
  dz.addEventListener("dragenter", (e) => { if ([...e.dataTransfer.types].includes("Files")) { depth++; dz.classList.add("dragging"); } });
  dz.addEventListener("dragleave", () => { if (--depth <= 0) { depth = 0; dz.classList.remove("dragging"); } });
  dz.addEventListener("dragover", (e) => e.preventDefault());
  dz.addEventListener("drop", (e) => { e.preventDefault(); depth = 0; dz.classList.remove("dragging"); if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files); });

  renderAttachmentChips();
  const loadCaps = cs.caps ? Promise.resolve(cs.caps) : fetch("/api/agent/capabilities", { credentials: "same-origin" }).then((r) => r.json());
  loadCaps.then((c) => {
    cs.caps = c; renderCapabilityPanel();
    fileInput.accept = c.accept.join(",");
    $("chat-provider").textContent = c.provider === "heuristic" ? "LOCAL ENGINE · add an LLM key in .env for richer reasoning" : `${c.provider.toUpperCase()} · ${c.model}`;
  }).catch(() => { $("cap-list").innerHTML = '<div class="muted" style="padding:16px">Could not load capabilities.</div>'; });
}
