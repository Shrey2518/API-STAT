const state = {
  user: null,
  route: window.location.pathname,
  scans: [],
  logs: [],
  configHistory: [],
  commandHistory: [],
  agentContext: {},
};

const $ = (id) => document.getElementById(id);
const esc = (value) => String(value ?? "").replace(/[&<>'"]/g, (m) => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[m]));

function toast(message, kind = "success") {
  const region = $("toast");
  const el = document.createElement("div");
  el.className = `toast ${kind}`;
  el.textContent = message;
  region.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

async function api(url, options = {}) {
  const opts = { credentials: "same-origin", ...options };
  opts.headers = { ...(options.headers || {}) };
  if (opts.body && !(opts.body instanceof FormData) && !opts.headers["Content-Type"]) {
    opts.headers["Content-Type"] = "application/json";
  }
  const response = await fetch(url, opts);
  // Read the body only once. Calling response.text() after response.json() fails
  // attempts to consume an already-used stream and can hide the real server error.
  const raw = await response.text();
  let data = null;
  if (raw) {
    try { data = JSON.parse(raw); }
    catch { data = { error: raw.slice(0, 2000) || `Request failed (${response.status})` }; }
  }
  if (!response.ok) {
    const message = data?.error || `Request failed (${response.status})`;
    const err = new Error(message);
    err.status = response.status;
    err.data = data;
    throw err;
  }
  return data;
}

function classifyScore(score) {
  const n = Number(score);
  if (!Number.isFinite(n)) return "";
  if (n >= 8) return "good";
  if (n >= 5) return "warn";
  return "bad";
}

function statusPill(status) {
  const s = String(status || "INFO").toUpperCase();
  const cls = s === "PASS" || s === "COMPLETE" ? "status-pass" : s === "FAIL" ? "status-bad" : s === "WARN" || s === "WARNING" || s === "NO_RESPONSE" ? "status-warn" : "status-info";
  return `<span class="status-pill ${cls}">${esc(s)}</span>`;
}

function navigate(path) {
  if (window.location.pathname !== path) window.history.pushState({}, "", path);
  state.route = path;
  renderRoute();
}

function setupNavigation() {
  document.addEventListener("click", (event) => {
    const target = event.target.closest("[data-route]");
    if (!target) return;
    const href = target.getAttribute("href") || target.dataset.route;
    if (!href || href.startsWith("http")) return;
    event.preventDefault();
    navigate(href);
  });
  window.addEventListener("popstate", () => {
    state.route = window.location.pathname;
    renderRoute();
  });
}

async function loadSession() {
  try {
    state.user = await api("/me");
    $("auth").hidden = true;
    $("app").hidden = false;
    $("user-email").textContent = state.user.email;
    await loadBaseData();
  } catch {
    state.user = null;
    $("auth").hidden = false;
    $("app").hidden = true;
    const password = $("password");
    if (password) password.value = "";
  }
}

async function loadBaseData() {
  const jobs = await Promise.allSettled([
    api("/api/config"),
    api("/scans"),
    api("/history/logs"),
  ]);
  const [config, scans, logs] = jobs;
  if (config.status === "fulfilled") {
    $("backend-version").textContent = `v${config.value.version || "3"}`;
    $("backend-label").textContent = "Backend ready";
  }
  if (scans.status === "fulfilled") state.scans = scans.value;
  if (logs.status === "fulfilled") state.logs = logs.value;
}

function authSetup() {
  let mode = "login";
  document.querySelectorAll(".auth-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      mode = tab.dataset.mode;
      document.querySelectorAll(".auth-tab").forEach((x) => x.classList.toggle("active", x === tab));
      $("auth-submit").textContent = mode === "login" ? "Log in" : "Create account";
      $("password").autocomplete = mode === "login" ? "current-password" : "new-password";
    });
  });
  $("auth-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = $("auth-submit-button");
    button.disabled = true;
    try {
      const endpoint = mode === "login" ? "/login" : "/signup";
      const result = await api(endpoint, { method: "POST", body: JSON.stringify({ email: $("email").value, password: $("password").value }) });
      state.user = result;
      toast(mode === "login" ? "Signed in successfully." : "Account created successfully.");
      await loadSession();
      navigate("/dashboard");
    } catch (error) {
      toast(error.message, "error");
    } finally {
      button.disabled = false;
    }
  });

  const logoutButton = $("logout");
  if (logoutButton) {
    logoutButton.addEventListener("click", async () => {
      logoutButton.disabled = true;
      try {
        await api("/logout", { method: "POST", body: JSON.stringify({}) });
        state.user = null;
        state.scans = [];
        state.logs = [];
        state.agentContext = {};
        state.route = "/dashboard";
        window.history.replaceState({}, "", "/dashboard");
        $("app").hidden = true;
        $("auth").hidden = false;
        $("password").value = "";
        toast("Signed out successfully.");
      } catch (error) {
        // If the server has already expired the session, return to the login view.
        if (error.status === 401 || error.status === 403) {
          state.user = null;
          $("app").hidden = true;
          $("auth").hidden = false;
          $("password").value = "";
          toast("Your session has ended. Please log in again.", "warn");
        } else {
          toast(error.message || "Unable to log out. Please try again.", "error");
        }
      } finally {
        logoutButton.disabled = false;
      }
    });
  }
}

function renderRoute() {
  if (!state.user) return;
  document.querySelectorAll(".page-view").forEach((p) => { p.hidden = true; });
  document.querySelectorAll(".nav-link").forEach((a) => a.classList.toggle("active", a.dataset.route === state.route));
  let key = "dashboard";
  if (state.route.startsWith("/calculator")) key = "calculator";
  else if (state.route.startsWith("/config")) key = "config";
  else if (state.route.startsWith("/tester")) key = "tester";
  else if (state.route.startsWith("/chatbot")) key = "chatbot";
  else if (state.route.startsWith("/history")) key = "history";
  else if (state.route.startsWith("/policy")) key = "policy";
  else if (state.route.startsWith("/scan/")) key = "detail";
  $(`page-${key}`).hidden = false;
  const fn = { dashboard: renderDashboard, calculator: renderCalculator, config: renderConfig, tester: renderTester, chatbot: renderChatbot, history: renderHistory, policy: renderPolicy, detail: renderDetail }[key];
  fn();
}

function renderDashboard() {
  const target = $("page-dashboard");
  const scans = state.scans;
  const logs = state.logs;
  const liveCount = logs.filter(x => x.action === "live_api_test").length;
  const configCount = logs.filter(x => x.action === "api_config_check").length;
  const calcCount = logs.filter(x => x.action === "api_calculator").length;
  const completed = scans.filter(x => x.status === "complete" && Number.isFinite(Number(x.security_score)));
  const best = completed.length ? Math.max(...completed.map(x => Number(x.security_score))) : null;
  const latest = scans.find(x => x.status === "complete") || scans[0];
  const assessments = scans.length + liveCount + configCount + calcCount;

  const recent = logs.slice(0, 8);
  target.innerHTML = `
    <div class="page-header dashboard-top">
      <div><div class="page-kicker">API-STAT</div><h1 class="page-title">Dashboard</h1><p class="page-subtitle">Unified API security posture across source reviews, live endpoint tests, configuration checks and threat-model assessments.</p></div>
      <div><button class="btn btn-outline" id="refresh-dashboard">Refresh</button></div>
    </div>

    <div class="assessment-summary">
      <div class="panel summary-main"><div class="stat-label">Latest source-code security score</div><div class="score ${classifyScore(latest?.security_score)}">${latest?.security_score != null ? `${Number(latest.security_score).toFixed(1)}/10` : "—"}</div><div class="stat-note">${latest ? esc(latest.source_name || "Latest scan") : "No source scan yet"}</div></div>
      <div class="panel stat-card"><div class="stat-label">All assessments</div><div class="stat-value">${assessments}</div><div class="stat-note">Source ${scans.length} · Live ${liveCount} · Config ${configCount} · Calc ${calcCount}</div></div>
      <div class="panel stat-card"><div class="stat-label">Best source score</div><div class="stat-value">${best != null ? `${best.toFixed(1)}` : "—"}</div><div class="stat-note">out of 10</div></div>
      <div class="panel stat-card"><div class="stat-label">Completed scans</div><div class="stat-value">${completed.length}</div><div class="stat-note">${scans.length ? `${Math.round((completed.length / scans.length) * 100)}% completion rate` : "No scan history"}</div></div>
    </div>

    <div class="card-grid three">
      <a class="panel action-card" href="/calculator" data-route="/calculator"><div><h3>API Calculator</h3><p>Model exposure, authentication, authorization, transport and API control risk.</p></div><div class="action-arrow">→</div></a>
      <a class="panel action-card" href="/config" data-route="/config"><div><h3>API Config Check</h3><p>Use the built-in security terminal to inspect HTTPS, headers, CORS and method exposure.</p></div><div class="action-arrow">→</div></a>
      <a class="panel action-card" href="/tester" data-route="/tester"><div><h3>Live API / Source</h3><p>Run a live endpoint security assessment or a fast AI-assisted source-code review.</p></div><div class="action-arrow">→</div></a>
    </div>

    <div class="activity-grid">
      <div class="panel panel-pad"><div class="section-title-row"><div><div class="page-kicker">ACCOUNT ACTIVITY</div><h2>Recent actions</h2></div><a class="btn btn-ghost btn-small" href="/history" data-route="/history">View history</a></div>
        <div class="activity-list">${recent.length ? recent.map(x => `<div class="activity-row"><div class="activity-time">${new Date(x.created_at).toLocaleString()}</div><div><div class="activity-name">${esc(x.action.replaceAll("_", " "))}</div><div class="activity-target">${esc(x.target || "Assessment")}</div></div><div>${statusPill("INFO")}</div></div>`).join("") : `<div class="result-empty">No assessment activity yet.</div>`}</div>
      </div>
      <div class="panel panel-pad"><div class="section-title-row"><div><div class="page-kicker">SOURCE SCORE TREND</div><h2>Recent scan posture</h2></div></div>
        <div class="trend-list">${completed.slice(0,8).reverse().map(s => `<div class="trend-row"><span class="trend-label">#${s.scan_id}</span><div class="trend-bar"><span style="width:${Math.max(0,Math.min(100,Number(s.security_score)*10))}%"></span></div><b>${Number(s.security_score).toFixed(1)}</b></div>`).join("") || `<div class="result-empty">Complete a source scan to populate the trend.</div>`}</div>
      </div>
    </div>`;
  $("refresh-dashboard").onclick = async () => { await loadBaseData(); renderDashboard(); toast("Dashboard refreshed."); };
}

function calculatorFields() {
  const items = [
    ["internet_exposure","Internet exposure","How directly reachable is the API from the public internet?"],
    ["data_sensitivity","Data sensitivity","How sensitive is the data handled by the API?"],
    ["auth_weakness","Authentication weakness","How weak or inconsistent is authentication?"],
    ["authorization_weakness","Authorization weakness","How weak are object/function-level authorization checks?"],
    ["rate_limit_weakness","Rate-limit weakness","How weak is throttling or abuse protection?"],
    ["input_validation_weakness","Input validation weakness","How much untrusted input reaches sensitive operations?"],
    ["tls_weakness","TLS weakness","How weak is transport security?"],
    ["cors_weakness","CORS weakness","How permissive is cross-origin access?"],
    ["logging_weakness","Logging weakness","How weak is audit logging and detection?"],
  ];
  return items;
}

function renderCalculator() {
  const target = $("page-calculator");
  target.innerHTML = `
    <div class="page-header"><div><div class="page-kicker">02 · THREAT MODEL</div><h1 class="page-title">API Calculator</h1><p class="page-subtitle">Enter the current security posture of the API. API-STAT calculates a risk score and uses the configured LLM to explain priorities and remediation.</p></div></div>
    <div class="calc-grid">
      <form class="panel panel-pad" id="calculator-form"><div class="form-grid one">${calculatorFields().map(([key,label,help]) => `<label>${esc(label)}<div class="range-line"><input type="range" min="0" max="10" value="3" step="1" data-factor="${key}"><span class="range-value" data-value="${key}">3</span></div><span class="help">${esc(help)}</span></label>`).join("")}</div><div class="form-actions"><button class="btn btn-primary" type="submit">Calculate risk</button></div></form>
      <div class="panel result-hero" id="calculator-result"><div class="page-kicker">ASSESSMENT RESULT</div><div class="result-empty" style="margin-top:16px">Run the calculator to see the risk score, AI interpretation and remediation.</div></div>
    </div>`;
  target.querySelectorAll('input[type="range"]').forEach(input => input.addEventListener("input", () => target.querySelector(`[data-value="${input.dataset.factor}"]`).textContent = input.value));
  $("calculator-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const payload = {};
    target.querySelectorAll('[data-factor]').forEach(input => payload[input.dataset.factor] = Number(input.value));
    const resultBox = $("calculator-result");
    resultBox.innerHTML = `<div class="page-kicker">ASSESSMENT RESULT</div><div class="result-empty" style="margin-top:16px">Running AI-assisted assessment…</div>`;
    try {
      const result = await api("/developer/calculator", { method:"POST", body:JSON.stringify(payload) });
      const ai = result.ai || {};
      const score = Number(result.risk_score || 0);
      resultBox.innerHTML = `<div class="page-kicker">ASSESSMENT RESULT</div><div class="result-score ${classifyScore(10-score)}">${score.toFixed(1)}/10</div><div class="muted">Risk level: <b>${esc(ai.risk_level || "ASSESSED")}</b></div><div class="result-section"><b>AI interpretation</b><p class="muted">${esc(ai.executive_summary || "Assessment completed.")}</p></div><div class="result-section"><b>Priority controls</b><div class="chip-row" style="margin-top:10px">${(ai.priority_controls || result.weak_controls || []).map(x => `<span class="chip">${esc(x)}</span>`).join("") || '<span class="muted">No high-priority control was identified.</span>'}</div></div><div class="result-section"><b>Remediation</b><ol class="muted">${(ai.remediation || []).map(x => `<li>${esc(x)}</li>`).join("")}</ol></div><div class="report-row"><a class="btn btn-outline" href="/developer/report/html/calculator" target="_blank" rel="noreferrer">Open formal HTML report</a></div>`;
      await loadBaseData();
      toast("Calculator assessment completed.");
    } catch (error) { resultBox.innerHTML = `<div class="result-empty">${esc(error.message)}</div>`; toast(error.message,"error"); }
  });
}

function configOutputForCommand(command, result) {
  const lines = [];
  if (result.summary) lines.push(result.summary);
  if (result.status_code !== undefined && result.status_code !== null) lines.push(`HTTP status: ${result.status_code}`);
  if (result.response_time_ms !== undefined && result.response_time_ms !== null) lines.push(`Response time: ${result.response_time_ms} ms`);
  if (result.security_score !== undefined && result.security_score !== null) lines.push(`Observed configuration score: ${result.security_score}/10 (heuristic, not exploitability proof)`);

  if (command === "header-config") {
    lines.push("Observed response headers:");
    for (const [key, value] of Object.entries(result.headers || {})) lines.push(`${key}: ${value}`);
  }

  for (const check of (result.checks || [])) {
    lines.push(`[${String(check.status || "INFO").toUpperCase()}] ${check.name}: ${check.detail}`);
  }

  const discovery = result.discovery || {};
  if (command === "api-docs" || command === "api-discover" || command === "full-report") {
    const specs = discovery.api_docs?.specifications || [];
    if (specs.length) {
      lines.push(`OpenAPI/Swagger specifications found: ${specs.length}`);
      specs.forEach(spec => {
        lines.push(`  Spec: ${spec.url} | ${spec.title || "API"} | ${spec.version || "version unknown"} | ${spec.paths?.length || 0} route(s)`);
        (spec.paths || []).slice(0, 15).forEach(route => lines.push(`    ${route.methods?.join(",") || "METHOD UNKNOWN"} ${route.path}`));
      });
    } else if (discovery.api_docs) {
      lines.push("No parseable OpenAPI/Swagger specification found at the checked conventional locations.");
    }
  }

  if (command === "sitemap-map" || command === "api-discover" || command === "full-report") {
    const sitemap = discovery.sitemap;
    if (sitemap) {
      lines.push(`Sitemap URLs collected: ${sitemap.page_count || 0}`);
      (sitemap.resources || []).forEach(item => lines.push(`  ${item.resource}: ${item.status_code ?? item.error ?? "not available"}`));
      (sitemap.pages || []).slice(0, 15).forEach(page => lines.push(`  Page: ${page}`));
      if ((sitemap.pages || []).length > 15) lines.push(`  … ${sitemap.pages.length - 15} more URL(s) in result data`);
    }
  }

  if (command === "js-route-map" || command === "api-discover" || command === "full-report") {
    const js = discovery.javascript;
    if (js) {
      lines.push(`JavaScript assets examined: ${js.assets_examined || 0}; candidate routes: ${(js.routes || []).length}`);
      (js.routes || []).slice(0, 25).forEach(route => lines.push(`  ${route.path} — ${route.discovery_source}`));
      (js.errors || []).slice(0, 5).forEach(error => lines.push(`  Asset notice: ${error}`));
    }
  }

  if (command === "method-config" || command === "full-report") {
    const methods = discovery.method_responses || {};
    for (const [method, info] of Object.entries(methods)) {
      lines.push(`${method}: HTTP ${info.status_code}; Allow=${info.allow || "not disclosed"}; CORS methods=${info.access_control_allow_methods || "not disclosed"}`);
    }
  }

  const endpoints = result.endpoints || [];
  if (endpoints.length && ["api-docs", "js-route-map", "api-discover", "full-report"].includes(command)) {
    lines.push(`Endpoint inventory entries: ${endpoints.length}`);
    endpoints.slice(0, 30).forEach(endpoint => {
      const method = endpoint.methods?.length ? `${endpoint.methods.join(",") } ` : "";
      const status = endpoint.status_code !== undefined ? ` | HTTP ${endpoint.status_code}` : " | not probed";
      const type = endpoint.content_type ? ` | ${endpoint.content_type}` : "";
      const error = endpoint.error ? ` | ${endpoint.error}` : "";
      lines.push(`  ${method}${endpoint.path || endpoint.url || "[unknown path]"}${status}${type}${error}`);
    });
    if (endpoints.length > 30) lines.push(`  … ${endpoints.length - 30} more entry/entries in result data`);
  }

  const findings = result.findings || [];
  if (findings.length) {
    lines.push(`Findings requiring review: ${findings.length}`);
    findings.forEach(finding => {
      lines.push(`  [${finding.severity || finding.status || "REVIEW"}] ${finding.title}: ${finding.evidence || "See check evidence."}`);
      if (finding.remediation) lines.push(`    Recommended action: ${finding.remediation}`);
    });
  }
  if (result.ai?.overall_assessment) lines.push(`AI interpretation: ${result.ai.overall_assessment}`);
  lines.push("Discovery candidates are not vulnerabilities until their behavior and access controls are verified.");
  return lines;
}

function renderConfig() {
  const target = $("page-config");
  const commandCards = [
    ["site-config <url>", "Check reachability, redirects, HTTPS and baseline configuration."],
    ["header-config <url>", "Inspect security headers, cookies and information disclosure."],
    ["tls-config <url>", "Validate TLS handshake, certificate hostname and expiry."],
    ["cors-config <url>", "Test controlled-origin CORS and preflight responses."],
    ["method-config <url>", "Inspect HEAD and OPTIONS method disclosure only."],
    ["api-docs <url>", "Find and parse conventional OpenAPI/Swagger specifications."],
    ["sitemap-map <url>", "Map same-host URLs exposed through robots and sitemaps."],
    ["js-route-map <url>", "Extract API route candidates from same-host JavaScript assets."],
    ["api-discover <url>", "Validate a bounded set of API endpoint candidates."],
    ["full-report <url>", "Combine config checks, endpoint discovery and remediation evidence."]
  ];
  target.innerHTML = `
    <div class="page-header"><div><div class="page-kicker">03 · API CONTROL TERMINAL</div><h1 class="page-title">API Config Check</h1><p class="page-subtitle">Check deployed HTTP(S) configuration and discover candidate API endpoints using bounded, evidence-based checks.</p></div></div>
    <div class="terminal-shell">
      <div class="terminal-head"><span class="term-dot"></span><span class="term-dot"></span><span class="term-dot"></span><span class="term-title">api-stat@security:~</span></div>
      <div class="terminal-body"><div id="terminal-output" class="terminal-output"></div><div class="terminal-input-row"><span class="term-prompt">api-stat@security:~$</span><input id="terminal-input" class="term-input" autocomplete="off" spellcheck="false" placeholder="type help or api-discover https://example.com"></div></div>
    </div>
    <div class="command-help">${commandCards.map(([command, description]) => `<div class="command-card"><code>${command.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</code><div class="help">${description}</div></div>`).join("")}</div>
    <div class="help muted" style="margin-top:10px">Utilities: <code>help</code> lists commands; <code>clear</code> clears this terminal. Scan only systems you own or are authorized to assess. Requests are bounded and state-changing methods are not used by this module.</div>
    <div class="allowed-select"><details><summary>Allowed source-code file types for section 4</summary><div class="allowed-list">${[".py",".js",".jsx",".ts",".tsx",".java",".kt",".go",".rs",".php",".rb",".cs",".c",".cpp",".h",".hpp",".swift",".m",".mm",".scala",".sh",".bash",".zsh",".ps1",".sql",".vue",".svelte",".dart",".ex",".exs",".erl",".hrl",".r",".lua",".pl",".asm"].map(x=>`<span class="chip">${x}</span>`).join("")}</div></details></div>`;
  const output = $("terminal-output");
  const input = $("terminal-input");
  const print = (text, kind="") => { const line = document.createElement("div"); line.className = `term-line ${kind}`; line.textContent = String(text); output.appendChild(line); output.scrollTop = output.scrollHeight; };
  print("API-STAT configuration scanner ready. Type help to begin.", "dim");
  print("Target policy: public HTTP(S) host only; cross-host redirects and out-of-scope ports are blocked.", "dim");
  input.focus();
  input.addEventListener("keydown", async (event) => {
    if (event.key !== "Enter") return;
    const raw = input.value.trim();
    if (!raw) return;
    input.value = "";
    print(`api-stat@security:~$ ${raw}`, "cmd");
    const splitAt = raw.search(/\s/);
    const cmd = (splitAt < 0 ? raw : raw.slice(0, splitAt)).toLowerCase();
    const url = splitAt < 0 ? "" : raw.slice(splitAt).trim();
    if (cmd === "clear") { output.innerHTML = ""; return; }
    if (cmd === "help") {
      print("Commands:");
      commandCards.forEach(([command, description]) => print(`  ${command} — ${description}`));
      print("Utilities: help | clear");
      return;
    }
    const supported = new Set(["site-config", "header-config", "tls-config", "cors-config", "method-config", "api-docs", "sitemap-map", "js-route-map", "api-discover", "full-report"]);
    if (!supported.has(cmd)) { print("Unknown or retired command. Type help for the ten supported commands.", "warn"); return; }
    if (!/^https?:\/\//i.test(url)) { print(`Usage: ${cmd} https://your-authorized-domain.example`, "warn"); return; }
    print(`Running ${cmd} against ${url}…`, "dim");
    try {
      const result = await api("/developer/config-check", { method:"POST", body:JSON.stringify({url, command:cmd, timeout:6}) });
      configOutputForCommand(cmd, result).forEach(line => {
        const value = String(line);
        const kind = value.startsWith("[PASS]") ? "good" : (value.startsWith("[WARN]") || value.startsWith("[FAIL]") || value.startsWith("[HIGH]") || value.startsWith("[MEDIUM]") ? "warn" : "");
        print(value, kind);
      });
      print(`Assessment complete in ${result.duration_ms ?? "recorded"} ms.`, "good");
      await loadBaseData();
    } catch (error) { print(`Error: ${error.message}`, "bad"); }
  });
}

function renderTester() {
  const target = $("page-tester");
  target.innerHTML = `
    <div class="page-header"><div><div class="page-kicker">04 · SECURITY ASSESSMENT</div><h1 class="page-title">Live API / Source Code Test</h1><p class="page-subtitle">Use live endpoint evidence or source-code evidence. The assessment runs independently from the Security Chatbot.</p></div></div>
    <div class="scan-grid">
      <div class="panel column-panel">
        <div class="column-head"><h2>Source Code Test</h2><p>AI-assisted secure API coding review. Upload source code or connect a public GitHub repository.</p></div>
        <div class="column-body">
          <form id="source-form" class="stack-form">
            <label>Source-code files<div><input id="source-files" type="file" multiple accept=".py,.js,.jsx,.ts,.tsx,.java,.kt,.go,.rs,.php,.rb,.cs,.c,.cpp,.h,.hpp,.swift,.m,.mm,.scala,.sh,.bash,.zsh,.ps1,.sql,.vue,.svelte,.dart,.ex,.exs,.erl,.hrl,.r,.lua,.pl,.asm"></div></label>
            <div class="help">Source code only. Archives, dependency/data files, JSON/YAML/OpenAPI specifications and web documents are rejected. The source must contain an API key/token/credential-like value for credential-handling assessment.</div>
            <label>Optional scan image<div><input id="scan-evidence-image" type="file" accept="image/png,image/jpeg,image/webp"></div></label>
            <div class="help">Image evidence is analyzed only during this scan and is used to enrich AI context.</div>
            <div class="form-actions" style="justify-content:flex-start"><button class="btn btn-secondary" type="button" id="browse-source">Browse source files</button><button class="btn btn-primary" type="submit">Run source review</button></div>
            <div class="panel panel-pad source-connector">
              <label>GitHub repository URL <span class="muted">(alternative to file upload)</span><input id="github-source-url" type="url" placeholder="https://github.com/org/public-api-service"></label>
              <div class="help">GitHub login is not required. Use a public repository URL as the source connector.</div>
            </div>
          </form>
          <div id="source-result" class="code-result"><div class="result-empty">Choose source code or a public repository URL.</div></div>
        </div>
      </div>

      <div class="panel column-panel">
        <div class="column-head"><h2>Live API Test</h2><p>Send a real HTTP request and analyze the returned security controls, transport signals, headers, CORS and authentication behavior.</p></div>
        <div class="column-body">
          <form id="live-form" class="stack-form">
            <label>API URL<input id="live-url" type="url" placeholder="https://api.example.com/v1/health" required></label>
            <div class="inline-grid"><label>Method<select id="live-method"><option>GET</option><option>HEAD</option><option>POST</option><option>PUT</option><option>PATCH</option><option>DELETE</option><option>OPTIONS</option></select></label><label>Credential type<select id="credential-type"><option value="none">None</option><option value="x-api-key">X-API-Key</option><option value="bearer">Bearer token</option></select></label></div>
            <label id="credential-wrap" hidden>API key / token<input id="credential" type="password" placeholder="Optional test credential"></label>
            <div class="help">Credentials are redacted from stored evidence and reports.</div>
            <label class="checkbox-row"><input id="deep-scan" type="checkbox"> Run deep scan (OWASP API Top 10 probes: BOLA, broken auth, rate limit, mass assignment, injection)</label>
            <div class="help">Deep scan sends a few extra requests to the endpoint, including with GET/HEAD variations and (for POST/PUT/PATCH) one extra write with probe fields added. Only enable it against an endpoint you own or are authorized to test.</div>
            <div class="form-actions" style="justify-content:flex-start"><button class="btn btn-primary" id="live-button" type="submit">Run live security test</button></div>
          </form>
          <div id="live-result" class="result-panel"><div class="result-empty">Enter an endpoint and run the live assessment.</div></div>
        </div>
      </div>
    </div>`;

  const fileInput = $("source-files");
  $("browse-source").onclick = () => fileInput.click();
  $("credential-type").addEventListener("change", (e) => { $("credential-wrap").hidden = e.target.value === "none"; });

  const setAgentContext = (ctx) => { state.agentContext = ctx || {}; };

  $("source-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const files = [...fileInput.files];
    const githubUrl = $("github-source-url").value.trim();
    if (!files.length && !githubUrl) { toast("Choose source-code files or provide a public GitHub repository URL.", "warn"); return; }
    if (files.length && githubUrl) { toast("Use files OR GitHub URL, not both.", "warn"); return; }
    const bad = files.find(f => !/\.(py|js|jsx|ts|tsx|java|kt|go|rs|php|rb|cs|c|cpp|h|hpp|swift|m|mm|scala|sh|bash|zsh|ps1|sql|vue|svelte|dart|ex|exs|erl|hrl|r|lua|pl|asm)$/i.test(f.name));
    if (bad) { toast(`${bad.name} is not a supported source-code file.`, "warn"); return; }
    const image = $("scan-evidence-image").files[0];
    const form = new FormData();
    if (githubUrl) form.append("source_url", githubUrl);
    files.forEach(f => form.append("source_files", f));
    if (image) form.append("evidence_image", image);
    const resultBox = $("source-result");
    resultBox.innerHTML = `<div class="result-empty">Source accepted. Starting analysis…</div><div class="scan-progress"><div class="progress-track"><span id="source-progress" style="width:2%"></span></div><div id="source-stage" class="help" style="margin-top:8px">Queued</div></div>`;
    try {
      const result = await api("/scan/new", { method:"POST", body: form });
      setAgentContext({target: githubUrl || files.map(x=>x.name).join(", "), mode:"source", scan_id:result.scan_id});
      pollSourceScan(result.scan_id);
    } catch (error) { resultBox.innerHTML = `<div class="result-empty">${esc(error.message)}</div>`; toast(error.message,"error"); }
  });

  $("live-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = $("live-button"); const resultBox = $("live-result"); button.disabled = true;
    resultBox.innerHTML = `<div class="result-empty">Sending live request and collecting security evidence…</div>`;
    const type = $("credential-type").value; const credential = $("credential").value.trim(); const headers = {};
    if (credential && type === "x-api-key") headers["X-API-Key"] = credential;
    if (credential && type === "bearer") headers["Authorization"] = `Bearer ${credential}`;
    try {
      const url=$("live-url").value.trim();
      setAgentContext({target:url,method:$("live-method").value,mode:"live"});
      const deepScan = $("deep-scan").checked;
      const result = await api("/developer/live-test", { method:"POST", body:JSON.stringify({ url, method:$("live-method").value, headers, timeout:15, attempts:3, deep_scan: deepScan }) });
      renderLiveResult(result); await loadBaseData();
    } catch (error) { resultBox.innerHTML = `<div class="result-empty">${esc(error.message)}</div>`; toast(error.message,"error"); }
    finally { button.disabled = false; }
  });
}

function renderLiveResult(result) {
  const box = $("live-result");
  if (!box) return;
  if (!result || !result.ok) {
    box.innerHTML = `<div class="result-empty">${esc(result?.error || "The live request could not be completed. Check the URL and network reachability.")}</div><div class="report-row"><a class="btn btn-outline" href="/developer/report/html/live" target="_blank" rel="noreferrer">Open assessment report</a></div>`;
    return;
  }
  const checks = result.checks || [];
  const rows = checks.map(c => `<div class="check-row"><span>${esc(c.name)}</span>${statusPill(c.status)}<span class="muted">${esc(c.detail)}</span></div>`).join("");
  const preview = result.response?.body_preview ? esc(result.response.body_preview.slice(0, 1500)) : "";
  box.innerHTML = `
    <div class="panel panel-pad" style="background:#091a29">
      <div class="live-result-head">
        <div>
          <div class="page-kicker">LIVE RESULT${result.deep_scan ? " · DEEP SCAN" : ""}</div>
          <div class="result-url">${esc(result.method)} ${esc(result.effective_url || result.url)}</div>
          <div class="muted">HTTP ${esc(result.status_code)} · ${esc(result.response_time_ms)} ms · ${esc(result.attempts)} attempt(s)</div>
        </div>
        <div class="score-badge ${classifyScore(result.security_score)}">${Number(result.security_score || 0).toFixed(1)}/10</div>
      </div>
      ${result.ai?.executive_summary ? `<div class="result-section"><b>AI assessment</b><p class="muted">${esc(result.ai.executive_summary)}</p></div>` : ""}
      ${(result.ai?.remediation || []).length ? `<div class="result-section"><b>AI remediation guidance</b><ol class="muted">${result.ai.remediation.map(x => `<li>${esc(x)}</li>`).join("")}</ol></div>` : ""}
      <div class="result-section"><b>Security checks${result.deep_scan ? " (incl. OWASP API Top 10 probes)" : ""}</b><div class="check-table">${rows || '<div class="result-empty">No checks were recorded.</div>'}</div></div>
      ${preview ? `<div class="result-section"><b>Response preview</b><pre class="code-preview">${preview}</pre></div>` : ""}
      <div class="report-row"><a class="btn btn-outline" href="/developer/report/html/live" target="_blank" rel="noreferrer">Open formal HTML report</a></div>
    </div>`;
}

/* Security chatbot UI lives in chat.js (renderChatbot) */

async function renderPolicy() {
  const target=$("page-policy");
  target.innerHTML=`
    <div class="page-header policy-header"><div><div class="page-kicker">06 · SECURE DEVELOPMENT STANDARD</div><h1 class="page-title">API-STAT Security Policy</h1><p class="page-subtitle">Policy documents used for secure API development and assessment guidance.</p></div><div><button class="btn btn-primary btn-add-policy" id="add-policy">＋ Add</button><input id="policy-file-input" type="file" accept="application/pdf" hidden></div></div>
    <div class="panel policy-library">
      <div class="policy-library-head"><div><h2>Policy Documents</h2><p class="muted">Open a policy inside API-STAT. No separate browser page is required.</p></div><div class="policy-count" id="policy-count">Loading…</div></div>
      <div id="policy-list" class="policy-list"></div>
    </div>
    <div id="policy-reader" class="policy-reader" hidden>
      <div class="policy-reader-bar"><div><div class="page-kicker">POLICY VIEWER</div><b id="policy-reader-title">api-stat version1</b></div><button class="btn btn-ghost btn-small" id="close-policy-reader">Close</button></div>
      <div class="policy-reader-body"><iframe id="policy-iframe" title="API-STAT Policy Viewer"></iframe></div>
    </div>`;

  const listEl=$("policy-list"), input=$("policy-file-input"), reader=$("policy-reader"), iframe=$("policy-iframe");
  const loadPolicies=async()=>{
    try {
      const rows=await api('/policy/list');
      $("policy-count").textContent=`${rows.length} document${rows.length===1?'':'s'}`;
      listEl.innerHTML=rows.map(d=>`<div class="policy-row"><div class="policy-icon">PDF</div><div class="policy-meta"><b>${esc(d.display_name)}</b><small>${esc(d.filename)}</small></div><div class="policy-actions"><button class="dots-button" type="button" data-menu="${esc(d.id)}" aria-label="Policy actions">⋯</button><div class="dots-menu" data-menu-panel="${esc(d.id)}"><button type="button" data-view="${esc(d.id)}">View</button><button type="button" class="danger-text" data-delete="${esc(d.id)}">Delete</button></div></div></div>`).join('');
    } catch(e) { listEl.innerHTML=`<div class="result-empty">${esc(e.message)}</div>`; }
  };
  const openPolicy=(id,name)=>{ iframe.src=`/policy/view/${encodeURIComponent(id)}#page=1&zoom=page-width`; $("policy-reader-title").textContent=name||'Policy'; reader.hidden=false; reader.scrollIntoView({behavior:'smooth',block:'start'}); };
  listEl.addEventListener('click', async (e)=>{
    const menuBtn=e.target.closest('[data-menu]');
    if(menuBtn){
      const panel=listEl.querySelector(`[data-menu-panel="${CSS.escape(menuBtn.dataset.menu)}"]`); listEl.querySelectorAll('.dots-menu.open').forEach(x=>x!==panel&&x.classList.remove('open')); if(panel)panel.classList.toggle('open'); return;
    }
    const view=e.target.closest('[data-view]'); if(view){const row=view.closest('.policy-row');openPolicy(view.dataset.view,row.querySelector('.policy-meta b').textContent);return;}
    const del=e.target.closest('[data-delete]'); if(del){ if(del.dataset.delete==='builtin'){toast('The built-in api-stat version1 policy is protected.','warn');return;} if(!confirm('Delete this policy document?'))return; try{await api(`/policy/${encodeURIComponent(del.dataset.delete)}`,{method:'DELETE'});toast('Policy deleted.');await loadPolicies();}catch(err){toast(err.message,'error');} }
  });
  document.addEventListener('click', (e)=>{ if(!e.target.closest('.policy-actions')) listEl.querySelectorAll('.dots-menu.open').forEach(x=>x.classList.remove('open')); }, {once:true});
  $("close-policy-reader").onclick=()=>{reader.hidden=true;iframe.src='about:blank';};
  $("add-policy").onclick=()=>input.click();
  input.addEventListener('change',async()=>{const f=input.files[0]; if(!f)return; if(f.type!=='application/pdf'&&!f.name.toLowerCase().endsWith('.pdf')){toast('Only PDF policy documents are allowed.','warn');input.value='';return;} const fd=new FormData();fd.append('policy_file',f);try{await api('/policy/upload',{method:'POST',body:fd});toast('Policy added.');await loadPolicies();}catch(e){toast(e.message,'error');}finally{input.value='';}});
  await loadPolicies();
}

async function pollSourceScan(scanId) {
  const resultBox = $("source-result");
  let done = false;
  while (!done) {
    try {
      const result = await api(`/scan/${scanId}/status`);
      const percent = Number(result.progress || 0);
      const progress = $("source-progress");
      const stage = $("source-stage");
      if (progress) progress.style.width = `${percent}%`;
      if (stage) stage.textContent = `${result.stage || "Working"} · ${percent}%`;
      if (result.status === "complete") {
        const summary = await api(`/scan/${scanId}/summary`);
        const findings = await api(`/scan/${scanId}/findings`);
        state.agentContext = {target: summary.source?.name || 'Source code', source_name: summary.source?.name, security_score: summary.security_score, findings: findings.slice(0,8), mode:'source'}; const at=$('agent-target'); if(at) at.textContent=summary.source?.name || 'Source code';
        resultBox.innerHTML = `<div class="panel panel-pad" style="background:#091a29"><div class="live-result-head"><div><div class="page-kicker">SOURCE RESULT</div><div class="result-url">${esc(summary.source?.name || "Source code")}</div><div class="muted">${summary.stats.findings} finding(s) · ${summary.stats.cves} CVE(s) · ${summary.stats.design_flaws} design flaw candidate(s)</div></div><div class="score-badge ${classifyScore(summary.security_score)}">${Number(summary.security_score || 0).toFixed(1)}/10</div></div><div class="result-section"><b>AI secure coding posture</b><p class="muted">${esc(summary.ai_summary?.executive_summary || "Source review completed. Review the prioritized findings and remediation in the report.")}</p></div>${summary.ai_summary?.priority_actions?.length ? `<div class="result-section"><b>AI priority actions</b><ol class="muted">${summary.ai_summary.priority_actions.map(x=>`<li>${esc(x)}</li>`).join("")}</ol></div>` : ""}<div class="chip-row">${Object.entries(summary.categories || {}).map(([k,v])=>`<span class="chip">${esc(k)}: ${Number(v||0).toFixed(1)}/10</span>`).join("")}</div><div class="result-section"><b>Top findings</b>${findings.slice(0,5).map(f=>`<div class="finding-card"><div class="finding-title">${esc(f.title || f.rule_id || f.cve_id || "Security finding")}</div><div class="finding-meta"><span class="chip">${esc(f.category || "Unclassified")}</span><span class="chip">Score ${Number(f.finding_score || 0).toFixed(1)}</span></div><div class="muted">${esc(f.ai_explanation || f.raw_message || "")}</div></div>`).join("") || '<div class="result-empty">No actionable findings were recorded.</div>'}</div><div class="report-row"><a class="btn btn-outline" href="/scan/${scanId}/report/html" target="_blank" rel="noreferrer">Open formal HTML report</a><a class="btn btn-secondary" href="/scan/${scanId}" data-route="/scan/${scanId}">Open full scan</a></div></div>`;
        toast("Source review completed.");
        await loadBaseData();
        done = true;
      } else if (result.status === "failed") {
        resultBox.innerHTML = `<div class="result-empty">Source review stopped: ${esc(result.error || "Unknown error")}</div>`;
        done = true;
      }
    } catch (error) {
      resultBox.innerHTML = `<div class="result-empty">${esc(error.message)}</div>`;
      done = true;
    }
    if (!done) await new Promise(resolve => setTimeout(resolve, 900));
  }
}

async function renderHistory() {
  const target = $("page-history");
  target.innerHTML = `<div class="page-header"><div><div class="page-kicker">05 · ACCOUNT HISTORY</div><h1 class="page-title">History & Logs</h1><p class="page-subtitle">Every source scan and developer security assessment performed in this account.</p></div><div><button class="btn btn-outline" id="refresh-history">Refresh</button></div></div><div class="panel panel-pad"><div class="history-toolbar"><b id="history-count">Loading…</b><input id="history-search" class="search-box" placeholder="Search target or action"></div><div class="table-wrap"><table><thead><tr><th>Time</th><th>Action</th><th>Target</th><th>Result</th><th>Open</th></tr></thead><tbody id="history-body"></tbody></table></div></div>`;
  await loadBaseData();
  const rows = [...state.logs].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  const draw = () => {
    const q = $("history-search").value.toLowerCase();
    const filtered = rows.filter(x => `${x.action} ${x.target || ""}`.toLowerCase().includes(q));
    $("history-count").textContent = `${filtered.length} activity record(s)`;
    $("history-body").innerHTML = filtered.map(x => `<tr><td>${new Date(x.created_at).toLocaleString()}</td><td>${esc(x.action.replaceAll("_"," "))}</td><td>${esc(x.target || "—")}</td><td>${statusPill(x.action.includes("test") || x.action.includes("check") || x.action.includes("calculator") ? "COMPLETE" : "INFO")}</td><td>${x.action === "security_scan_started" || x.action === "security_scan_rescanned" ? (()=>{const s=state.scans.find(s=>String(s.scan_id)===String((x.target||"").split(":").pop())); return s ? `<a class="table-button" href="/scan/${s.scan_id}" data-route="/scan/${s.scan_id}">Open</a>` : "—";})() : "—"}</td></tr>`).join("") || `<tr><td colspan="5"><div class="result-empty">No matching activity.</div></td></tr>`;
  };
  $("history-search").addEventListener("input", draw);
  $("refresh-history").onclick = async () => { await loadBaseData(); draw(); toast("History refreshed."); };
  draw();
}

async function renderDetail() {
  const match = state.route.match(/^\/scan\/(\d+)$/);
  if (!match) { navigate("/dashboard"); return; }
  const id = match[1];
  const target = $("page-detail");
  target.innerHTML = `<div class="page-header"><div><div class="page-kicker">SOURCE SCAN</div><h1 class="page-title">Scan #${esc(id)}</h1><p class="page-subtitle">Full findings, AI remediation and security score.</p></div><div class="form-actions"><a class="btn btn-outline" href="/scan/${id}/report/html" target="_blank" rel="noreferrer">Open HTML report</a><button class="btn btn-primary" id="rescan-button">Rescan</button></div></div><div id="detail-content" class="result-empty">Loading scan…</div>`;
  try {
    const [summary, findings] = await Promise.all([api(`/scan/${id}/summary`),api(`/scan/${id}/findings`)]);
    $("detail-content").innerHTML = `<div class="panel panel-pad"><div class="detail-header"><div><div class="page-kicker">SECURITY SCORE</div><div class="detail-score ${classifyScore(summary.security_score)}">${Number(summary.security_score || 0).toFixed(1)}/10</div><div class="muted">${esc(summary.source?.name || "Source")}</div></div><div class="chip-row">${Object.entries(summary.categories||{}).map(([k,v])=>`<span class="chip">${esc(k)}: ${Number(v||0).toFixed(1)}</span>`).join("")}</div></div><div class="result-section"><b>AI executive summary</b><p class="muted">${esc(summary.ai_summary?.executive_summary || "")}</p></div>${summary.ai_summary?.priority_actions?.length ? `<div class="result-section"><b>AI priority actions</b><ol class="muted">${summary.ai_summary.priority_actions.map(x=>`<li>${esc(x)}</li>`).join("")}</ol></div>` : ""}</div><div style="margin-top:18px"><h2>Findings (${findings.length})</h2>${findings.map(f=>`<article class="finding-card"><div class="finding-top"><div class="finding-title">${esc(f.title || f.rule_id || f.cve_id || "Security finding")}</div><span class="chip">Score ${Number(f.finding_score||0).toFixed(1)}</span></div><div class="finding-meta"><span class="chip">${esc(f.category||"Unclassified")}</span>${f.cve_id?`<span class="chip">${esc(f.cve_id)}</span>`:""}${f.cvss_score!=null?`<span class="chip">CVSS ${esc(f.cvss_score)}</span>`:""}${f.exploit_available?`<span class="chip">Public exploit</span>`:""}</div><p class="muted">${esc(f.ai_explanation || f.raw_message || "")}</p>${f.ai_justification?`<p class="muted"><b>AI justification:</b> ${esc(f.ai_justification)}</p>`:""}${f.ai_fix_steps?.length?`<div class="remediation" style="margin-top:12px"><b>Remediation</b><ol class="muted">${f.ai_fix_steps.map(s=>`<li>${esc(s)}</li>`).join("")}</ol></div>`:""}${f.ai_fix_snippet?`<div class="pre" style="margin-top:12px">${esc(f.ai_fix_snippet)}</div>`:""}</article>`).join("") || '<div class="result-empty">No findings.</div>'}</div>`;
    $("rescan-button").onclick = async () => {
      $("rescan-button").disabled = true;
      try { const r = await api(`/scan/${id}/rescan`,{method:"POST"}); toast(`Rescan queued as #${r.scan_id}`); navigate(`/scan/${r.scan_id}`); }
      catch(e){toast(e.message,"error");}
      finally { $("rescan-button").disabled = false; }
    };
  } catch (error) { $("detail-content").innerHTML = `<div class="result-empty">${esc(error.message)}</div>`; }
}

async function boot() {
  setupNavigation();
  authSetup();
  await loadSession();
  if (state.user) renderRoute();
}

boot();
