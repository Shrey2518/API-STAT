"""Regression tests that AI report summaries are based on current scan evidence."""
import os
import unittest
from unittest.mock import patch

from app.llm import analyze_live_api, explain_scan


class EvidenceBasedAISummaryTests(unittest.TestCase):
    def test_live_summary_uses_observed_hsts_warning(self):
        with patch.dict(os.environ, {
            'OPENAI_API_KEY': '', 'GEMINI_API_KEY': '', 'OLLAMA_BASE_URL': ''
        }):
            result = analyze_live_api({
                'ok': True,
                'status_code': 403,
                'response_time_ms': 124,
                'checks': [
                    {'name': 'HSTS', 'status': 'WARN', 'detail': 'HSTS header is missing.'},
                    {'name': 'HTTPS', 'status': 'PASS', 'detail': 'Served over HTTPS.'},
                ],
            })
        self.assertEqual(result['provider'], 'heuristic')
        self.assertIn('HTTP 403', result['executive_summary'])
        self.assertTrue(any('Strict-Transport-Security' in item for item in result['remediation']))

    def test_source_summary_uses_current_finding_and_fix(self):
        with patch.dict(os.environ, {
            'OPENAI_API_KEY': '', 'GEMINI_API_KEY': '', 'OLLAMA_BASE_URL': ''
        }):
            result = explain_scan(
                {'security_score': 7.5, 'risk_score': 2.5},
                [{'title': 'Possible debug mode enabled', 'category': 'Security Misconfiguration',
                  'finding_score': 6.4, 'ai_fix_steps': ['Disable debug mode in production.']}],
                [{'step': 'Static analysis', 'status': 'complete'}],
            )
        self.assertIn('1 finding(s)', result['executive_summary'])
        self.assertIn('Disable debug mode in production.', result['priority_actions'])
        self.assertEqual(result['provider'], 'heuristic')


if __name__ == '__main__':
    unittest.main()
