"""Regression tests for scan-specific HTML reports (no network or Flask needed)."""
import tempfile
import unittest
from pathlib import Path

from app.report_dynamic import generate_live_report_html, generate_source_report_html


class DynamicReportTests(unittest.TestCase):
    def test_live_report_tracks_current_result_and_remediation(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "live.html"
            generate_live_report_html("Live API test", {
                "report_mode": "live",
                "report_id": "LIVE-TEST-123",
                "assessment_type": "Live API Security Test",
                "target": "https://api.example.test/v2/items",
                "url": "https://api.example.test/v2/items",
                "method": "GET",
                "status_code": 403,
                "response_time_ms": 123.4,
                "attempts": 1,
                "ok": True,
                "deep_scan": False,
                "checks": [
                    {"name": "HTTPS", "status": "PASS", "detail": "HTTPS was used."},
                    {"name": "HSTS", "status": "WARN", "detail": "HSTS header is missing."},
                ],
                "ai_provider": "heuristic",
                "ai_model": "local-heuristic-fallback",
                "ai": {
                    "executive_summary": "This test observed one header warning.",
                    "remediation": ["Add HSTS for eligible HTTPS responses."],
                    "confidence": 0.7,
                    "provider": "heuristic",
                },
                "request": {"method": "GET", "headers": {"Authorization": "Bearer should-not-leak"}},
                "response": {"headers": {"Set-Cookie": "session=should-not-leak"}, "body_preview": "ok"},
            }, path)
            html = path.read_text(encoding="utf-8")
            self.assertIn("LIVE-TEST-123", html)
            self.assertIn("https://api.example.test/v2/items", html)
            self.assertIn("HSTS header is missing.", html)
            self.assertIn("Add HSTS for eligible HTTPS responses.", html)
            self.assertIn("Authorization", html)
            self.assertNotIn("should-not-leak", html)
            self.assertIn("Control Verification", html)
            self.assertNotIn("Prioritized Source Findings", html)

    def test_source_report_includes_actual_findings_and_pipeline(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "source.html"
            generate_source_report_html("Source scan", {
                "report_mode": "source",
                "report_id": "SOURCE-TEST-8",
                "assessment_type": "Source Code Security Assessment",
                "assessment_status": "COMPLETED",
                "scan_id": 8,
                "generated_at": "2026-10-09T08:00:00Z",
                "source": "sample-app.zip",
                "source_url": "https://github.com/example/sample-app",
                "source_kind": "github",
                "source_file_count": 3,
                "security_score": 7.4,
                "risk_score": 2.6,
                "risk_percent": 26,
                "category_scores": {"Security Misconfiguration": 4.2},
                "stats": {"findings": 1, "cves": 0, "design_flaws": 1, "public_exploits": 0, "files": 3},
                "findings": [{
                    "title": "Possible debug mode enabled",
                    "category": "Security Misconfiguration",
                    "rule_id": "B201",
                    "file_path": "app.py",
                    "line_number": 45,
                    "finding_score": 6.4,
                    "raw_message": "Debug setting is enabled.",
                    "code_snippet": "app.run(debug=True)",
                    "ai_justification": "The line enables debug mode.",
                    "ai_fix_steps": ["Disable debug mode in production."],
                    "ai_fix_snippet": "app.run(debug=False)",
                }],
                "ai_summary": {
                    "executive_summary": "One source finding needs review.",
                    "priority_actions": ["Disable debug mode in production."],
                    "secure_api_coding_practices": [{
                        "practice": "Production configuration", "status": "WARN",
                        "evidence": "Debug mode is enabled.",
                        "remediation": "Disable debug mode.",
                    }],
                    "confidence": 0.8,
                    "provider": "heuristic",
                },
                "ai_provider": "heuristic",
                "ai_model": "local-heuristic-fallback",
                "pipeline": [{"step": "Static analysis", "status": "complete", "details": {"files": 3}}],
            }, path)
            html = path.read_text(encoding="utf-8")
            self.assertIn("SOURCE-TEST-8", html)
            self.assertIn("Possible debug mode enabled", html)
            self.assertIn("app.py:45", html)
            self.assertIn("Disable debug mode in production.", html)
            self.assertIn("Static analysis", html)
            self.assertIn("Security Domain Exposure", html)
            self.assertNotIn("Control Verification</h2>", html)

    def test_html_escapes_untrusted_source_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "source.html"
            generate_source_report_html("Scan", {
                "source": "sample.py",
                "findings": [{"title": "Untrusted <script>alert(1)</script>", "code_snippet": "<img src=x onerror=alert(1)>", "finding_score": 3}],
            }, path)
            html = path.read_text(encoding="utf-8")
            self.assertNotIn("<script>alert(1)</script>", html)
            self.assertIn("&lt;script&gt;", html)
            self.assertIn("&lt;img src=x onerror=alert(1)&gt;", html)


if __name__ == "__main__":
    unittest.main()
