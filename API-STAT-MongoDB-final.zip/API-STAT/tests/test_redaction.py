"""Regression tests for credential redaction in stored API targets."""
import unittest

from app.routes import _redact_target_url, _redact_security_evidence


class EvidenceRedactionTests(unittest.TestCase):
    def test_target_url_redacts_query_credentials_and_userinfo(self):
        value = 'https://alice:password123@example.test/v1/items?token=abc&limit=10&X-API-Key=short'
        result = _redact_target_url(value)
        self.assertNotIn('alice', result)
        self.assertNotIn('password123', result)
        self.assertNotIn('abc', result)
        self.assertNotIn('short', result)
        self.assertIn('token=%5BREDACTED%5D', result)
        self.assertIn('limit=10', result)
        self.assertIn('X-API-Key=%5BREDACTED%5D', result)

    def test_nested_evidence_redacts_sensitive_fields(self):
        result = _redact_security_evidence({
            'headers': {'Authorization': 'Bearer secret-value', 'Accept': 'application/json'},
            'body': {'client_secret': 'sensitive', 'name': 'test'},
            'target': 'https://example.test/items?token=short&sort=asc',
        })
        self.assertEqual(result['headers']['Authorization'], '[REDACTED]')
        self.assertEqual(result['body']['client_secret'], '[REDACTED]')
        self.assertEqual(result['headers']['Accept'], 'application/json')
        self.assertEqual(result['body']['name'], 'test')
        self.assertIn('token=%5BREDACTED%5D', result['target'])
        self.assertIn('sort=asc', result['target'])


if __name__ == '__main__':
    unittest.main()
