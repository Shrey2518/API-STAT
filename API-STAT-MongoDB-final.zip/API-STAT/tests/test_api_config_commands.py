"""Regression tests for the API Config Check terminal command registry."""
import pytest

from app.scan_engine import API_CONFIG_COMMANDS, run_api_config_command

EXPECTED_COMMANDS = {
    "site-config",
    "header-config",
    "tls-config",
    "cors-config",
    "method-config",
    "api-docs",
    "sitemap-map",
    "js-route-map",
    "api-discover",
    "full-report",
}


def test_exactly_ten_api_config_commands_are_registered():
    assert API_CONFIG_COMMANDS == EXPECTED_COMMANDS


@pytest.mark.parametrize(
    "legacy_command",
    ["site-audit", "header-audit", "tls-audit", "cors-audit", "method-audit"],
)
def test_legacy_audit_commands_are_retired(legacy_command):
    with pytest.raises(ValueError, match="Unsupported API Config Check command"):
        run_api_config_command(legacy_command, "https://example.com")


def test_unknown_command_is_rejected_before_target_network_access():
    with pytest.raises(ValueError, match="Unsupported API Config Check command"):
        run_api_config_command("not-a-command", "https://example.com")
