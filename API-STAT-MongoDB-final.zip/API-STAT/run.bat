@echo off
setlocal
REM API-STAT recommended runtime: Python 3.12.x
py -3.12 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.12 is required for the most reliable security-tool runtime.
  echo Install Python 3.12.x and run this file again.
  pause
  exit /b 1
)
if not exist venv\Scripts\python.exe (
  echo Creating virtual environment with Python 3.12...
  py -3.12 -m venv venv
)
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if not exist .env copy .env.example .env
findstr /R /C:"^MONGODB_URI=mongodb" .env >nul
if errorlevel 1 (
  echo MongoDB Atlas is not configured yet.
  echo Open .env, set MONGODB_URI to your Atlas connection string, save, then rerun.
  pause
  exit /b 1
)
python main.py
