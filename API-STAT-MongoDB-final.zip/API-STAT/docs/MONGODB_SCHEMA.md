# API-STAT MongoDB schema

Database name: `apistat` by default. Set `MONGODB_DB` to override it.

All records have a numeric `id` mirrored to MongoDB's `_id` to preserve the existing API and `/scan/<id>` URLs. The `_counters` collection allocates sequential IDs. MongoDB creates collections automatically on first write; the app creates the indexes listed below on startup when `MONGODB_URI` is configured.

## Collections

### `users`
- `id`, `email` (unique), `password_hash`, `created_at`, `last_login_at`
- Passwords use Werkzeug password hashes; plain-text passwords are never persisted.

### `scans`
- Ownership and type: `user_id`, `scan_type`
- State: `status`, `progress`, `stage`, `current_stage`, `created_at`, `started_at`, `completed_at`, `error_message`
- Target/source metadata: `source_path`, `source_name`, `source_kind`, `source_type`, `source_url`, `file_count`
- Scores and metrics: `overall_score`, `risk_score`, `risk_percent`, `crypto_score`, `auth_score`, `misconfig_score`, `design_flaw_score`, `finding_count`, `cve_count`, `design_flaw_count`, `exploit_count`
- Engine/report metadata: `llm_provider`, `api_result_json`, `ai_summary_json`, `ai_summary`, `pipeline_json`, `pipeline_steps`

### `findings`
- Linkage: `scan_id`, `user_id`
- Classification: `source`, `tool`, `category`, `rule_id`, `cve_id`, `title`, `severity`, `base_severity`, `cvss_score`, `exploit_available`, `exploit_id`, `finding_score`
- Location/evidence: `file_path`, `line_number`, `code_snippet`, `endpoint`, `http_method`, `raw_message`
- AI remediation: `ai_relevance_confidence`, `ai_explanation`, `ai_justification`, `ai_fix_snippet`, `ai_fix_steps`, `remediation_steps`

### `action_logs`
- `id`, `user_id`, `action`, `target`, `details`, `created_at`
- `details` remains JSON text for compatibility with the current History & Logs and dynamic report routes.

### `policy_documents`
- `id`, `user_id`, `display_name`, `filename`, `path`, `file_storage_reference`, `file_hash`, `created_at`
- PDF bytes remain in local file storage; MongoDB stores metadata and the file reference.

### `calculator_assessments`
- `id`, `user_id`, `input_parameters`, `risk_score`, `risk_level`, `ai_interpretation`, `recommendations`, `created_at`

### `config_assessments`
- `id`, `user_id`, `target_url`, `commands_executed`, `checks_performed`, `check_results`, `risk_score`, `findings`, `recommendations`, `created_at`

### `live_api_assessments`
- `id`, `user_id`, `target_url`, `http_method`, `request_metadata`, `response_status`, `security_score`, `findings`, `ai_interpretation`, `result`, `created_at`

## Indexes

- `users.email` — unique index for account lookup and duplicate prevention.
- `scans(user_id, created_at descending)` — user-owned scan history.
- `findings(scan_id, finding_score descending)` — scan findings ordered by score.
- `findings.user_id` — user-scoped finding queries.
- `action_logs(user_id, created_at descending)` and `(user_id, action, created_at descending)` — history and latest-report retrieval.
- `policy_documents(user_id, created_at descending)` — policy library lookup.
- Each assessment collection: `(user_id, created_at descending)`.

## Data safety

- Never store MongoDB credentials in source code or frontend files.
- API-STAT redacts supported credential-like URL parameters and evidence fields before persisting route-level security test results. Continue to avoid submitting real production secrets during testing.
- Scan source files and PDF content remain in the local `uploads_tmp`/policy folders; MongoDB stores the references and assessment metadata.
- Restrict Atlas network access and database-user privileges. Use a dedicated database user for this application.
